import { type ReadQuery } from "@n/adira.core.ts";
import { type PlanRow } from "@n/adira.backend.ts";
import { type Entity } from "./resources";
import { type Order } from "./models";
import { type RequestContext } from "./telemetry";
declare const itemNative: import("@n/adira.backend.ts").MongoPlan<Omit<Omit<Omit<import("./models").Line, "id"> & Record<"id", string>, "marginCents"> & Record<"marginCents", number>, "shortageUnits"> & {
    readonly shortageUnits: number;
}, RequestContext>;
export type FulfillmentLineIntermediate = PlanRow<typeof itemNative>;
declare const orderSource: import("@n/adira.backend.ts").AppPlan<Omit<Omit<Omit<Omit<Omit<Order, "id"> & Record<"id", string>, "netCents"> & Record<"netCents", number>, "priority"> & Record<"priority", number>, "shortageUnits"> & Record<"shortageUnits", number>, "fulfillmentScore"> & Record<"fulfillmentScore", number>, RequestContext>;
export type FulfillmentOrderIntermediate = PlanRow<typeof orderSource>;
declare const batchedOrderSource: import("@n/adira.backend.ts").AppPlan<Omit<Omit<Omit<Omit<Omit<Omit<Order, "id"> & Record<"id", string>, "netCents"> & Record<"netCents", number>, "priority"> & Record<"priority", number>, "shortageSummary"> & Record<"shortageSummary", {
    readonly shortageUnits: number;
} | null>, "shortageUnits"> & Record<"shortageUnits", number>, "fulfillmentScore"> & Record<"fulfillmentScore", number>, RequestContext>;
export type BatchedOrderIntermediate = PlanRow<typeof batchedOrderSource>;
declare const financeSource: import("@n/adira.backend.ts").AppPlan<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<import("./models").Account, "id"> & Record<"id", string>, "recentOrderCount"> & Record<"recentOrderCount", number>, "recentOrderAverage"> & Record<"recentOrderAverage", number | null>, "recentOrderMin"> & Record<"recentOrderMin", number | null>, "recentOrderMax"> & Record<"recentOrderMax", number | null>, "latestPaidOrder"> & Record<"latestPaidOrder", {
    readonly netCents: number;
} | null>, "latestPaidOrderCents"> & Record<"latestPaidOrderCents", number | null>, "revenue"> & Record<"revenue", {
    readonly grossRevenueCents: number;
    readonly revenueOrderCount: number;
    readonly refundedCents: number;
} | null>, "grossRevenueCents"> & Record<"grossRevenueCents", number>, "refundedCents"> & Record<"refundedCents", number>, "revenueOrderCount"> & Record<"revenueOrderCount", number>, "netRevenueCents"> & Record<"netRevenueCents", number>, "cost"> & Record<"cost", {
    readonly costCents: number;
} | null>, "costCents"> & Record<"costCents", number>, RequestContext>;
export type FinanceIntermediate = PlanRow<typeof financeSource>;
declare const accountSource: import("@n/adira.backend.ts").AppPlan<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<Omit<import("./models").Account, "id"> & Record<"id", string>, "recentOrderCount"> & Record<"recentOrderCount", number>, "recentOrderAverage"> & Record<"recentOrderAverage", number | null>, "recentOrderMin"> & Record<"recentOrderMin", number | null>, "recentOrderMax"> & Record<"recentOrderMax", number | null>, "latestPaidOrder"> & Record<"latestPaidOrder", {
    readonly netCents: number;
} | null>, "latestPaidOrderCents"> & Record<"latestPaidOrderCents", number | null>, "revenue"> & Record<"revenue", {
    readonly grossRevenueCents: number;
    readonly revenueOrderCount: number;
    readonly refundedCents: number;
} | null>, "grossRevenueCents"> & Record<"grossRevenueCents", number>, "refundedCents"> & Record<"refundedCents", number>, "revenueOrderCount"> & Record<"revenueOrderCount", number>, "netRevenueCents"> & Record<"netRevenueCents", number>, "cost"> & Record<"cost", {
    readonly costCents: number;
} | null>, "costCents"> & Record<"costCents", number>, "marginBps"> & Record<"marginBps", number>, "openTicketCount"> & Record<"openTicketCount", number>, "lateShipmentCount"> & Record<"lateShipmentCount", number>, "exposure"> & Record<"exposure", {
    readonly exposureCents: number;
} | null>, "riskScore"> & Record<"riskScore", number>, "riskBand"> & Record<"riskBand", "critical" | "watch" | "healthy">, "portfolio"> & Record<"portfolio", {
    readonly revenueCents: number;
    readonly largestAccountCents: number;
} | null>, "managerRevenueCents"> & Record<"managerRevenueCents", number>, "managerConcentrationBps"> & Record<"managerConcentrationBps", number>, "portfolioShareBps"> & Record<"portfolioShareBps", number>, "history"> & Record<"history", readonly {
    readonly netCents: number;
}[]>, "orderVolatility"> & Record<"orderVolatility", number>, RequestContext>;
export type RiskIntermediate = PlanRow<typeof accountSource>;
export declare const readAccounts: import("@n/adira.core.ts").ReadExecutor<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly tier: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly creditLimitCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly grossRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly costCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly revenueOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly marginBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly openTicketCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly lateShipmentCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskBand: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly managerRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly managerConcentrationBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly portfolioShareBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderAverage: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMin: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMax: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly latestPaidOrderCents: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly orderVolatility: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly manager: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly orders: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        }, {}>, false, true>;
        readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                    readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                    readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                }, {}>, true, false>;
            }, {}>, false, true>;
        }, {}>, true, false>;
    }, {}>, true, false>;
    readonly tickets: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly subject: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly openedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    }, {}>, true, false>;
}, {
    readonly hasRecentEscalation: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
}>, RequestContext>;
export declare const readOrders: import("@n/adira.core.ts").ReadExecutor<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>, RequestContext>;
export declare const readOrdersBatched: import("@n/adira.core.ts").ReadExecutor<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>, RequestContext>;
export declare const executeBatchedOrders: (query: unknown, context: RequestContext) => Promise<import("@n/adira.core.ts").ExecutedRead<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>, ReadQuery<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>>>>;
export declare const inspectBatchedOrders: (query: unknown, context: RequestContext) => import("@n/adira.core.ts").ReadPlanInspection;
export declare const readProducts: import("@n/adira.core.ts").ReadExecutor<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly category: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly active: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly unitsSold: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly warehouseCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly daysCover: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, true, false>;
}, {}>, RequestContext>;
export declare function inspect(entity: Entity, query: unknown, context: RequestContext): import("@n/adira.core.ts").ReadPlanInspection;
export declare function executeAdira(entity: Entity, query: unknown, context: RequestContext): Promise<import("@n/adira.core.ts").ExecutedRead<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly tier: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly creditLimitCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly grossRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly costCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly revenueOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly marginBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly openTicketCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly lateShipmentCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskBand: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly managerRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly managerConcentrationBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly portfolioShareBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderAverage: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMin: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMax: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly latestPaidOrderCents: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly orderVolatility: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly manager: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly orders: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        }, {}>, false, true>;
        readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                    readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                    readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                }, {}>, true, false>;
            }, {}>, false, true>;
        }, {}>, true, false>;
    }, {}>, true, false>;
    readonly tickets: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly subject: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly openedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    }, {}>, true, false>;
}, {
    readonly hasRecentEscalation: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
}>, ReadQuery<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly tier: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly creditLimitCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly grossRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly costCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly revenueOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly marginBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly openTicketCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly lateShipmentCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskBand: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly managerRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly managerConcentrationBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly portfolioShareBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderAverage: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMin: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMax: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly latestPaidOrderCents: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly orderVolatility: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly manager: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly orders: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        }, {}>, false, true>;
        readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                    readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                    readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                }, {}>, true, false>;
            }, {}>, false, true>;
        }, {}>, true, false>;
    }, {}>, true, false>;
    readonly tickets: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly subject: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly openedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    }, {}>, true, false>;
}, {
    readonly hasRecentEscalation: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
}>>>> | Promise<import("@n/adira.core.ts").ExecutedRead<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>, ReadQuery<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>>>> | Promise<import("@n/adira.core.ts").ExecutedRead<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly category: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly active: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly unitsSold: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly warehouseCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly daysCover: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, true, false>;
}, {}>, ReadQuery<import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly category: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly active: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly unitsSold: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly warehouseCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly daysCover: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, true, false>;
}, {}>>>>;
export {};
