"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.nativePriority = void 0;
exports.referenceRevenueQuality = referenceRevenueQuality;
exports.referenceFulfillment = referenceFulfillment;
exports.referencePortfolio = referencePortfolio;
exports.referenceNestedTriage = referenceNestedTriage;
const business_1 = require("./business");
const models_1 = require("./models");
const telemetry_1 = require("./telemetry");
const key = (id) => String(id);
const base = (c) => ({ tenantId: c.tenantId, deletedAt: null });
const eligibleAccounts = (c) => ({
    ...base(c),
    region: { $in: ["EU", "NA"] },
    tier: { $ne: "starter" },
});
const paidWindow = {
    placedAt: { $gte: business_1.SINCE },
    status: { $in: ["paid", "shipped"] },
};
const unique = (ids) => [
    ...new Map(ids.map((id) => [key(id), id])).values(),
];
const byId = (a, b) => key(a._id).localeCompare(key(b._id));
const net = (row) => row.totalCents - row.refundedCents;
const orderPriority = (row) => (0, business_1.priority)(row.totalCents, row.status, (business_1.AS_OF - row.placedAt) / business_1.DAY);
async function referenceRevenueQuality(c) {
    const accounts = await models_1.Accounts.collection
        .find(eligibleAccounts(c))
        .toArray();
    if (!accounts.length)
        return { rows: [] };
    // One indexed Orders scan computes every reduction, latest order and top 3.
    const stats = await models_1.Orders.collection
        .aggregate([
        {
            $match: {
                ...base(c),
                ...paidWindow,
                accountId: { $in: accounts.map((a) => a._id) },
            },
        },
        { $set: { netCents: { $subtract: ["$totalCents", "$refundedCents"] } } },
        {
            $group: {
                _id: "$accountId",
                count: { $sum: 1 },
                total: { $sum: "$netCents" },
                avg: { $avg: "$netCents" },
                min: { $min: "$netCents" },
                max: { $max: "$netCents" },
                latest: {
                    $top: { sortBy: { placedAt: -1, _id: 1 }, output: "$netCents" },
                },
                topNet: {
                    $topN: {
                        n: 3,
                        sortBy: { netCents: -1, _id: 1 },
                        output: {
                            _id: "$_id",
                            totalCents: "$totalCents",
                            refundedCents: "$refundedCents",
                            status: "$status",
                            placedAt: "$placedAt",
                        },
                    },
                },
            },
        },
    ])
        .toArray();
    const map = new Map(stats.map((s) => [key(s._id), s]));
    const chosen = accounts
        .flatMap((account) => {
        const s = map.get(key(account._id));
        if (!s ||
            !((s.avg >= 200_000 && s.max >= 400_000) ||
                (s.count >= 3 && !(s.min >= 150_000))))
            return [];
        return [{ account, s }];
    })
        .sort((a, b) => b.s.avg - a.s.avg || byId(a.account, b.account))
        .slice(0, 20);
    if (!chosen.length)
        return { rows: [] };
    const costs = await models_1.Lines.collection
        .aggregate([
        {
            $match: {
                ...base(c),
                ...paidWindow,
                accountId: { $in: chosen.map(({ account }) => account._id) },
            },
        },
        { $group: { _id: "$accountId", cost: { $sum: "$costCents" } } },
    ])
        .toArray();
    const costMap = new Map(costs.map((r) => [key(r._id), r.cost]));
    return {
        rows: chosen.map(({ account, s }) => ({
            id: key(account._id),
            name: account.name,
            recentOrderCount: s.count,
            recentOrderAverage: s.avg,
            recentOrderMin: s.min,
            recentOrderMax: s.max,
            latestPaidOrderCents: s.latest,
            marginBps: (0, business_1.marginBps)(s.total, costMap.get(key(account._id)) ?? 0),
            orders: s.topNet.slice(1, 3).map((order) => {
                (0, telemetry_1.count)(c, "priority");
                return {
                    id: key(order._id),
                    netCents: net(order),
                    priority: orderPriority(order),
                };
            }),
        })),
    };
}
async function linesWithStock(orderIds, c) {
    if (!orderIds.length)
        return { lines: [], stock: { totals: new Map(), rows: new Map() } };
    const lines = await models_1.Lines.collection
        .find({ ...base(c), orderId: { $in: unique(orderIds) } }, {
        projection: {
            _id: 1,
            orderId: 1,
            productId: 1,
            quantity: 1,
            grossCents: 1,
            costCents: 1,
        },
    })
        .batchSize(10_000)
        .toArray();
    const products = unique(lines.map((l) => l.productId));
    // Shared products are read once, even when hundreds of orders reference them.
    const inventory = products.length
        ? await models_1.Inventories.collection
            .find({ ...base(c), productId: { $in: products } }, {
            projection: {
                _id: 1,
                productId: 1,
                warehouse: 1,
                onHand: 1,
                reserved: 1,
            },
        })
            .batchSize(10_000)
            .toArray()
        : [];
    const totals = new Map(), rows = new Map();
    for (const row of inventory) {
        const id = key(row.productId);
        totals.set(id, (totals.get(id) ?? 0) + row.onHand - row.reserved);
        const list = rows.get(id) ?? [];
        list.push(row);
        rows.set(id, list);
    }
    (0, telemetry_1.count)(c, "distinctStockProducts", products.length);
    return {
        lines: lines.map((line) => ({
            ...line,
            marginCents: line.grossCents - line.costCents,
            shortageUnits: Math.max(0, line.quantity - Math.max(0, totals.get(key(line.productId)) ?? 0)),
        })),
        stock: { totals, rows },
    };
}
async function nestedItems(data, c, variant) {
    const grouped = new Map();
    for (const line of data.lines) {
        const pass = variant === "fulfillment"
            ? (line.shortageUnits >= 1 && line.marginCents >= 10_000) ||
                (!(line.marginCents >= 20_000) && line.quantity >= 3)
            : line.marginCents >= 5_000 &&
                (line.quantity >= 3 || line.shortageUnits >= 1);
        if (!pass)
            continue;
        const id = key(line.orderId), list = grouped.get(id) ?? [];
        list.push(line);
        grouped.set(id, list);
    }
    for (const [id, list] of grouped)
        grouped.set(id, list
            .sort((a, b) => (variant === "fulfillment"
            ? b.shortageUnits - a.shortageUnits
            : 0) ||
            b.marginCents - a.marginCents ||
            byId(a, b))
            .slice(0, 2));
    const ids = unique([...grouped.values()].flat().map((l) => l.productId));
    const products = ids.length
        ? await models_1.Products.collection
            .find({ ...base(c), _id: { $in: ids } }, { projection: { _id: 1, sku: 1 } })
            .toArray()
        : [];
    const productMap = new Map(products.map((p) => [key(p._id), p]));
    return new Map([...grouped].map(([id, lines]) => [
        id,
        lines.map((line) => {
            const product = productMap.get(key(line.productId));
            return {
                quantity: line.quantity,
                marginCents: line.marginCents,
                shortageUnits: line.shortageUnits,
                product: product
                    ? {
                        sku: product.sku,
                        inventory: (data.stock.rows.get(key(product._id)) ?? [])
                            .filter((r) => r.onHand - r.reserved < 30)
                            .sort((a, b) => a.onHand - a.reserved - (b.onHand - b.reserved) ||
                            byId(a, b))
                            .slice(0, 1)
                            .map((row) => {
                            (0, telemetry_1.count)(c, "stockStatus");
                            return {
                                warehouse: row.warehouse,
                                available: row.onHand - row.reserved,
                                stockStatus: (0, business_1.stockStatus)(row.onHand - row.reserved),
                            };
                        }),
                    }
                    : null,
            };
        }),
    ]));
}
async function referenceFulfillment(c) {
    const orders = await models_1.Orders.collection
        .find({
        ...base(c),
        region: { $in: ["EU", "NA"] },
        placedAt: { $gte: business_1.AS_OF - 30 * business_1.DAY },
        status: { $ne: "cancelled" },
    })
        .batchSize(10_000)
        .toArray();
    const data = await linesWithStock(orders.map((o) => o._id), c);
    const shortages = new Map();
    for (const line of data.lines)
        shortages.set(key(line.orderId), (shortages.get(key(line.orderId)) ?? 0) + line.shortageUnits);
    const chosen = orders
        .map((order) => {
        const shortageUnits = shortages.get(key(order._id)) ?? 0;
        const p = orderPriority(order);
        (0, telemetry_1.count)(c, "priority");
        (0, telemetry_1.count)(c, "fulfillmentScore");
        return {
            order,
            shortageUnits,
            priority: p,
            score: (0, business_1.fulfillmentScore)(p, shortageUnits),
        };
    })
        .filter((r) => (r.shortageUnits >= 1 && r.priority >= 55) || r.score >= 90)
        .sort((a, b) => b.score - a.score || byId(a.order, b.order))
        .slice(0, 20);
    const selectedIds = new Set(chosen.map((r) => key(r.order._id)));
    const [items, accounts] = await Promise.all([
        nestedItems({
            ...data,
            lines: data.lines.filter((l) => selectedIds.has(key(l.orderId))),
        }, c, "fulfillment"),
        chosen.length
            ? models_1.Accounts.collection
                .find({
                ...base(c),
                _id: { $in: unique(chosen.map((r) => r.order.accountId)) },
            }, { projection: { _id: 1, name: 1 } })
                .toArray()
            : Promise.resolve([]),
    ]);
    const accountMap = new Map(accounts.map((a) => [key(a._id), a]));
    return {
        rows: chosen.map((r) => ({
            id: key(r.order._id),
            number: r.order.number,
            priority: r.priority,
            shortageUnits: r.shortageUnits,
            fulfillmentScore: r.score,
            account: accountMap.has(key(r.order.accountId))
                ? { name: accountMap.get(key(r.order.accountId)).name }
                : null,
            items: items.get(key(r.order._id)) ?? [],
        })),
    };
}
async function portfolios(managerIds, c) {
    if (!managerIds.length)
        return [];
    return models_1.Orders.collection
        .aggregate([
        {
            $match: {
                ...base(c),
                ...paidWindow,
                managerId: { $in: unique(managerIds) },
            },
        },
        {
            $group: {
                _id: { manager: "$managerId", account: "$accountId" },
                net: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
            },
        },
        {
            $group: {
                _id: "$_id.manager",
                total: { $sum: "$net" },
                largest: { $max: "$net" },
                accounts: { $push: { id: "$_id.account", net: "$net" } },
            },
        },
    ])
        .toArray();
}
async function referencePortfolio(c) {
    const accounts = await models_1.Accounts.collection
        .find(eligibleAccounts(c))
        .toArray();
    const ids = accounts.map((a) => a._id), managers = unique(accounts.map((a) => a.managerId));
    if (!ids.length)
        return { rows: [] };
    (0, telemetry_1.count)(c, "uniqueManagers", managers.length);
    (0, telemetry_1.count)(c, "managerPortfolioParents", accounts.length);
    const [portfolio, tickets] = await Promise.all([
        portfolios(managers, c),
        models_1.Tickets.collection
            .find({
            ...base(c),
            accountId: { $in: ids },
            status: { $in: ["open", "pending"] },
            priority: { $gte: 4 },
            openedAt: { $gte: business_1.AS_OF - 30 * business_1.DAY },
        })
            .sort({ priority: -1, _id: 1 })
            .toArray(),
    ]);
    const pMap = new Map(portfolio.map((p) => [key(p._id), p]));
    const revenues = new Map(portfolio.flatMap((p) => p.accounts.map((a) => [key(a.id), a.net])));
    const escalations = new Set(tickets.map((t) => key(t.accountId)));
    const chosen = accounts
        .map((a) => {
        const p = pMap.get(key(a.managerId)), total = p?.total ?? 0, revenue = revenues.get(key(a._id)) ?? 0;
        return {
            account: a,
            netRevenueCents: revenue,
            managerRevenueCents: total,
            managerConcentrationBps: (0, business_1.shareBps)(p?.largest ?? 0, total),
            portfolioShareBps: (0, business_1.shareBps)(revenue, total),
        };
    })
        .filter((r) => (r.portfolioShareBps >= 200 && r.managerRevenueCents >= 500_000) ||
        (escalations.has(key(r.account._id)) &&
            !(r.managerConcentrationBps < 2_000)))
        .sort((a, b) => b.portfolioShareBps - a.portfolioShareBps ||
        b.netRevenueCents - a.netRevenueCents ||
        byId(a.account, b.account))
        .slice(0, 20);
    const agents = chosen.length
        ? await models_1.Agents.collection
            .find({
            ...base(c),
            _id: { $in: unique(chosen.map((a) => a.account.managerId)) },
        })
            .toArray()
        : [];
    const agentMap = new Map(agents.map((a) => [key(a._id), a]));
    return {
        rows: chosen.map(({ account, ...metrics }) => ({
            id: key(account._id),
            name: account.name,
            ...metrics,
            manager: agentMap.has(key(account.managerId))
                ? { name: agentMap.get(key(account.managerId)).name }
                : null,
            tickets: tickets
                .filter((t) => key(t.accountId) === key(account._id))
                .slice(0, 2)
                .map((t) => ({ subject: t.subject, priority: t.priority })),
        })),
    };
}
// MongoDB's $round uses ties-to-even; floor(x + .5) matches our non-negative JS rule.
exports.nativePriority = {
    $min: [
        100,
        {
            $floor: {
                $add: [
                    0.5,
                    {
                        $add: [
                            {
                                $multiply: [
                                    {
                                        $log: [
                                            { $add: [1, { $divide: ["$totalCents", 1000] }] },
                                            2,
                                        ],
                                    },
                                    5,
                                ],
                            },
                            { $cond: [{ $eq: ["$status", "pending"] }, 25, 0] },
                            {
                                $min: [
                                    30,
                                    {
                                        $multiply: [
                                            { $divide: [{ $subtract: [business_1.AS_OF, "$placedAt"] }, business_1.DAY] },
                                            2,
                                        ],
                                    },
                                ],
                            },
                        ],
                    },
                ],
            },
        },
    ],
};
async function referenceNestedTriage(c) {
    const accounts = await models_1.Accounts.collection
        .find(eligibleAccounts(c))
        .sort({ _id: 1 })
        .skip(1)
        .limit(12)
        .toArray();
    if (!accounts.length)
        return { rows: [] };
    const ids = accounts.map((a) => a._id), managers = unique(accounts.map((a) => a.managerId));
    const [orders, tickets, agents, portfolio] = await Promise.all([
        models_1.Orders.collection
            .aggregate([{ $match: { ...base(c), accountId: { $in: ids }, placedAt: { $gte: business_1.AS_OF - 30 * business_1.DAY }, status: { $ne: "cancelled" } } }, { $set: { netCents: { $subtract: ["$totalCents", "$refundedCents"] }, priority: exports.nativePriority } }, { $match: { netCents: { $gte: 20_000 }, $or: [{ priority: { $gte: 65 } }, { status: "pending" }] } }, { $group: { _id: "$accountId", rows: { $topN: { n: 4, sortBy: { priority: -1, netCents: -1, _id: 1 }, output: "$$ROOT" } } } }, { $project: { rows: { $slice: ["$rows", 1, 3] } } }, { $unwind: "$rows" }, { $replaceWith: "$rows" }])
            .toArray(),
        models_1.Tickets.collection
            .aggregate([
            {
                $match: {
                    ...base(c),
                    accountId: { $in: ids },
                    status: { $in: ["open", "pending"] },
                    priority: { $gte: 3 },
                },
            },
            {
                $group: {
                    _id: "$accountId",
                    rows: {
                        $topN: {
                            n: 3,
                            sortBy: { priority: -1, openedAt: 1, _id: 1 },
                            output: "$$ROOT",
                        },
                    },
                },
            },
            { $project: { rows: { $slice: ["$rows", 1, 2] } } },
            { $unwind: "$rows" },
            { $replaceWith: "$rows" },
        ])
            .toArray(),
        models_1.Agents.collection
            .find({ ...base(c), _id: { $in: managers } })
            .toArray(),
        portfolios(managers, c),
    ]);
    const data = await linesWithStock(orders.map((o) => o._id), c);
    const items = await nestedItems(data, c, "triage");
    const agentMap = new Map(agents.map((a) => [key(a._id), a]));
    const pMap = new Map(portfolio.map((p) => [key(p._id), p.total]));
    return {
        rows: accounts.map((account) => ({
            id: key(account._id),
            name: account.name,
            managerRevenueCents: pMap.get(key(account.managerId)) ?? 0,
            manager: agentMap.has(key(account.managerId))
                ? { name: agentMap.get(key(account.managerId)).name }
                : null,
            orders: orders
                .filter((o) => key(o.accountId) === key(account._id))
                .sort((a, b) => b.priority - a.priority || b.netCents - a.netCents || byId(a, b))
                .map((order) => ({
                id: key(order._id),
                status: order.status,
                netCents: order.netCents,
                priority: order.priority,
                items: items.get(key(order._id)) ?? [],
            })),
            tickets: tickets
                .filter((t) => key(t.accountId) === key(account._id))
                .sort((a, b) => b.priority - a.priority || a.openedAt - b.openedAt || byId(a, b))
                .map((t) => ({ subject: t.subject, priority: t.priority })),
        })),
    };
}
