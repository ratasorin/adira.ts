"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readProducts = exports.readOrders = exports.readAccounts = void 0;
exports.inspect = inspect;
exports.executeAdira = executeAdira;
const adira_core_ts_1 = require("@n/adira.core.ts");
const adira_backend_ts_1 = require("@n/adira.backend.ts");
const resources_1 = require("../shared/resources");
const business_1 = require("../shared/business");
const models_1 = require("./models");
const telemetry_1 = require("./telemetry");
const reads = (0, adira_backend_ts_1.createReadContext)();
const limits = { defaultLimit: 40, maxLimit: 100, maxCandidates: 10_000 };
const inventorySource = reads.mongo
    .from(models_1.Inventories, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")))
    .derive("available", (e) => e.add(e.field("onHand"), e.multiply(e.field("reserved"), e.literal(-1))))
    .toApp({ batchSize: 128, concurrency: 8 })
    .derive("stockStatus", ["available"], (row, c) => {
    (0, telemetry_1.count)(c, "stockStatus");
    return (0, business_1.stockStatus)(row.available);
});
const productNative = reads.mongo
    .from(models_1.Products, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const inventory = productNative
    .related(inventorySource, { localField: "_id", foreignField: "productId" })
    .many(resources_1.InventoryResource);
const itemNative = reads.mongo
    .from(models_1.Lines, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")))
    .derive("marginCents", (e) => e.add(e.field("grossCents"), e.multiply(e.field("costCents"), e.literal(-1))));
const product = itemNative
    .related(productNative, { localField: "productId", foreignField: "_id" })
    .one(resources_1.ProductMini, { relations: { inventory } });
const accountNative = reads.mongo
    .from(models_1.Accounts, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const orderSource = reads.mongo
    .from(models_1.Orders, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")))
    .derive("netCents", (e) => e.add(e.field("totalCents"), e.multiply(e.field("refundedCents"), e.literal(-1))))
    .toApp({ batchSize: 128, concurrency: 8 })
    .derive("priority", ["totalCents", "status", "placedAt"], (r, c) => {
    (0, telemetry_1.count)(c, "priority");
    return (0, business_1.priority)(r.totalCents, r.status, (business_1.AS_OF - r.placedAt) / business_1.DAY);
});
const orderRelations = {
    items: orderSource
        .related(itemNative, { localField: "_id", foreignField: "orderId" })
        .many(resources_1.LineResource, { relations: { product } }),
    account: orderSource
        .related(accountNative, { localField: "accountId", foreignField: "_id" })
        .one(resources_1.AccountMini),
};
const orders = accountNative
    .related(orderSource, { localField: "_id", foreignField: "accountId" })
    .many(resources_1.OrderResource, {
    relations: orderRelations,
    limits: { ...limits, maxCandidates: 400 },
});
const ticketSource = reads.mongo
    .from(models_1.Tickets, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const tickets = accountNative
    .related(ticketSource, { localField: "_id", foreignField: "accountId" })
    .many(resources_1.TicketResource);
const shipmentSource = reads.mongo
    .from(models_1.Shipments, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const shipments = accountNative
    .related(shipmentSource, { localField: "_id", foreignField: "accountId" })
    .many(resources_1.ShipmentResource);
const agentSource = reads.mongo
    .from(models_1.Agents, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const manager = accountNative
    .related(agentSource, { localField: "managerId", foreignField: "_id" })
    .one(resources_1.AgentResource);
// Keep independent reads separate: revenue consumers should not activate costs.
const financeSource = accountNative
    .native({
    provides: ["grossRevenueCents", "refundedCents", "revenueOrderCount"],
    requires: ["_id", "tenantId"],
    stages: [
        {
            $lookup: {
                from: models_1.Orders.collection.name,
                localField: "_id",
                foreignField: "accountId",
                let: { tenant: "$tenantId" },
                pipeline: [
                    {
                        $match: {
                            deletedAt: null,
                            placedAt: { $gte: business_1.SINCE },
                            status: { $in: ["paid", "shipped"] },
                            $expr: { $eq: ["$tenantId", "$$tenant"] },
                        },
                    },
                    {
                        $group: {
                            _id: null,
                            gross: { $sum: "$totalCents" },
                            refunded: { $sum: "$refundedCents" },
                            count: { $sum: 1 },
                        },
                    },
                ],
                as: "_finance",
            },
        },
        {
            $set: {
                grossRevenueCents: {
                    $ifNull: [{ $arrayElemAt: ["$_finance.gross", 0] }, 0],
                },
                refundedCents: {
                    $ifNull: [{ $arrayElemAt: ["$_finance.refunded", 0] }, 0],
                },
                revenueOrderCount: {
                    $ifNull: [{ $arrayElemAt: ["$_finance.count", 0] }, 0],
                },
            },
        },
        { $unset: "_finance" },
    ],
    output: adira_core_ts_1.schema.object({
        grossRevenueCents: adira_core_ts_1.schema.number(),
        refundedCents: adira_core_ts_1.schema.number(),
        revenueOrderCount: adira_core_ts_1.schema.number(),
    }),
})
    .derive("netRevenueCents", (e) => e.add(e.field("grossRevenueCents"), e.multiply(e.field("refundedCents"), e.literal(-1))))
    // Register display-only costs after net revenue so the existing planner can
    // also delay them until after a page filtered/ordered by net revenue.
    .native({
    provides: ["costCents"],
    requires: ["_id", "tenantId"],
    stages: [
        {
            $lookup: {
                from: models_1.Lines.collection.name,
                localField: "_id",
                foreignField: "accountId",
                let: { tenant: "$tenantId" },
                pipeline: [
                    {
                        $match: {
                            deletedAt: null,
                            placedAt: { $gte: business_1.SINCE },
                            status: { $in: ["paid", "shipped"] },
                            $expr: { $eq: ["$tenantId", "$$tenant"] },
                        },
                    },
                    { $group: { _id: null, cost: { $sum: "$costCents" } } },
                ],
                as: "_cost",
            },
        },
        {
            $set: {
                costCents: { $ifNull: [{ $arrayElemAt: ["$_cost.cost", 0] }, 0] },
            },
        },
        { $unset: "_cost" },
    ],
    output: adira_core_ts_1.schema.object({ costCents: adira_core_ts_1.schema.number() }),
});
const Exposure = (0, adira_core_ts_1.defineResource)({ exposureCents: adira_core_ts_1.field.number() });
const exposure = financeSource
    .related({
    requires: ["_id"],
    output: adira_core_ts_1.schema.object({ exposureCents: adira_core_ts_1.schema.number() }),
    resolveBatch: async ({ parents, context }) => {
        (0, telemetry_1.count)(context, "exposureBatch");
        const totals = await models_1.Orders.aggregate([
            {
                $match: {
                    tenantId: context.tenantId,
                    deletedAt: null,
                    accountId: { $in: parents.map((p) => p.row._id) },
                    status: { $in: ["pending", "paid"] },
                },
            },
            {
                $group: {
                    _id: "$accountId",
                    total: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
                },
            },
        ]);
        const map = new Map(totals.map((r) => [String(r._id), r.total]));
        return parents.map(({ ref, row }) => ({
            ref,
            rows: [{ exposureCents: map.get(String(row._id)) ?? 0 }],
        }));
    },
})
    .one(Exposure);
const Portfolio = (0, adira_core_ts_1.defineResource)({ revenueCents: adira_core_ts_1.field.number() });
const portfolio = financeSource
    .related({
    requires: ["managerId"],
    output: adira_core_ts_1.schema.object({ revenueCents: adira_core_ts_1.schema.number() }),
    resolveBatch: async ({ parents, context }) => {
        (0, telemetry_1.count)(context, "managerPortfolioBatch");
        const ids = [
            ...new Map(parents.map((p) => [String(p.row.managerId), p.row.managerId])).values(),
        ];
        (0, telemetry_1.count)(context, "uniqueManagers", ids.length);
        const totals = await models_1.Orders.aggregate([
            {
                $match: {
                    tenantId: context.tenantId,
                    deletedAt: null,
                    managerId: { $in: ids },
                    placedAt: { $gte: business_1.SINCE },
                    status: { $in: ["paid", "shipped"] },
                },
            },
            {
                $group: {
                    _id: "$managerId",
                    total: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
                },
            },
        ]);
        const map = new Map(totals.map((r) => [String(r._id), r.total]));
        return parents.map(({ ref, row }) => ({
            ref,
            rows: [{ revenueCents: map.get(String(row.managerId)) ?? 0 }],
        }));
    },
})
    .one(Portfolio);
const accountSource = financeSource
    .toApp({ batchSize: 128, concurrency: 8 })
    .derive("marginBps", ["netRevenueCents", "costCents"], (r, c) => {
    (0, telemetry_1.count)(c, "marginBps");
    return (0, business_1.marginBps)(r.netRevenueCents, r.costCents);
})
    .load("openTicketCount", tickets.count({ where: { status: { $in: ["open", "pending"] } } }))
    .load("lateShipmentCount", shipments.count({ where: { late: { $eq: true } } }))
    .load("exposure", exposure.get({ select: { exposureCents: true } }))
    .derive("riskScore", [
    "netRevenueCents",
    "openTicketCount",
    "lateShipmentCount",
    "creditLimitCents",
    "exposure",
], (r, c) => {
    (0, telemetry_1.count)(c, "riskScore");
    return (0, business_1.riskScore)({ ...r, exposureCents: r.exposure?.exposureCents ?? 0 });
})
    .derive("riskBand", ["riskScore"], (r, c) => {
    (0, telemetry_1.count)(c, "riskBand");
    return (0, business_1.riskBand)(r.riskScore);
})
    .load("portfolio", portfolio.get({ select: { revenueCents: true } }))
    .derive("managerRevenueCents", ["portfolio"], (r) => r.portfolio?.revenueCents ?? 0)
    .load("history", orders.all({
    select: { netCents: true },
    where: { placedAt: { $gte: business_1.SINCE } },
}))
    .derive("orderVolatility", ["history"], (r, c) => {
    (0, telemetry_1.count)(c, "orderVolatility");
    return (0, business_1.volatility)(r.history.map((o) => o.netCents));
});
exports.readAccounts = reads.defineRead(resources_1.AccountResource, {
    source: accountSource,
    relations: { manager, orders, tickets },
    limits,
});
exports.readOrders = reads.defineRead(resources_1.OrderResource, {
    source: orderSource,
    relations: orderRelations,
    limits,
});
const sold = productNative
    .related(itemNative, { localField: "_id", foreignField: "productId" })
    .many(resources_1.LineResource, { relations: { product } });
const productSource = productNative
    .native({
    provides: ["onHand", "reserved"],
    requires: ["_id", "tenantId"],
    stages: [
        {
            $lookup: {
                from: models_1.Inventories.collection.name,
                localField: "_id",
                foreignField: "productId",
                let: { tenant: "$tenantId" },
                pipeline: [
                    {
                        $match: {
                            deletedAt: null,
                            $expr: { $eq: ["$tenantId", "$$tenant"] },
                        },
                    },
                    {
                        $group: {
                            _id: null,
                            onHand: { $sum: "$onHand" },
                            reserved: { $sum: "$reserved" },
                        },
                    },
                ],
                as: "_stock",
            },
        },
        {
            $set: {
                onHand: { $ifNull: [{ $arrayElemAt: ["$_stock.onHand", 0] }, 0] },
                reserved: { $ifNull: [{ $arrayElemAt: ["$_stock.reserved", 0] }, 0] },
            },
        },
        { $unset: "_stock" },
    ],
    output: adira_core_ts_1.schema.object({
        onHand: adira_core_ts_1.schema.number(),
        reserved: adira_core_ts_1.schema.number(),
    }),
})
    .derive("available", (e) => e.add(e.field("onHand"), e.multiply(e.field("reserved"), e.literal(-1))))
    .toApp({ batchSize: 128, concurrency: 8 })
    .load("unitsSold", sold.sum({
    field: "quantity",
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
}))
    .load("warehouseCount", inventory.count())
    .derive("daysCover", ["available", "unitsSold"], (r, c) => {
    (0, telemetry_1.count)(c, "daysCover");
    return (0, business_1.daysCover)(r.available, r.unitsSold);
});
exports.readProducts = reads.defineRead(resources_1.ProductResource, {
    source: productSource,
    relations: { inventory },
    limits,
});
function inspect(entity, query, context) {
    if (entity === "accounts")
        return exports.readAccounts.inspect(query, context);
    if (entity === "orders")
        return exports.readOrders.inspect(query, context);
    return exports.readProducts.inspect(query, context);
}
function executeAdira(entity, query, context) {
    if (entity === "accounts")
        return (0, exports.readAccounts)(query, context);
    if (entity === "orders")
        return (0, exports.readOrders)(query, context);
    return (0, exports.readProducts)(query, context);
}
