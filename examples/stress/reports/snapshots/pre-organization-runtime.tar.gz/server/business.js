"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.shareBps = exports.fulfillmentScore = exports.stockStatus = exports.daysCover = exports.priority = exports.marginBps = exports.riskBand = exports.money = exports.statuses = exports.tiers = exports.regions = exports.SINCE = exports.DAY = exports.AS_OF = void 0;
exports.riskScore = riskScore;
exports.volatility = volatility;
exports.AS_OF = Date.UTC(2026, 9, 1);
exports.DAY = 86_400_000;
exports.SINCE = exports.AS_OF - 90 * exports.DAY;
exports.regions = ["EU", "NA", "APAC", "LATAM"];
exports.tiers = ["starter", "growth", "enterprise"];
exports.statuses = ["pending", "paid", "shipped", "cancelled"];
const money = (value) => Math.round(value);
exports.money = money;
// Shared business rules, not shared query planning: both backends must compute the same answer.
function riskScore(row) {
    const utilization = row.exposureCents / Math.max(1, row.creditLimitCents);
    return Math.min(100, Math.round(Math.min(35, utilization * 25) +
        Math.min(35, row.openTicketCount * 7) +
        Math.min(25, row.lateShipmentCount * 4) +
        (row.netRevenueCents < 20_000 ? 5 : 0)));
}
const riskBand = (score) => score >= 70 ? "critical" : score >= 40 ? "watch" : "healthy";
exports.riskBand = riskBand;
const marginBps = (net, cost) => net <= 0 ? 0 : Math.round(((net - cost) * 10_000) / net);
exports.marginBps = marginBps;
const priority = (total, status, age) => Math.min(100, Math.round(Math.log2(1 + total / 1000) * 5 +
    (status === "pending" ? 25 : 0) +
    Math.min(30, age * 2)));
exports.priority = priority;
const daysCover = (available, sold) => Math.floor(available / Math.max(1, sold / 90));
exports.daysCover = daysCover;
const stockStatus = (available) => available < 0 ? "backorder" : available < 30 ? "low" : "healthy";
exports.stockStatus = stockStatus;
const fulfillmentScore = (priority, shortage) => priority + Math.min(50, shortage * 8);
exports.fulfillmentScore = fulfillmentScore;
const shareBps = (part, total) => total <= 0 ? 0 : Math.round((part * 10_000) / total);
exports.shareBps = shareBps;
function volatility(values) {
    if (!values.length)
        return 0;
    const sorted = [...values].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    const deviations = values
        .map((value) => Math.abs(value - median))
        .sort((a, b) => a - b);
    return deviations[Math.floor(deviations.length / 2)];
}
