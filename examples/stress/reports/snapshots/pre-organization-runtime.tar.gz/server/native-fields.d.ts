import type { PipelineStage } from "mongoose";
/** Developer-owned native field producer. It preserves every line and its identity. */
export declare const shortageStages: PipelineStage[];
/** A backend-approved relation predicate, usable anywhere in a Boolean tree. */
export declare const escalationStages: PipelineStage[];
