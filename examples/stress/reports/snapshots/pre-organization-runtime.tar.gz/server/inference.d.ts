/** Server build checks intermediate types. This module is never imported at runtime. */
import type { RiskIntermediate, FulfillmentLineIntermediate } from "./adira";
import type { RequestContext } from "./telemetry";
export declare function checkIntermediates(row: RiskIntermediate, line: FulfillmentLineIntermediate): {
    badNative: string;
    badLoaded: number;
};
export declare function checkCustomProviderContract(): import("@n/adira.backend.ts").AppRelationPlan<import("./models").Account, {
    readonly amount: number;
}, RequestContext>;
