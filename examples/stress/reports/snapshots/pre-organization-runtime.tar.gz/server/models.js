"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.models = exports.Inventories = exports.Tickets = exports.Shipments = exports.Lines = exports.Orders = exports.Products = exports.Accounts = exports.Agents = exports.Tenants = void 0;
exports.connect = connect;
const mongoose_1 = __importStar(require("mongoose"));
const base = {
    tenantId: { type: mongoose_1.Schema.Types.ObjectId, required: true },
    deletedAt: { type: Number, default: null },
};
function model(name, collection, fields, indexes) {
    const schema = new mongoose_1.Schema({ ...base, ...fields }, {
        versionKey: false,
        collection,
        autoIndex: false,
        autoCreate: false,
    });
    indexes.forEach((index) => schema.index(index));
    return mongoose_1.default.model(name, schema);
}
exports.Tenants = mongoose_1.default.model("StressTenant", new mongoose_1.Schema({ name: String, code: String }, {
    collection: "stress_tenants",
    versionKey: false,
    autoCreate: false,
    autoIndex: false,
}));
exports.Agents = model("StressAgent", "stress_agents", { name: String, email: String, region: String }, [{ tenantId: 1, _id: 1 }]);
exports.Accounts = model("StressAccount", "stress_accounts", {
    name: String,
    tier: String,
    region: String,
    managerId: mongoose_1.Schema.Types.ObjectId,
    creditLimitCents: Number,
    joinedAt: Number,
}, [
    { tenantId: 1, deletedAt: 1, region: 1, name: 1 },
    { tenantId: 1, deletedAt: 1, tier: 1, name: 1 },
    { tenantId: 1, managerId: 1 },
]);
exports.Products = model("StressProduct", "stress_products", {
    name: String,
    sku: String,
    category: String,
    priceCents: Number,
    costCents: Number,
    active: Boolean,
}, [{ tenantId: 1, deletedAt: 1, category: 1, active: 1, sku: 1 }]);
exports.Orders = model("StressOrder", "stress_orders", {
    accountId: mongoose_1.Schema.Types.ObjectId,
    managerId: mongoose_1.Schema.Types.ObjectId,
    region: String,
    number: String,
    status: String,
    placedAt: Number,
    totalCents: Number,
    refundedCents: Number,
}, [
    { accountId: 1, tenantId: 1, placedAt: -1, _id: 1 },
    { tenantId: 1, deletedAt: 1, region: 1, placedAt: -1 },
    { tenantId: 1, managerId: 1, placedAt: -1 },
]);
exports.Lines = model("StressLine", "stress_lines", {
    orderId: mongoose_1.Schema.Types.ObjectId,
    accountId: mongoose_1.Schema.Types.ObjectId,
    productId: mongoose_1.Schema.Types.ObjectId,
    placedAt: Number,
    status: String,
    quantity: Number,
    grossCents: Number,
    costCents: Number,
}, [
    { orderId: 1, tenantId: 1, _id: 1 },
    { accountId: 1, tenantId: 1, placedAt: -1 },
    { productId: 1, tenantId: 1, placedAt: -1 },
]);
exports.Shipments = model("StressShipment", "stress_shipments", {
    orderId: mongoose_1.Schema.Types.ObjectId,
    accountId: mongoose_1.Schema.Types.ObjectId,
    promisedAt: Number,
    deliveredAt: Number,
    late: Boolean,
}, [{ accountId: 1, tenantId: 1, deletedAt: 1, late: 1 }]);
exports.Tickets = model("StressTicket", "stress_tickets", {
    accountId: mongoose_1.Schema.Types.ObjectId,
    agentId: mongoose_1.Schema.Types.ObjectId,
    subject: String,
    status: String,
    priority: Number,
    openedAt: Number,
}, [
    { accountId: 1, tenantId: 1, deletedAt: 1, status: 1 },
    { accountId: 1, tenantId: 1, openedAt: -1 },
]);
exports.Inventories = model("StressInventory", "stress_inventory", {
    productId: mongoose_1.Schema.Types.ObjectId,
    warehouse: String,
    onHand: Number,
    reserved: Number,
}, [{ productId: 1, tenantId: 1, deletedAt: 1, warehouse: 1 }]);
exports.models = [
    exports.Tenants,
    exports.Agents,
    exports.Accounts,
    exports.Products,
    exports.Orders,
    exports.Lines,
    exports.Shipments,
    exports.Tickets,
    exports.Inventories,
];
async function connect(uri) {
    await mongoose_1.default.connect(uri, {
        maxPoolSize: 32,
        minPoolSize: 0,
        monitorCommands: true,
        serverSelectionTimeoutMS: 5000,
    });
}
