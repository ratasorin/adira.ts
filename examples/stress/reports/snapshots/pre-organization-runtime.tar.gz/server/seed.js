"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.oid = exports.profiles = void 0;
exports.random = random;
exports.seed = seed;
exports.option = option;
const mongoose_1 = __importStar(require("mongoose"));
const business_1 = require("./business");
const models_1 = require("./models");
exports.profiles = {
    smoke: { tenants: 2, agents: 12, accounts: 40, products: 60, orders: 600 },
    medium: {
        tenants: 4,
        agents: 200,
        accounts: 1500,
        products: 2000,
        orders: 30_000,
    },
    large: {
        tenants: 4,
        agents: 600,
        accounts: 6000,
        products: 8000,
        orders: 150_000,
    },
};
const oid = (kind, tenant, n) => new mongoose_1.Types.ObjectId(kind.toString(16).padStart(2, "0") +
    tenant.toString(16).padStart(4, "0") +
    n.toString(16).padStart(18, "0"));
exports.oid = oid;
function random(n) {
    let x = (n + 0x9e3779b9) | 0;
    x = Math.imul(x ^ (x >>> 16), 0x21f0aaad);
    x = Math.imul(x ^ (x >>> 15), 0x735a2d97);
    return (x ^ (x >>> 15)) >>> 0;
}
const words = [
    "Northstar",
    "Meridian",
    "Atlas",
    "Harbor",
    "Summit",
    "Cobalt",
    "Juniper",
    "Orion",
];
function account(t, n, agents) {
    return {
        _id: (0, exports.oid)(3, t, n),
        tenantId: (0, exports.oid)(1, t, 0),
        deletedAt: n > 5 && n % 37 === 0 ? business_1.AS_OF - business_1.DAY : null,
        name: `${words[n % words.length]} ${["Industries", "Supply", "Labs", "Trading"][n % 4]} ${String(n).padStart(6, "0")}`,
        tier: business_1.tiers[n % 3],
        region: business_1.regions[n % 4],
        managerId: (0, exports.oid)(2, t, n % agents),
        creditLimitCents: 50_000 + (random(n + 91) % 2_000_000),
        joinedAt: business_1.AS_OF - (n % 1000) * business_1.DAY,
    };
}
function product(t, n) {
    const priceCents = 500 + (random(n + 173) % 50_000);
    return {
        _id: (0, exports.oid)(4, t, n),
        tenantId: (0, exports.oid)(1, t, 0),
        deletedAt: n % 53 === 52 ? business_1.AS_OF - business_1.DAY : null,
        name: `${["Sensor", "Controller", "Module", "Gateway", "Cable"][n % 5]} ${n}`,
        sku: `SKU-${String(n).padStart(7, "0")}`,
        category: [
            "hardware",
            "network",
            "components",
            "accessories",
            "industrial",
        ][n % 5],
        priceCents,
        costCents: Math.round(priceCents * (0.35 + (n % 40) / 100)),
        active: n % 11 !== 10,
    };
}
async function batches(count, build, insert) {
    for (let start = 0; start < count; start += 1000)
        await insert(Array.from({ length: Math.min(1000, count - start) }, (_, i) => build(start + i)));
}
async function seed(profile, reset = false, log = console.log) {
    const db = mongoose_1.default.connection.db;
    if (!/^adira_stress(?:_|$)/.test(db.databaseName))
        throw new Error("Seed only accepts database names beginning adira_stress; other databases are protected");
    const config = exports.profiles[profile];
    const existing = await Promise.all(models_1.models.map((model) => model.estimatedDocumentCount()));
    if (existing.some(Boolean) && !reset)
        throw new Error("Stress data already exists. Use --reset to replace only the named stress collections");
    if (reset) {
        for (const model of models_1.models)
            await model.collection.deleteMany({});
        await db.collection("stress_metadata").deleteMany({});
    }
    const started = performance.now();
    for (let t = 0; t < config.tenants; t++) {
        const tenantId = (0, exports.oid)(1, t, 0);
        await models_1.Tenants.collection.insertOne({
            _id: tenantId,
            name: [
                "Northstar Commerce",
                "Meridian Operations",
                "Atlas Wholesale",
                "Harbor Supply",
            ][t % 4],
            code: `tenant-${t}`,
        });
        await batches(config.agents, (n) => ({
            _id: (0, exports.oid)(2, t, n),
            tenantId,
            deletedAt: null,
            name: `${["Avery", "Jordan", "Morgan", "Riley"][n % 4]} ${["Chen", "Silva", "Patel", "Ionescu"][n % 4]} ${n}`,
            email: `agent${n}@tenant${t}.example`,
            region: business_1.regions[n % 4],
        }), (rows) => models_1.Agents.collection.insertMany(rows));
        await batches(config.accounts, (n) => account(t, n, config.agents), (rows) => models_1.Accounts.collection.insertMany(rows));
        await batches(config.products, (n) => product(t, n), (rows) => models_1.Products.collection.insertMany(rows));
        await batches(config.products * 2, (n) => ({
            _id: (0, exports.oid)(9, t, n),
            tenantId,
            deletedAt: null,
            productId: (0, exports.oid)(4, t, Math.floor(n / 2)),
            warehouse: ["AMS", "JFK", "SIN", "LAX"][n % 4],
            onHand: random(n + 11) % 250,
            reserved: random(n + 23) % 150,
        }), (rows) => models_1.Inventories.collection.insertMany(rows));
        await batches(config.accounts * 6, (n) => ({
            _id: (0, exports.oid)(8, t, n),
            tenantId,
            deletedAt: n % 41 === 40 ? business_1.AS_OF - business_1.DAY : null,
            accountId: (0, exports.oid)(3, t, Math.floor(n / 6)),
            agentId: (0, exports.oid)(2, t, n % config.agents),
            subject: [
                "Delivery inquiry",
                "Invoice adjustment",
                "Damaged item",
                "Stock availability",
            ][n % 4],
            status: ["open", "pending", "closed", "resolved"][random(n + 31) % 4],
            priority: 1 + (random(n + 77) % 5),
            openedAt: business_1.AS_OF - (random(n + 98) % 180) * business_1.DAY,
        }), (rows) => models_1.Tickets.collection.insertMany(rows));
        for (let start = 0; start < config.orders; start += 500) {
            const orders = [];
            const lines = [];
            const shipments = [];
            for (let n = start; n < Math.min(start + 500, config.orders); n++) {
                const r = random(n + t * 900001), a = r % 100 < 35 ? r % 5 : 5 + (r % Math.max(1, config.accounts - 5));
                const acct = account(t, a, config.agents), orderId = (0, exports.oid)(5, t, n), placedAt = business_1.AS_OF - (random(n + 410) % 365) * business_1.DAY;
                const status = [
                    "paid",
                    "paid",
                    "paid",
                    "paid",
                    "shipped",
                    "shipped",
                    "shipped",
                    "shipped",
                    "pending",
                    "cancelled",
                ][random(n + 97) % 10];
                const deletedAt = n % 101 === 100 ? business_1.AS_OF - business_1.DAY : null;
                let totalCents = 0;
                for (let j = 0; j < 4; j++) {
                    const p = random(n * 4 + j + 601) % config.products, prod = product(t, p), quantity = 1 + (random(n * 4 + j + 881) % 5);
                    const grossCents = quantity * prod.priceCents;
                    totalCents += grossCents;
                    lines.push({
                        _id: (0, exports.oid)(6, t, n * 4 + j),
                        tenantId,
                        deletedAt,
                        orderId,
                        accountId: acct._id,
                        productId: prod._id,
                        placedAt,
                        status,
                        quantity,
                        grossCents,
                        costCents: quantity * prod.costCents,
                    });
                }
                orders.push({
                    _id: orderId,
                    tenantId,
                    deletedAt,
                    accountId: acct._id,
                    managerId: acct.managerId,
                    region: acct.region,
                    number: `ORD-${t}-${String(n).padStart(7, "0")}`,
                    status,
                    placedAt,
                    totalCents,
                    refundedCents: status === "shipped" && r % 7 === 0
                        ? Math.round(totalCents / 4)
                        : 0,
                });
                if (n % 4 !== 3) {
                    const promisedAt = placedAt + 3 * business_1.DAY, deliveredAt = promisedAt + ((r % 5) - 2) * business_1.DAY;
                    shipments.push({
                        _id: (0, exports.oid)(7, t, n),
                        tenantId,
                        deletedAt,
                        orderId,
                        accountId: acct._id,
                        promisedAt,
                        deliveredAt,
                        late: deliveredAt > promisedAt,
                    });
                }
            }
            await Promise.all([
                models_1.Orders.collection.insertMany(orders),
                models_1.Lines.collection.insertMany(lines),
                shipments.length
                    ? models_1.Shipments.collection.insertMany(shipments)
                    : Promise.resolve(),
            ]);
        }
        log(`Seeded tenant ${t + 1}/${config.tenants}`);
    }
    for (const model of models_1.models)
        await model.createIndexes();
    const counts = Object.fromEntries(await Promise.all(models_1.models.map(async (model) => [
        model.collection.name,
        await model.countDocuments({}),
    ])));
    const metadata = {
        profile,
        config,
        counts,
        asOf: business_1.AS_OF,
        since: business_1.AS_OF - 90 * business_1.DAY,
        seededAt: new Date().toISOString(),
        seedMs: performance.now() - started,
        distribution: "35% of orders belong to five whale accounts per tenant; remaining orders are uniform; four lines/order",
    };
    await db
        .collection("stress_metadata")
        .replaceOne({ _id: "dataset" }, { _id: "dataset", ...metadata }, { upsert: true });
    log(JSON.stringify(metadata, null, 2));
    return metadata;
}
function option(name, fallback) {
    const index = process.argv.indexOf(`--${name}`);
    return index < 0 ? (fallback ?? "") : (process.argv[index + 1] ?? "");
}
if (require.main === module)
    (async () => {
        const profile = option("profile", "medium");
        if (!Object.hasOwn(exports.profiles, profile))
            throw new Error("Unknown profile");
        await (0, models_1.connect)(option("uri", process.env.STRESS_MONGO_URI ??
            "mongodb://127.0.0.1:27017/adira_stress"));
        try {
            await seed(profile, process.argv.includes("--reset"));
        }
        finally {
            await mongoose_1.default.disconnect();
        }
    })().catch((error) => {
        console.error(error);
        process.exitCode = 1;
    });
