export declare const AS_OF: number;
export declare const DAY = 86400000;
export declare const SINCE: number;
export declare const regions: readonly ["EU", "NA", "APAC", "LATAM"];
export declare const tiers: readonly ["starter", "growth", "enterprise"];
export declare const statuses: readonly ["pending", "paid", "shipped", "cancelled"];
export declare const money: (value: number) => number;
export interface RiskInputs {
    netRevenueCents: number;
    openTicketCount: number;
    lateShipmentCount: number;
    creditLimitCents: number;
    exposureCents: number;
}
export declare function riskScore(row: RiskInputs): number;
export declare const riskBand: (score: number) => "critical" | "watch" | "healthy";
export declare const marginBps: (net: number, cost: number) => number;
export declare const priority: (total: number, status: string, age: number) => number;
export declare const daysCover: (available: number, sold: number) => number;
export declare const stockStatus: (available: number) => "healthy" | "backorder" | "low";
export declare const fulfillmentScore: (priority: number, shortage: number) => number;
export declare const shareBps: (part: number, total: number) => number;
export declare function volatility(values: readonly number[]): number;
