import mongoose, { Types } from "mongoose";
export type Id = Types.ObjectId;
export interface Base {
    _id: Id;
    tenantId: Id;
    deletedAt: number | null;
}
export interface Tenant {
    _id: Id;
    name: string;
    code: string;
}
export interface Agent extends Base {
    name: string;
    email: string;
    region: string;
}
export interface Account extends Base {
    name: string;
    tier: string;
    region: string;
    managerId: Id;
    creditLimitCents: number;
    joinedAt: number;
}
export interface Product extends Base {
    name: string;
    sku: string;
    category: string;
    priceCents: number;
    costCents: number;
    active: boolean;
}
export interface Order extends Base {
    accountId: Id;
    managerId: Id;
    region: string;
    number: string;
    status: string;
    placedAt: number;
    totalCents: number;
    refundedCents: number;
}
export interface Line extends Base {
    orderId: Id;
    accountId: Id;
    productId: Id;
    placedAt: number;
    status: string;
    quantity: number;
    grossCents: number;
    costCents: number;
}
export interface Shipment extends Base {
    orderId: Id;
    accountId: Id;
    promisedAt: number;
    deliveredAt: number;
    late: boolean;
}
export interface Ticket extends Base {
    accountId: Id;
    agentId: Id;
    subject: string;
    status: string;
    priority: number;
    openedAt: number;
}
export interface Inventory extends Base {
    productId: Id;
    warehouse: string;
    onHand: number;
    reserved: number;
}
export declare const Tenants: mongoose.Model<Tenant, {}, {}, {}, mongoose.Document<unknown, {}, Tenant, {}, {}> & Tenant & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Agents: mongoose.Model<Agent, {}, {}, {}, mongoose.Document<unknown, {}, Agent, {}, {}> & Agent & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Accounts: mongoose.Model<Account, {}, {}, {}, mongoose.Document<unknown, {}, Account, {}, {}> & Account & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Products: mongoose.Model<Product, {}, {}, {}, mongoose.Document<unknown, {}, Product, {}, {}> & Product & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Orders: mongoose.Model<Order, {}, {}, {}, mongoose.Document<unknown, {}, Order, {}, {}> & Order & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Lines: mongoose.Model<Line, {}, {}, {}, mongoose.Document<unknown, {}, Line, {}, {}> & Line & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Shipments: mongoose.Model<Shipment, {}, {}, {}, mongoose.Document<unknown, {}, Shipment, {}, {}> & Shipment & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Tickets: mongoose.Model<Ticket, {}, {}, {}, mongoose.Document<unknown, {}, Ticket, {}, {}> & Ticket & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const Inventories: mongoose.Model<Inventory, {}, {}, {}, mongoose.Document<unknown, {}, Inventory, {}, {}> & Inventory & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>;
export declare const models: (mongoose.Model<Tenant, {}, {}, {}, mongoose.Document<unknown, {}, Tenant, {}, {}> & Tenant & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Agent, {}, {}, {}, mongoose.Document<unknown, {}, Agent, {}, {}> & Agent & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Account, {}, {}, {}, mongoose.Document<unknown, {}, Account, {}, {}> & Account & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Product, {}, {}, {}, mongoose.Document<unknown, {}, Product, {}, {}> & Product & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Order, {}, {}, {}, mongoose.Document<unknown, {}, Order, {}, {}> & Order & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Line, {}, {}, {}, mongoose.Document<unknown, {}, Line, {}, {}> & Line & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Shipment, {}, {}, {}, mongoose.Document<unknown, {}, Shipment, {}, {}> & Shipment & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Ticket, {}, {}, {}, mongoose.Document<unknown, {}, Ticket, {}, {}> & Ticket & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any> | mongoose.Model<Inventory, {}, {}, {}, mongoose.Document<unknown, {}, Inventory, {}, {}> & Inventory & Required<{
    _id: Types.ObjectId;
}> & {
    __v: number;
}, any>)[];
export declare function connect(uri: string): Promise<void>;
