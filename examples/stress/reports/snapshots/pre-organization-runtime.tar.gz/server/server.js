"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = createApp;
exports.listen = listen;
const express_1 = __importDefault(require("express"));
const mongoose_1 = __importDefault(require("mongoose"));
const node_path_1 = require("node:path");
const adira_core_ts_1 = require("@n/adira.core.ts");
const workloads_1 = require("./fixtures/workloads");
const business_1 = require("./business");
const reference_1 = require("./reference");
const models_1 = require("./models");
const telemetry_1 = require("./telemetry");
const seed_1 = require("./seed");
async function createApp(mode = "both") {
    const metadata = await mongoose_1.default.connection
        .db.collection("stress_metadata")
        .findOne({ _id: "dataset" });
    if (!metadata)
        throw new Error("No stress dataset. Run the seed command first");
    const app = (0, express_1.default)();
    app.disable("x-powered-by");
    app.use(express_1.default.json({ limit: "100kb" }));
    // A reference-only process does not construct or load the Adira implementation.
    const adira = mode === "reference" ? undefined : await Promise.resolve().then(() => __importStar(require("./adira")));
    const tenants = await mongoose_1.default.connection
        .db.collection("stress_tenants")
        .find({})
        .sort({ _id: 1 })
        .toArray();
    const context = (req) => {
        const tenant = Number(req.header("x-tenant-index") ?? 0);
        if (!Number.isInteger(tenant) || tenant < 0 || tenant >= tenants.length)
            throw new adira_core_ts_1.ReadValidationError("Invalid tenant index");
        return { tenantId: (0, seed_1.oid)(1, tenant, 0), trace: (0, telemetry_1.newTrace)() };
    };
    const respond = (work) => async (req, res) => {
        let c;
        try {
            c = context(req);
            const data = await telemetry_1.traces.run(c.trace, () => work(req, c));
            res.json({
                ...(0, adira_core_ts_1.readRecord)(data, "response data"),
                telemetry: {
                    backend: req.path.includes("/reference/")
                        ? "reference"
                        : req.path.includes("/adira-batched/")
                            ? "adiraBatched"
                            : "adira",
                    serverMs: performance.now() - c.trace.started,
                    mongoMs: c.trace.mongoMs,
                    commands: c.trace.commands,
                    commandNames: c.trace.commandNames,
                    callbacks: c.trace.callbacks,
                    dataBytes: Buffer.byteLength(JSON.stringify(data)),
                    memory: process.memoryUsage(),
                },
            });
        }
        catch (error) {
            res
                .status(error instanceof Error && error.name === "ReadBudgetError"
                ? 422
                : error instanceof adira_core_ts_1.ReadValidationError
                    ? 400
                    : 500)
                .json({
                error: error instanceof Error ? error.name : "Error",
                message: error instanceof Error ? error.message : String(error),
                telemetry: c
                    ? {
                        serverMs: performance.now() - c.trace.started,
                        commands: c.trace.commands,
                        callbacks: c.trace.callbacks,
                    }
                    : undefined,
            });
        }
    };
    const query = (req) => {
        const raw = req.query.query;
        if (typeof raw !== "string")
            throw new adira_core_ts_1.ReadValidationError("Supply a JSON query parameter");
        if (Buffer.byteLength(raw) > 64_000)
            throw new adira_core_ts_1.ReadValidationError("Query exceeds 64KB");
        try {
            return JSON.parse(raw);
        }
        catch {
            throw new adira_core_ts_1.ReadValidationError("Invalid JSON query");
        }
    };
    app.get("/api/catalog", (_req, res) => res.json({
        metadata,
        tenants: tenants.map((t, i) => ({ index: i, name: t.name })),
        mode,
    }));
    if (adira) {
        app.get("/api/adira-batched/orders", respond((req, c) => adira.executeBatchedOrders(query(req), c)));
        app.get("/api/adira-batched/plan/orders", respond(async (req, c) => adira.inspectBatchedOrders(query(req), c)));
        app.get("/api/adira/accounts", respond((req, c) => adira.executeAdira("accounts", query(req), c)));
        app.get("/api/adira/orders", respond((req, c) => adira.executeAdira("orders", query(req), c)));
        app.get("/api/adira/products", respond((req, c) => adira.executeAdira("products", query(req), c)));
        app.get("/api/adira/plan/:entity", respond(async (req, c) => {
            if (!["accounts", "orders", "products"].includes(req.params.entity))
                throw new adira_core_ts_1.ReadValidationError("Unknown resource");
            return adira.inspect(req.params.entity, query(req), c);
        }));
    }
    if (mode !== "adira")
        app.get("/api/reference/:view", respond((req, c) => {
            const workload = workloads_1.workloads.find((w) => w.id === req.params.view);
            if (!workload)
                throw new adira_core_ts_1.ReadValidationError("Unknown reference view");
            return (0, reference_1.executeReference)(workload.id, c);
        }));
    if (adira)
        app.get("/api/diagnostics/budget", respond(async (req, c) => {
            const tenant = Number(req.header("x-tenant-index") ?? 0), id = (0, seed_1.oid)(3, tenant, 0);
            const reference = await (0, reference_1.referenceVolatility)(id, c);
            const childQuery = {
                select: {
                    id: true,
                    orders: {
                        select: { id: true, priority: true },
                        where: {
                            placedAt: { $gte: business_1.SINCE },
                        },
                        orderBy: { priority: "desc", id: "asc" },
                        page: { limit: 2 },
                    },
                },
                where: { id: { $eq: String(id) } },
                page: { limit: 1 },
            };
            let childPage;
            try {
                childPage = await adira.executeAdira("accounts", childQuery, c);
            }
            catch (error) {
                childPage = {
                    error: error instanceof Error ? error.name : "Error",
                    message: String(error),
                };
            }
            const computedChildPage = {
                query: childQuery,
                reference: reference.priorityTop2,
                adira: childPage,
            };
            try {
                return {
                    reference,
                    adira: await adira.executeAdira("accounts", {
                        select: { id: true, name: true, orderVolatility: true },
                        where: { id: { $eq: String(id) } },
                    }, c),
                    candidateLimit: 400,
                    computedChildPage,
                };
            }
            catch (error) {
                return {
                    reference,
                    adira: {
                        error: error instanceof Error ? error.name : "Error",
                        message: String(error),
                    },
                    candidateLimit: 400,
                    computedChildPage,
                };
            }
        }));
    app.get("/api/diagnostics/indexes", respond(async () => Object.fromEntries(await Promise.all(models_1.models.map(async (model) => [
        model.collection.name,
        await model.collection.indexes(),
    ])))));
    if (adira)
        app.get("/api/diagnostics/commands/:view", respond(async (req, c) => {
            const workload = workloads_1.workloads.find((w) => w.id === req.params.view);
            if (!workload)
                throw new adira_core_ts_1.ReadValidationError("Unknown view");
            const backend = req.query.backend ?? "adira";
            if (backend !== "adira" &&
                backend !== "reference" &&
                backend !== "adiraBatched")
                throw new adira_core_ts_1.ReadValidationError("Unknown backend");
            if (backend === "adiraBatched" && workload.entity !== "orders")
                throw new adira_core_ts_1.ReadValidationError("The batched alternative is an order resource");
            c.trace.details = [];
            const result = backend === "adiraBatched"
                ? await adira.executeBatchedOrders(workload.query, c)
                : backend === "adira"
                    ? await adira.executeAdira(workload.entity, workload.query, c)
                    : await (0, reference_1.executeReference)(workload.id, c);
            return {
                note: "Untimed command trace; returned counts include intermediate rows and repeated rows. Durations may overlap.",
                backend,
                rows: result.rows.length,
                commands: c.trace.details,
                callbacks: c.trace.callbacks,
            };
        }));
    if (adira)
        app.get("/api/diagnostics/explain/:view", respond(async (req, c) => {
            const workload = workloads_1.workloads.find((w) => w.id === req.params.view);
            if (!workload)
                throw new adira_core_ts_1.ReadValidationError("Unknown view");
            const plan = adira.inspect(workload.entity, workload.query, c);
            const collection = workload.entity === "accounts"
                ? models_1.Accounts.collection
                : workload.entity === "orders"
                    ? models_1.Orders.collection
                    : models_1.Products.collection;
            const explanation = await collection
                .aggregate(plan.pipeline)
                .explain("executionStats");
            return {
                note: "Only the Adira root native pipeline; deferred loads, JavaScript and later database calls are not included",
                plan,
                explanation,
            };
        }));
    app.use("/api", (_req, res) => res
        .status(404)
        .json({ error: "NotFound", message: "Unknown API endpoint" }));
    app.use(express_1.default.static((0, node_path_1.resolve)(__dirname, "../public")));
    app.get("*", (_req, res) => res.sendFile((0, node_path_1.resolve)(__dirname, "../public/index.html")));
    return app;
}
async function listen(mode = "both", port = 5400) {
    const app = await createApp(mode);
    const server = app.listen(port, "127.0.0.1");
    await new Promise((resolve, reject) => {
        server.once("listening", resolve);
        server.once("error", reject);
    });
    return {
        server,
        url: `http://127.0.0.1:${server.address().port}`,
    };
}
if (require.main === module)
    (async () => {
        await (0, models_1.connect)((0, seed_1.option)("uri", process.env.STRESS_MONGO_URI ??
            "mongodb://127.0.0.1:27017/adira_stress"));
        (0, telemetry_1.monitor)();
        const mode = (0, seed_1.option)("backend", "both");
        if (!["adira", "reference", "both"].includes(mode))
            throw new Error("Unknown backend");
        const { server, url } = await listen(mode, Number((0, seed_1.option)("port", "5400")));
        console.log(`Operations Lab: ${url} (${mode})`);
        const stop = () => server.close(() => {
            mongoose_1.default.disconnect().then(() => process.exit(0));
        });
        process.once("SIGINT", stop);
        process.once("SIGTERM", stop);
    })().catch(async (error) => {
        console.error(error);
        await mongoose_1.default.disconnect();
        process.exitCode = 1;
    });
