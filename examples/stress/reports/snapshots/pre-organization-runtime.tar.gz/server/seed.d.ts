import { Types } from "mongoose";
export declare const profiles: {
    readonly smoke: {
        readonly tenants: 2;
        readonly agents: 12;
        readonly accounts: 40;
        readonly products: 60;
        readonly orders: 600;
    };
    readonly medium: {
        readonly tenants: 4;
        readonly agents: 200;
        readonly accounts: 1500;
        readonly products: 2000;
        readonly orders: 30000;
    };
    readonly large: {
        readonly tenants: 4;
        readonly agents: 600;
        readonly accounts: 6000;
        readonly products: 8000;
        readonly orders: 150000;
    };
};
export type Profile = keyof typeof profiles;
export declare const oid: (kind: number, tenant: number, n: number) => Types.ObjectId;
export declare function random(n: number): number;
export declare function seed(profile: Profile, reset?: boolean, log?: (message: string) => void): Promise<{
    profile: "smoke" | "medium" | "large";
    config: {
        readonly tenants: 2;
        readonly agents: 12;
        readonly accounts: 40;
        readonly products: 60;
        readonly orders: 600;
    } | {
        readonly tenants: 4;
        readonly agents: 200;
        readonly accounts: 1500;
        readonly products: 2000;
        readonly orders: 30000;
    } | {
        readonly tenants: 4;
        readonly agents: 600;
        readonly accounts: 6000;
        readonly products: 8000;
        readonly orders: 150000;
    };
    counts: any;
    asOf: number;
    since: number;
    seededAt: string;
    seedMs: number;
    distribution: string;
}>;
export declare function option(name: string, fallback?: string): string;
