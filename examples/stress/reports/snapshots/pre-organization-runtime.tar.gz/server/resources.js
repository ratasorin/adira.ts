"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductResource = exports.AccountResource = exports.ShipmentResource = exports.TicketResource = exports.OrderResource = exports.LineResource = exports.ProductMini = exports.InventoryResource = exports.AccountMini = exports.AgentResource = exports.readLimits = void 0;
const adira_core_ts_1 = require("@n/adira.core.ts");
exports.readLimits = {
    ...adira_core_ts_1.defaultReadLimits,
    defaultLimit: 40,
    maxLimit: 100,
};
const id = () => adira_core_ts_1.field.string().filterable("$eq").orderable();
const number = () => adira_core_ts_1.field.number().filterable("$eq", "$gte", "$lt").orderable();
const text = () => adira_core_ts_1.field.string().filterable("$eq", "$in", "$startsWith").orderable();
exports.AgentResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    name: text(),
    region: text(),
});
exports.AccountMini = (0, adira_core_ts_1.defineResource)({
    id: id(),
    name: text(),
    region: text(),
});
exports.InventoryResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    warehouse: text(),
    onHand: number(),
    reserved: number(),
    available: number(),
    stockStatus: text(),
});
exports.ProductMini = (0, adira_core_ts_1.defineResource)({
    id: id(),
    name: text(),
    sku: text(),
    inventory: adira_core_ts_1.field.many(exports.InventoryResource),
});
exports.LineResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    quantity: number(),
    grossCents: number(),
    marginCents: number(),
    shortageUnits: number(),
    placedAt: number(),
    status: text(),
    product: adira_core_ts_1.field.one(exports.ProductMini).nullable(),
});
exports.OrderResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    number: text(),
    status: text(),
    region: text(),
    placedAt: number(),
    totalCents: number(),
    netCents: number(),
    priority: number(),
    shortageUnits: number(),
    fulfillmentScore: number(),
    account: adira_core_ts_1.field.one(exports.AccountMini).nullable(),
    items: adira_core_ts_1.field.many(exports.LineResource),
});
exports.TicketResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    subject: text(),
    status: text(),
    priority: number(),
    openedAt: number(),
});
exports.ShipmentResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    late: adira_core_ts_1.field.boolean().filterable("$eq"),
});
exports.AccountResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    name: text(),
    tier: text(),
    region: text(),
    creditLimitCents: number(),
    grossRevenueCents: number(),
    netRevenueCents: number(),
    costCents: number(),
    revenueOrderCount: number(),
    marginBps: number(),
    openTicketCount: number(),
    lateShipmentCount: number(),
    riskScore: number(),
    riskBand: text(),
    managerRevenueCents: number(),
    managerConcentrationBps: number(),
    portfolioShareBps: number(),
    recentOrderCount: number(),
    recentOrderAverage: number().nullable(),
    recentOrderMin: number().nullable(),
    recentOrderMax: number().nullable(),
    latestPaidOrderCents: number().nullable(),
    orderVolatility: number(),
    manager: adira_core_ts_1.field.one(exports.AgentResource).nullable(),
    orders: adira_core_ts_1.field.many(exports.OrderResource),
    tickets: adira_core_ts_1.field.many(exports.TicketResource),
}, {
    predicates: { hasRecentEscalation: adira_core_ts_1.field.boolean().filterable("$eq") },
});
exports.ProductResource = (0, adira_core_ts_1.defineResource)({
    id: id(),
    name: text(),
    sku: text(),
    category: text(),
    active: adira_core_ts_1.field.boolean().filterable("$eq"),
    available: number(),
    unitsSold: number(),
    warehouseCount: number(),
    daysCover: number(),
    inventory: adira_core_ts_1.field.many(exports.InventoryResource),
});
