export declare function temporaryMongo(): Promise<{
    uri: string;
    stop: () => Promise<void>;
}>;
