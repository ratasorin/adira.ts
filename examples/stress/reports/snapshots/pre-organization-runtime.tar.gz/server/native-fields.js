"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.escalationStages = exports.shortageStages = void 0;
const models_1 = require("./models");
const business_1 = require("./business");
/** Developer-owned native field producer. It preserves every line and its identity. */
exports.shortageStages = [
    {
        $lookup: {
            from: models_1.Inventories.collection.name,
            localField: "productId",
            foreignField: "productId",
            let: { tenant: "$tenantId" },
            pipeline: [
                {
                    $match: {
                        $expr: {
                            $and: [
                                { $eq: ["$tenantId", "$$tenant"] },
                                { $eq: [{ $ifNull: ["$deletedAt", null] }, null] },
                            ],
                        },
                    },
                },
                {
                    $group: {
                        _id: null,
                        available: { $sum: { $subtract: ["$onHand", "$reserved"] } },
                    },
                },
            ],
            as: "_stockForLine",
        },
    },
    {
        $set: {
            shortageUnits: {
                $max: [
                    0,
                    {
                        $subtract: [
                            "$quantity",
                            {
                                $max: [
                                    0,
                                    { $ifNull: [{ $first: "$_stockForLine.available" }, 0] },
                                ],
                            },
                        ],
                    },
                ],
            },
        },
    },
    { $unset: "_stockForLine" },
];
/** A backend-approved relation predicate, usable anywhere in a Boolean tree. */
exports.escalationStages = [
    {
        $lookup: {
            from: models_1.Tickets.collection.name,
            localField: "_id",
            foreignField: "accountId",
            let: { tenant: "$tenantId" },
            pipeline: [
                {
                    $match: {
                        status: { $in: ["open", "pending"] },
                        priority: { $gte: 4 },
                        openedAt: { $gte: business_1.AS_OF - 30 * business_1.DAY },
                        $expr: {
                            $and: [
                                { $eq: ["$tenantId", "$$tenant"] },
                                { $eq: [{ $ifNull: ["$deletedAt", null] }, null] },
                            ],
                        },
                    },
                },
                { $limit: 1 },
                { $project: { _id: 0, priority: 1 } },
            ],
            as: "recentEscalations",
        },
    },
];
