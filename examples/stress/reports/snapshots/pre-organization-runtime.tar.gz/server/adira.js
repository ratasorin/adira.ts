"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.readProducts = exports.inspectBatchedOrders = exports.executeBatchedOrders = exports.readOrdersBatched = exports.readOrders = exports.readAccounts = void 0;
exports.inspect = inspect;
exports.executeAdira = executeAdira;
const adira_core_ts_1 = require("@n/adira.core.ts");
const adira_backend_ts_1 = require("@n/adira.backend.ts");
const resources_1 = require("./resources");
const business_1 = require("./business");
const native_fields_1 = require("./native-fields");
const models_1 = require("./models");
const telemetry_1 = require("./telemetry");
const metrics_1 = require("./metrics");
const reads = (0, adira_backend_ts_1.createReadContext)();
const finiteNumber = adira_core_ts_1.schema.number();
const inventorySource = reads.mongo
    .from(models_1.Inventories, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")))
    .derive("available", (e) => e.add(e.field("onHand"), e.multiply(e.field("reserved"), e.literal(-1))))
    .toApp({ batchSize: 128, concurrency: 8 })
    .derive("stockStatus", ["available"], (row, c) => {
    (0, telemetry_1.count)(c, "stockStatus");
    return (0, business_1.stockStatus)(row.available);
});
const productNative = reads.mongo
    .from(models_1.Products, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const inventory = productNative
    .related(inventorySource, { localField: "_id", foreignField: "productId" })
    .many(resources_1.InventoryResource);
const itemNative = reads.mongo
    .from(models_1.Lines, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")))
    .derive("marginCents", (e) => e.add(e.field("grossCents"), e.multiply(e.field("costCents"), e.literal(-1))))
    .native({
    provides: ["shortageUnits"],
    requires: ["productId", "tenantId", "quantity"],
    stages: native_fields_1.shortageStages,
    output: adira_core_ts_1.schema.object({ shortageUnits: adira_core_ts_1.schema.number() }),
});
const product = itemNative
    .related(productNative, { localField: "productId", foreignField: "_id" })
    .one(resources_1.ProductMini, { relations: { inventory } });
const accountNative = reads.mongo
    .from(models_1.Accounts, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const orderNative = reads.mongo
    .from(models_1.Orders, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")))
    .derive("netCents", (e) => e.add(e.field("totalCents"), e.multiply(e.field("refundedCents"), e.literal(-1))));
const priorityNeeds = ["totalCents", "status", "placedAt"];
function resolvePriority(row, context) {
    (0, telemetry_1.count)(context, "priority");
    return (0, business_1.priority)(row.totalCents, row.status, (business_1.AS_OF - row.placedAt) / business_1.DAY);
}
const orderBase = orderNative
    .toApp({ batchSize: 128, concurrency: 8 })
    .derive("priority", priorityNeeds, resolvePriority);
const fulfillmentItems = orderBase
    .related(itemNative, { localField: "_id", foreignField: "orderId" })
    .many(resources_1.LineResource, { relations: { product } });
const orderSource = orderBase
    .load("shortageUnits", fulfillmentItems.sum({ field: "shortageUnits" }))
    .derive("fulfillmentScore", ["priority", "shortageUnits"], (row, context) => {
    (0, telemetry_1.count)(context, "fulfillmentScore");
    return (0, business_1.fulfillmentScore)(row.priority, row.shortageUnits);
});
// The same public contract and includes, with a deliberately different root
// implementation. Larger batches amortize shared product reads across orders.
const batchedOrderBase = orderNative
    .toApp({ batchSize: 1024, concurrency: 8 })
    .derive("priority", priorityNeeds, resolvePriority);
const shortageSummary = batchedOrderBase
    .related({
    requires: ["_id"],
    output: metrics_1.shortageOutput,
    resolveBatch: metrics_1.loadOrderShortages,
})
    .one(metrics_1.ShortageSummary);
const batchedOrderSource = batchedOrderBase
    .load("shortageSummary", shortageSummary.get({ select: { shortageUnits: true } }))
    .derive("shortageUnits", ["shortageSummary"], (row) => row.shortageSummary?.shortageUnits ?? 0)
    .derive("fulfillmentScore", ["priority", "shortageUnits"], (row, context) => {
    (0, telemetry_1.count)(context, "fulfillmentScore");
    return (0, business_1.fulfillmentScore)(row.priority, row.shortageUnits);
});
const orderRelations = {
    items: orderSource
        .related(itemNative, { localField: "_id", foreignField: "orderId" })
        .many(resources_1.LineResource, { relations: { product } }),
    account: orderSource
        .related(accountNative, { localField: "accountId", foreignField: "_id" })
        .one(resources_1.AccountMini),
};
const orders = accountNative
    .related(orderSource, { localField: "_id", foreignField: "accountId" })
    .many(resources_1.OrderResource, {
    relations: orderRelations,
    limits: { ...resources_1.readLimits, maxCandidates: 400 },
});
const ticketSource = reads.mongo
    .from(models_1.Tickets, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const tickets = accountNative
    .related(ticketSource, { localField: "_id", foreignField: "accountId" })
    .many(resources_1.TicketResource);
const shipmentSource = reads.mongo
    .from(models_1.Shipments, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const shipments = accountNative
    .related(shipmentSource, { localField: "_id", foreignField: "accountId" })
    .many(resources_1.ShipmentResource);
const agentSource = reads.mongo
    .from(models_1.Agents, {
    scope: (e, c) => e.and(e.eq(e.field("tenantId"), c.tenantId), e.isNull(e.field("deletedAt"))),
})
    .derive("id", (e) => e.toString(e.field("_id")));
const manager = accountNative
    .related(agentSource, { localField: "managerId", foreignField: "_id" })
    .one(resources_1.AgentResource);
// One query per parent batch for each independent data source. Grouping revenue
// fields shares a single Orders scan; selecting revenue never activates Lines.
const revenue = accountNative
    .related({
    requires: ["_id"],
    output: metrics_1.revenueOutput,
    resolveBatch: metrics_1.loadRevenue,
})
    .one(metrics_1.Revenue);
const costs = accountNative
    .related({
    requires: ["_id"],
    output: metrics_1.costOutput,
    resolveBatch: metrics_1.loadCost,
})
    .one(metrics_1.Cost);
// Membership statistics precede display-only financial enrichment so the latter
// can run only for the selected parent page. Every unused reduction is pruned.
const statisticsSource = accountNative
    .toApp({ batchSize: 128, concurrency: 8 })
    .load("recentOrderCount", orders.count({
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
}))
    .load("recentOrderAverage", orders.avg({
    field: "netCents",
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
}))
    .load("recentOrderMin", orders.min({
    field: "netCents",
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
}))
    .load("recentOrderMax", orders.max({
    field: "netCents",
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
}))
    .load("latestPaidOrder", orders.first({
    select: { netCents: true },
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
    orderBy: { placedAt: "desc", id: "asc" },
}))
    .derive("latestPaidOrderCents", ["latestPaidOrder"], (row) => row.latestPaidOrder?.netCents ?? null);
const financeSource = statisticsSource
    .load("revenue", revenue.get({
    select: {
        grossRevenueCents: true,
        refundedCents: true,
        revenueOrderCount: true,
    },
}))
    .derive("grossRevenueCents", ["revenue"], (row) => row.revenue?.grossRevenueCents ?? 0)
    .derive("refundedCents", ["revenue"], (row) => row.revenue?.refundedCents ?? 0)
    .derive("revenueOrderCount", ["revenue"], (row) => row.revenue?.revenueOrderCount ?? 0)
    .derive("netRevenueCents", ["grossRevenueCents", "refundedCents"], (row) => finiteNumber.parse(row.grossRevenueCents - row.refundedCents))
    // The independent display-only cost suffix can run after parent pagination.
    .load("cost", costs.get({ select: { costCents: true } }))
    .derive("costCents", ["cost"], (row) => row.cost?.costCents ?? 0);
const Exposure = (0, adira_core_ts_1.defineResource)({ exposureCents: adira_core_ts_1.field.number() });
const exposure = financeSource
    .related({
    requires: ["_id"],
    output: adira_core_ts_1.schema.object({ exposureCents: adira_core_ts_1.schema.number() }),
    resolveBatch: async ({ parents, context }) => {
        (0, telemetry_1.count)(context, "exposureBatch");
        const totals = await models_1.Orders.aggregate([
            {
                $match: {
                    tenantId: context.tenantId,
                    deletedAt: null,
                    accountId: { $in: parents.map((p) => p.row._id) },
                    status: { $in: ["pending", "paid"] },
                },
            },
            {
                $group: {
                    _id: "$accountId",
                    total: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
                },
            },
        ]);
        const map = new Map(totals.map((r) => [String(r._id), r.total]));
        return parents.map(({ ref, row }) => ({
            ref,
            rows: [{ exposureCents: map.get(String(row._id)) ?? 0 }],
        }));
    },
})
    .one(Exposure);
const Portfolio = (0, adira_core_ts_1.defineResource)({
    revenueCents: adira_core_ts_1.field.number(),
    largestAccountCents: adira_core_ts_1.field.number(),
});
const portfolio = financeSource
    .related({
    requires: ["managerId"],
    output: adira_core_ts_1.schema.object({
        revenueCents: adira_core_ts_1.schema.number(),
        largestAccountCents: adira_core_ts_1.schema.number(),
    }),
    resolveBatch: async ({ parents, context }) => {
        (0, telemetry_1.count)(context, "managerPortfolioBatch");
        const ids = [
            ...new Map(parents.map((p) => [String(p.row.managerId), p.row.managerId])).values(),
        ];
        (0, telemetry_1.count)(context, "uniqueManagers", ids.length);
        (0, telemetry_1.count)(context, "managerPortfolioParents", parents.length);
        const totals = await models_1.Orders.aggregate([
            {
                $match: {
                    tenantId: context.tenantId,
                    deletedAt: null,
                    managerId: { $in: ids },
                    placedAt: { $gte: business_1.SINCE },
                    status: { $in: ["paid", "shipped"] },
                },
            },
            {
                $group: {
                    _id: { manager: "$managerId", account: "$accountId" },
                    total: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
                },
            },
            {
                $group: {
                    _id: "$_id.manager",
                    total: { $sum: "$total" },
                    largestAccountCents: { $max: "$total" },
                },
            },
        ]);
        const map = new Map(totals.map((r) => [String(r._id), r]));
        return parents.map(({ ref, row }) => ({
            ref,
            rows: [
                {
                    revenueCents: map.get(String(row.managerId))?.total ?? 0,
                    largestAccountCents: map.get(String(row.managerId))?.largestAccountCents ?? 0,
                },
            ],
        }));
    },
})
    .one(Portfolio);
const accountSource = financeSource
    .derive("marginBps", ["netRevenueCents", "costCents"], (r, c) => {
    (0, telemetry_1.count)(c, "marginBps");
    return (0, business_1.marginBps)(r.netRevenueCents, r.costCents);
})
    .load("openTicketCount", tickets.count({ where: { status: { $in: ["open", "pending"] } } }))
    .load("lateShipmentCount", shipments.count({ where: { late: { $eq: true } } }))
    .load("exposure", exposure.get({ select: { exposureCents: true } }))
    .derive("riskScore", [
    "netRevenueCents",
    "openTicketCount",
    "lateShipmentCount",
    "creditLimitCents",
    "exposure",
], (r, c) => {
    (0, telemetry_1.count)(c, "riskScore");
    return (0, business_1.riskScore)({ ...r, exposureCents: r.exposure?.exposureCents ?? 0 });
})
    .derive("riskBand", ["riskScore"], (r, c) => {
    (0, telemetry_1.count)(c, "riskBand");
    return (0, business_1.riskBand)(r.riskScore);
})
    .load("portfolio", portfolio.get({
    select: { revenueCents: true, largestAccountCents: true },
}))
    .derive("managerRevenueCents", ["portfolio"], (r) => r.portfolio?.revenueCents ?? 0)
    .derive("managerConcentrationBps", ["portfolio"], (row) => (0, business_1.shareBps)(row.portfolio?.largestAccountCents ?? 0, row.portfolio?.revenueCents ?? 0))
    .derive("portfolioShareBps", ["netRevenueCents", "managerRevenueCents"], (row) => (0, business_1.shareBps)(row.netRevenueCents, row.managerRevenueCents))
    .load("history", orders.all({
    select: { netCents: true },
    where: { placedAt: { $gte: business_1.SINCE } },
}))
    .derive("orderVolatility", ["history"], (r, c) => {
    (0, telemetry_1.count)(c, "orderVolatility");
    return (0, business_1.volatility)(r.history.map((o) => o.netCents));
});
exports.readAccounts = reads.defineRead(resources_1.AccountResource, {
    source: accountSource,
    relations: { manager, orders, tickets },
    limits: resources_1.readLimits,
    filters: {
        hasRecentEscalation: {
            $eq: (expected) => accountSource.pipelineCondition({
                requires: ["_id", "tenantId"],
                preservesRows: true,
                stages: native_fields_1.escalationStages,
                output: adira_core_ts_1.schema.object({
                    recentEscalations: adira_core_ts_1.schema.array(adira_core_ts_1.schema.object({ priority: adira_core_ts_1.schema.number() })),
                }),
                test: (e) => e.eq(e.gt(e.size(e.field("recentEscalations")), 0), expected),
            }),
        },
    },
});
exports.readOrders = reads.defineRead(resources_1.OrderResource, {
    source: orderSource,
    relations: orderRelations,
    limits: resources_1.readLimits,
});
exports.readOrdersBatched = reads.defineRead(resources_1.OrderResource, {
    source: batchedOrderSource,
    relations: orderRelations,
    limits: resources_1.readLimits,
});
const executeBatchedOrders = (query, context) => (0, exports.readOrdersBatched)(query, context);
exports.executeBatchedOrders = executeBatchedOrders;
const inspectBatchedOrders = (query, context) => exports.readOrdersBatched.inspect(query, context);
exports.inspectBatchedOrders = inspectBatchedOrders;
const sold = productNative
    .related(itemNative, { localField: "_id", foreignField: "productId" })
    .many(resources_1.LineResource, { relations: { product } });
const stock = productNative
    .related({
    requires: ["_id"],
    output: metrics_1.stockOutput,
    resolveBatch: metrics_1.loadStock,
})
    .one(metrics_1.Stock);
const productSource = productNative
    .toApp({ batchSize: 128, concurrency: 8 })
    .load("stock", stock.get({
    select: {
        onHand: true,
        reserved: true,
        warehouseCount: true,
    },
}))
    .derive("available", ["stock"], (row) => finiteNumber.parse((row.stock?.onHand ?? 0) - (row.stock?.reserved ?? 0)))
    .derive("warehouseCount", ["stock"], (row) => row.stock?.warehouseCount ?? 0)
    .load("unitsSold", sold.sum({
    field: "quantity",
    where: {
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    },
}))
    .derive("daysCover", ["available", "unitsSold"], (r, c) => {
    (0, telemetry_1.count)(c, "daysCover");
    return (0, business_1.daysCover)(r.available, r.unitsSold);
});
exports.readProducts = reads.defineRead(resources_1.ProductResource, {
    source: productSource,
    relations: { inventory },
    limits: resources_1.readLimits,
});
function inspect(entity, query, context) {
    if (entity === "accounts")
        return exports.readAccounts.inspect(query, context);
    if (entity === "orders")
        return exports.readOrders.inspect(query, context);
    return exports.readProducts.inspect(query, context);
}
function executeAdira(entity, query, context) {
    if (entity === "accounts")
        return (0, exports.readAccounts)(query, context);
    if (entity === "orders")
        return (0, exports.readOrders)(query, context);
    return (0, exports.readProducts)(query, context);
}
