import mongoose from "mongoose";
import { workloads, type WorkloadId } from "./fixtures/workloads";
export declare function canonical(value: unknown): string;
export declare const digest: (value: unknown) => string;
export interface Payload {
    rows?: unknown[];
    [key: string]: unknown;
    error?: string;
    message?: string;
    telemetry?: {
        commands: number;
        serverMs: number;
        mongoMs: number;
        dataBytes: number;
        callbacks: Record<string, number>;
        memory: {
            rss: number;
            heapUsed: number;
        };
    };
}
/** Compare business data independently of per-request execution telemetry. */
export declare function responseData({ telemetry: _telemetry, ...data }: Payload): {
    [key: string]: unknown;
    rows?: unknown[];
    error?: string;
    message?: string;
};
export type Backend = "adira" | "adiraBatched" | "reference";
export declare function request(url: string, backend: Backend, workload: (typeof workloads)[number], tenant?: number): Promise<{
    body: Payload;
    elapsedMs: number;
    status: number;
    bytes: number;
}>;
export declare function assertParity(a: Payload, b: Payload, label: string): void;
export declare function runBenchmark(): Promise<{
    createdAt: string;
    environment: {
        node: string;
        mongodb: string;
        os: string;
        cpu: string;
        logicalCpus: number;
        totalMemory: number;
        freeMemory: number;
        startingLoad: number[];
        finishingLoad: number[];
        mongoCacheGB: string | number;
        transport: string;
    };
    metadata: mongoose.mongo.WithId<mongoose.mongo.BSON.Document>;
    sourceHashes: any;
    settings: {
        iterations: number;
        warmups: number;
        concurrency: number[];
        scheduling: string;
    };
    parity: {
        workload: "revenueQuality" | "fulfillment" | "nestedTriage" | "portfolioConcentration" | "directory" | "finances" | "risk" | "account360" | "orderOps" | "replenishment";
        tenant: number;
        rows: number;
        digest: string;
        backends: Backend[];
    }[];
    summaries: Record<string, unknown>[];
    samples: {
        workload: WorkloadId;
        backend: string;
        concurrency: number;
        elapsedMs: number;
        serverMs: number;
        mongoMs: number;
        commands: number;
        bytes: number;
        callbacks: Record<string, number>;
        rss: number;
        heapUsed: number;
        wave: number;
    }[];
    budget: any;
    plans: any;
    explanations: Record<string, unknown>;
    commandTraces: Record<string, unknown>;
    expressivity: ({
        status: number;
        error: any;
        message: any;
        commands: any;
        id: "relationQuantifier";
        query: {
            readonly select: {
                readonly id: true;
            };
            readonly where: {
                readonly orders: {
                    readonly $some: {
                        readonly priority: {
                            readonly $gte: 80;
                        };
                    };
                };
            };
        };
        boundary: "Arbitrary relation quantifiers require a backend-declared predicate.";
    } | {
        status: number;
        error: any;
        message: any;
        commands: any;
        id: "relationAlias";
        query: {
            readonly select: {
                readonly urgentOrders: {
                    readonly select: {
                        readonly id: true;
                    };
                    readonly where: {
                        readonly priority: {
                            readonly $gte: 80;
                        };
                    };
                };
            };
        };
        boundary: "Two differently filtered views of one relation need separate declared relation names or requests.";
    } | {
        status: number;
        error: any;
        message: any;
        commands: any;
        id: "computedArguments";
        query: {
            readonly select: {
                readonly recentOrderAverage: {
                    readonly since: 123;
                };
            };
        };
        boundary: "Computed scalar fields have fixed backend dependencies, without frontend-supplied arguments.";
    } | {
        status: number;
        error: any;
        message: any;
        commands: any;
        id: "arbitraryGrouping";
        query: {
            readonly select: {
                readonly id: true;
            };
            readonly groupBy: readonly ["region"];
        };
        boundary: "Frontend grouping is deliberately outside the REST resource contract.";
    } | {
        status: number;
        error: any;
        message: any;
        commands: any;
        id: "predicateOperand";
        query: {
            readonly select: {
                readonly id: true;
            };
            readonly where: {
                readonly hasRecentEscalation: {
                    readonly $eq: "yes";
                };
            };
        };
        boundary: "Backend-approved predicates still enforce their declared operand types.";
    })[];
    indexes: {
        [key: string]: unknown;
        rows?: unknown[];
        error?: string;
        message?: string;
    };
    eventLoop: {
        meanMs: number;
        p99Ms: number;
    };
    limitations: string[];
}>;
