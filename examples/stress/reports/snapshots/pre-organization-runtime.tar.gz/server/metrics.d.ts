import type { BatchParent } from "@n/adira.backend.ts";
import { type Id } from "./models";
import { type RequestContext } from "./telemetry";
type Input = {
    readonly parents: readonly BatchParent<{
        _id: Id;
    }>[];
    readonly context: RequestContext;
};
export declare const revenueOutput: import("@n/adira.core.ts").ObjectSchema<{
    readonly grossRevenueCents: import("@n/adira.core.ts").ValueSchema<number>;
    readonly refundedCents: import("@n/adira.core.ts").ValueSchema<number>;
    readonly revenueOrderCount: import("@n/adira.core.ts").ValueSchema<number>;
}>;
export declare const Revenue: import("@n/adira.core.ts").ReadResource<{
    readonly grossRevenueCents: import("@n/adira.core.ts").ScalarField<number, never, false>;
    readonly refundedCents: import("@n/adira.core.ts").ScalarField<number, never, false>;
    readonly revenueOrderCount: import("@n/adira.core.ts").ScalarField<number, never, false>;
}, {}>;
export declare function loadRevenue({ parents, context }: Input): Promise<{
    ref: import("@n/adira.backend.ts").BatchParentRef;
    rows: {
        grossRevenueCents: number;
        refundedCents: number;
        revenueOrderCount: number;
    }[];
}[]>;
export declare const costOutput: import("@n/adira.core.ts").ObjectSchema<{
    readonly costCents: import("@n/adira.core.ts").ValueSchema<number>;
}>;
export declare const Cost: import("@n/adira.core.ts").ReadResource<{
    readonly costCents: import("@n/adira.core.ts").ScalarField<number, never, false>;
}, {}>;
export declare function loadCost({ parents, context }: Input): Promise<{
    ref: import("@n/adira.backend.ts").BatchParentRef;
    rows: {
        costCents: number;
    }[];
}[]>;
export declare const stockOutput: import("@n/adira.core.ts").ObjectSchema<{
    readonly onHand: import("@n/adira.core.ts").ValueSchema<number>;
    readonly reserved: import("@n/adira.core.ts").ValueSchema<number>;
    readonly warehouseCount: import("@n/adira.core.ts").ValueSchema<number>;
}>;
export declare const Stock: import("@n/adira.core.ts").ReadResource<{
    readonly onHand: import("@n/adira.core.ts").ScalarField<number, never, false>;
    readonly reserved: import("@n/adira.core.ts").ScalarField<number, never, false>;
    readonly warehouseCount: import("@n/adira.core.ts").ScalarField<number, never, false>;
}, {}>;
export declare function loadStock({ parents, context }: Input): Promise<{
    ref: import("@n/adira.backend.ts").BatchParentRef;
    rows: {
        onHand: number;
        reserved: number;
        warehouseCount: number;
    }[];
}[]>;
export declare const shortageOutput: import("@n/adira.core.ts").ObjectSchema<{
    readonly shortageUnits: import("@n/adira.core.ts").ValueSchema<number>;
}>;
export declare const ShortageSummary: import("@n/adira.core.ts").ReadResource<{
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, never, false>;
}, {}>;
/** Alternative backend modeling: share stock scans across orders in one batch. */
export declare function loadOrderShortages({ parents, context }: Input): Promise<{
    ref: import("@n/adira.backend.ts").BatchParentRef;
    rows: {
        shortageUnits: number;
    }[];
}[]>;
export {};
