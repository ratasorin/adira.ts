type Mode = "adira" | "reference" | "both";
export declare function createApp(mode?: Mode): Promise<import("express-serve-static-core").Express>;
export declare function listen(mode?: Mode, port?: number): Promise<{
    server: import("http").Server<typeof import("http").IncomingMessage, typeof import("http").ServerResponse>;
    url: string;
}>;
export {};
