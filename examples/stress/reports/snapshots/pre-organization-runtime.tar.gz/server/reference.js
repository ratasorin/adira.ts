"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeReference = executeReference;
exports.referenceVolatility = referenceVolatility;
/** Conventional view-specific REST backend. No Adira executor, parser, planner, or query translator. */
const business_1 = require("./business");
const models_1 = require("./models");
const telemetry_1 = require("./telemetry");
const reference_advanced_1 = require("./reference-advanced");
const key = (id) => String(id);
const base = (c) => ({ tenantId: c.tenantId, deletedAt: null });
const byId = (a, b) => a.id.localeCompare(b.id);
const selected = (row, fields) => Object.fromEntries(fields.map((field) => [field, row[field]]));
async function financials(accounts, c, includeCost) {
    const ids = accounts.map((a) => a._id);
    if (!ids.length)
        return new Map();
    const filter = {
        ...base(c),
        accountId: { $in: ids },
        placedAt: { $gte: business_1.SINCE },
        status: { $in: ["paid", "shipped"] },
    };
    const [orders, costs] = await Promise.all([
        models_1.Orders.collection
            .aggregate([
            { $match: filter },
            {
                $group: {
                    _id: "$accountId",
                    gross: { $sum: "$totalCents" },
                    refunded: { $sum: "$refundedCents" },
                    count: { $sum: 1 },
                },
            },
        ])
            .toArray(),
        includeCost
            ? models_1.Lines.collection
                .aggregate([
                { $match: filter },
                { $group: { _id: "$accountId", cost: { $sum: "$costCents" } } },
            ])
                .toArray()
            : Promise.resolve([]),
    ]);
    const revenue = new Map(orders.map((o) => [key(o._id), o])), costMap = new Map(costs.map((o) => [key(o._id), o.cost]));
    return new Map(accounts.map((a) => {
        const value = revenue.get(key(a._id)), net = (value?.gross ?? 0) - (value?.refunded ?? 0), cost = costMap.get(key(a._id)) ?? 0;
        return [
            key(a._id),
            {
                grossRevenueCents: value?.gross ?? 0,
                netRevenueCents: net,
                costCents: cost,
                revenueOrderCount: value?.count ?? 0,
                marginBps: (0, business_1.marginBps)(net, cost),
            },
        ];
    }));
}
async function counts(c, ids) {
    if (!ids.length)
        return {
            tickets: new Map(),
            late: new Map(),
            exposure: new Map(),
        };
    const match = { ...base(c), accountId: { $in: ids } };
    const [tickets, late, exposure] = await Promise.all([
        models_1.Tickets.collection
            .aggregate([
            { $match: { ...match, status: { $in: ["open", "pending"] } } },
            { $group: { _id: "$accountId", count: { $sum: 1 } } },
        ])
            .toArray(),
        models_1.Shipments.collection
            .aggregate([
            { $match: { ...match, late: true } },
            { $group: { _id: "$accountId", count: { $sum: 1 } } },
        ])
            .toArray(),
        models_1.Orders.collection
            .aggregate([
            { $match: { ...match, status: { $in: ["pending", "paid"] } } },
            {
                $group: {
                    _id: "$accountId",
                    count: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
                },
            },
        ])
            .toArray(),
    ]);
    return {
        tickets: new Map(tickets.map((r) => [key(r._id), r.count])),
        late: new Map(late.map((r) => [key(r._id), r.count])),
        exposure: new Map(exposure.map((r) => [key(r._id), r.count])),
    };
}
async function accountMetrics(accounts, c, risk) {
    const [finance, service] = await Promise.all([
        financials(accounts, c, !risk),
        risk
            ? counts(c, accounts.map((a) => a._id))
            : Promise.resolve(null),
    ]);
    return accounts.map((account) => {
        const id = key(account._id), fin = finance.get(id);
        const row = {
            ...account,
            id,
            ...fin,
            openTicketCount: service?.tickets.get(id) ?? 0,
            lateShipmentCount: service?.late.get(id) ?? 0,
            exposureCents: service?.exposure.get(id) ?? 0,
        };
        if (risk)
            (0, telemetry_1.count)(c, "riskScore");
        const score = risk ? (0, business_1.riskScore)(row) : 0;
        return { ...row, riskScore: score, riskBand: (0, business_1.riskBand)(score) };
    });
}
async function inventoryMap(productIds, c, full) {
    if (!productIds.length)
        return new Map();
    const rows = await models_1.Inventories.collection
        .find({ ...base(c), productId: { $in: productIds } })
        .sort({ warehouse: 1, _id: 1 })
        .toArray();
    const result = new Map();
    for (const row of rows) {
        const id = key(row.productId), available = row.onHand - row.reserved;
        (0, telemetry_1.count)(c, "stockStatus");
        const value = full
            ? {
                warehouse: row.warehouse,
                onHand: row.onHand,
                reserved: row.reserved,
                stockStatus: (0, business_1.stockStatus)(available),
            }
            : {
                warehouse: row.warehouse,
                available,
                stockStatus: (0, business_1.stockStatus)(available),
            };
        const list = result.get(id) ?? [];
        list.push(value);
        result.set(id, list);
    }
    return result;
}
async function nestedOrders(rows, c, withAccount) {
    if (!rows.length)
        return [];
    // Windowing keeps the per-parent page in MongoDB instead of loading all order lines.
    const items = await models_1.Lines.collection
        .aggregate([{ $match: { ...base(c), orderId: { $in: rows.map((r) => r._id) } } }, { $setWindowFields: { partitionBy: "$orderId", sortBy: { _id: 1 }, output: { _rank: { $documentNumber: {} } } } }, { $match: { _rank: { $lte: 2 } } }])
        .toArray();
    const productIds = [
        ...new Map(items.map((i) => [key(i.productId), i.productId])).values(),
    ];
    const [products, warehouses, accounts] = await Promise.all([
        models_1.Products.collection
            .find({ ...base(c), _id: { $in: productIds } })
            .toArray(),
        inventoryMap(productIds, c, false),
        withAccount
            ? models_1.Accounts.collection
                .find({
                ...base(c),
                _id: { $in: rows.map((r) => r.accountId) },
            })
                .toArray()
            : Promise.resolve([]),
    ]);
    const productMap = new Map(products.map((p) => [key(p._id), p])), accountMap = new Map(accounts.map((a) => [key(a._id), a]));
    return rows.map((row) => {
        (0, telemetry_1.count)(c, "priority");
        const acct = accountMap.get(key(row.accountId));
        const children = items
            .filter((i) => key(i.orderId) === key(row._id))
            .sort((a, b) => key(a._id).localeCompare(key(b._id)))
            .map((item) => {
            const prod = productMap.get(key(item.productId));
            return {
                quantity: item.quantity,
                marginCents: item.grossCents - item.costCents,
                product: prod
                    ? {
                        sku: prod.sku,
                        inventory: (warehouses.get(key(prod._id)) ?? []).slice(0, 2),
                    }
                    : null,
            };
        });
        const common = {
            id: key(row._id),
            number: row.number,
            netCents: row.totalCents - row.refundedCents,
            priority: (0, business_1.priority)(row.totalCents, row.status, (business_1.AS_OF - row.placedAt) / business_1.DAY),
            items: children,
        };
        return withAccount
            ? {
                ...common,
                status: row.status,
                account: acct ? { name: acct.name, region: acct.region } : null,
            }
            : common;
    });
}
async function account360(c) {
    const accounts = await models_1.Accounts.collection
        .find({ ...base(c), region: "EU" })
        .sort({ name: 1, _id: 1 })
        .limit(12)
        .toArray();
    if (!accounts.length)
        return { rows: [] };
    const ids = accounts.map((a) => a._id), managers = [
        ...new Map(accounts.map((a) => [key(a.managerId), a.managerId])).values(),
    ];
    const [metrics, orders, tickets, agents, portfolio] = await Promise.all([
        accountMetrics(accounts, c, true),
        models_1.Orders.collection
            .aggregate([
            { $match: { ...base(c), accountId: { $in: ids } } },
            {
                $group: {
                    _id: "$accountId",
                    rows: {
                        $topN: {
                            n: 2,
                            sortBy: { placedAt: -1, _id: 1 },
                            output: "$$ROOT",
                        },
                    },
                },
            },
            { $unwind: "$rows" },
            { $replaceWith: "$rows" },
        ])
            .toArray(),
        models_1.Tickets.collection
            .find({
            ...base(c),
            accountId: { $in: ids },
            status: { $in: ["open", "pending"] },
        })
            .sort({ priority: -1, _id: 1 })
            .toArray(),
        models_1.Agents.collection
            .find({ ...base(c), _id: { $in: managers } })
            .toArray(),
        models_1.Orders.collection
            .aggregate([
            {
                $match: {
                    ...base(c),
                    managerId: { $in: managers },
                    placedAt: { $gte: business_1.SINCE },
                    status: { $in: ["paid", "shipped"] },
                },
            },
            {
                $group: {
                    _id: "$managerId",
                    total: { $sum: { $subtract: ["$totalCents", "$refundedCents"] } },
                },
            },
        ])
            .toArray(),
    ]);
    const enriched = await nestedOrders(orders, c, false), orderMap = new Map(orders.map((o, i) => [key(o._id), enriched[i]]));
    const agentMap = new Map(agents.map((a) => [key(a._id), a.name])), portfolioMap = new Map(portfolio.map((r) => [key(r._id), r.total]));
    return {
        rows: metrics.map((row) => ({
            id: row.id,
            name: row.name,
            netRevenueCents: row.netRevenueCents,
            riskScore: row.riskScore,
            managerRevenueCents: portfolioMap.get(key(row.managerId)) ?? 0,
            manager: agentMap.has(key(row.managerId))
                ? { name: agentMap.get(key(row.managerId)) }
                : null,
            orders: orders
                .filter((o) => key(o.accountId) === row.id)
                .sort((a, b) => b.placedAt - a.placedAt || key(a._id).localeCompare(key(b._id)))
                .map((o) => orderMap.get(key(o._id))),
            tickets: tickets
                .filter((t) => key(t.accountId) === row.id)
                .slice(0, 2)
                .map((t) => ({ subject: t.subject, priority: t.priority })),
        })),
    };
}
async function replenishment(c) {
    const products = await models_1.Products.collection
        .find({ ...base(c), category: "hardware", active: true })
        .toArray();
    if (!products.length)
        return { rows: [] };
    const ids = products.map((p) => p._id);
    const [stock, sold] = await Promise.all([
        models_1.Inventories.collection
            .aggregate([
            { $match: { ...base(c), productId: { $in: ids } } },
            {
                $group: {
                    _id: "$productId",
                    available: { $sum: { $subtract: ["$onHand", "$reserved"] } },
                    count: { $sum: 1 },
                },
            },
        ])
            .toArray(),
        models_1.Lines.collection
            .aggregate([
            {
                $match: {
                    ...base(c),
                    productId: { $in: ids },
                    placedAt: { $gte: business_1.SINCE },
                    status: { $in: ["paid", "shipped"] },
                },
            },
            { $group: { _id: "$productId", sold: { $sum: "$quantity" } } },
        ])
            .toArray(),
    ]);
    const stockMap = new Map(stock.map((r) => [key(r._id), r])), soldMap = new Map(sold.map((r) => [key(r._id), r.sold]));
    const candidates = products.map((p) => {
        const id = key(p._id), value = stockMap.get(id), unitsSold = soldMap.get(id) ?? 0, available = value?.available ?? 0;
        (0, telemetry_1.count)(c, "daysCover");
        return {
            id,
            name: p.name,
            sku: p.sku,
            available,
            unitsSold,
            warehouseCount: value?.count ?? 0,
            daysCover: (0, business_1.daysCover)(available, unitsSold),
            _id: p._id,
        };
    });
    const selectedRows = candidates
        .filter((p) => p.daysCover < 60 || p.available < 0)
        .sort((a, b) => a.daysCover - b.daysCover || byId(a, b))
        .slice(0, 25);
    const warehouses = await inventoryMap(selectedRows.map((p) => p._id), c, true);
    return {
        rows: selectedRows.map(({ _id, ...row }) => ({
            ...row,
            inventory: (warehouses.get(row.id) ?? []).slice(0, 2),
        })),
    };
}
async function executeReference(view, c) {
    if (view === "revenueQuality")
        return (0, reference_advanced_1.referenceRevenueQuality)(c);
    if (view === "fulfillment")
        return (0, reference_advanced_1.referenceFulfillment)(c);
    if (view === "nestedTriage")
        return (0, reference_advanced_1.referenceNestedTriage)(c);
    if (view === "portfolioConcentration")
        return (0, reference_advanced_1.referencePortfolio)(c);
    if (view === "account360")
        return account360(c);
    if (view === "replenishment")
        return replenishment(c);
    if (view === "orderOps") {
        const candidates = await models_1.Orders.collection
            .find({
            ...base(c),
            region: "EU",
            placedAt: { $gte: business_1.AS_OF - 30 * business_1.DAY },
            status: { $ne: "cancelled" },
        })
            .toArray();
        const chosen = candidates
            .map((row) => {
            (0, telemetry_1.count)(c, "priority");
            return {
                ...row,
                id: key(row._id),
                priority: (0, business_1.priority)(row.totalCents, row.status, (business_1.AS_OF - row.placedAt) / business_1.DAY),
            };
        })
            .filter((row) => row.status === "pending" || row.priority >= 65)
            .sort((a, b) => b.priority - a.priority || byId(a, b))
            .slice(0, 20);
        return { rows: await nestedOrders(chosen, c, true) };
    }
    const filter = {
        ...base(c),
        region: { $in: ["EU", "NA"] },
        tier: { $ne: "starter" },
    };
    if (view === "directory") {
        const accounts = await models_1.Accounts.collection
            .find(filter, { projection: { name: 1, tier: 1, region: 1 } })
            .sort({ name: 1, _id: 1 })
            .limit(40)
            .toArray();
        return {
            rows: accounts.map((a) => ({
                id: key(a._id),
                name: a.name,
                tier: a.tier,
                region: a.region,
            })),
        };
    }
    const accounts = await models_1.Accounts.collection
        .find(filter)
        .sort({ name: 1, _id: 1 })
        .toArray();
    const rows = await accountMetrics(accounts, c, view === "risk");
    if (view === "finances")
        return {
            rows: rows
                .filter((r) => r.netRevenueCents >= 10_000)
                .sort((a, b) => b.netRevenueCents - a.netRevenueCents || byId(a, b))
                .slice(0, 30)
                .map((r) => selected(r, [
                "id",
                "name",
                "tier",
                "netRevenueCents",
                "revenueOrderCount",
                "marginBps",
            ])),
        };
    return {
        rows: rows
            .filter((r) => r.riskScore >= 45 || r.openTicketCount >= 4)
            .sort((a, b) => b.riskScore - a.riskScore || byId(a, b))
            .slice(0, 25)
            .map((r) => selected(r, [
            "id",
            "name",
            "region",
            "netRevenueCents",
            "openTicketCount",
            "lateShipmentCount",
            "riskScore",
            "riskBand",
        ])),
    };
}
async function referenceVolatility(accountId, c) {
    const orders = await models_1.Orders.collection
        .find({ ...base(c), accountId, placedAt: { $gte: business_1.SINCE } })
        .project({ totalCents: 1, refundedCents: 1, placedAt: 1, status: 1 })
        .toArray();
    return {
        candidates: orders.length,
        value: (0, business_1.volatility)(orders.map((o) => o.totalCents - o.refundedCents)),
        priorityTop2: orders
            .map((o) => ({
            id: key(o._id),
            priority: (0, business_1.priority)(o.totalCents, o.status, (business_1.AS_OF - o.placedAt) / business_1.DAY),
        }))
            .sort((a, b) => b.priority - a.priority || byId(a, b))
            .slice(0, 2),
    };
}
