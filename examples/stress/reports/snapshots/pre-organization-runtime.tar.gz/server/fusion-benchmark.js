"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.runFusionBenchmark = runFusionBenchmark;
/** Paired executor comparison. Capture the old compiled reader before rebuilding. */
const express_1 = __importDefault(require("express"));
const mongoose_1 = __importDefault(require("mongoose"));
const strict_1 = __importDefault(require("node:assert/strict"));
const node_crypto_1 = require("node:crypto");
const promises_1 = require("node:fs/promises");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const node_perf_hooks_1 = require("node:perf_hooks");
const workloads_1 = require("./fixtures/workloads");
const adira_1 = require("./adira");
const benchmark_1 = require("./benchmark");
const adira_core_ts_1 = require("@n/adira.core.ts");
const models_1 = require("./models");
const mongo_1 = require("./mongo");
const reference_1 = require("./reference");
const seed_1 = require("./seed");
const telemetry_1 = require("./telemetry");
const variants = ["before", "after", "reference"];
const capturedSources = [
    "packages/backend/read/execute.ts",
    "packages/core/src/read/query.ts",
    "examples/stress/server/adira.ts",
    "examples/stress/server/metrics.ts",
    "examples/stress/server/fixtures/advanced-workloads.ts",
];
const hashFile = async (path) => (0, node_crypto_1.createHash)("sha256")
    .update(await (0, promises_1.readFile)(path))
    .digest("hex");
const percentile = (values, p) => {
    const sorted = [...values].sort((a, b) => a - b);
    return sorted[Math.min(sorted.length - 1, Math.ceil(sorted.length * p) - 1)];
};
async function runFusionBenchmark() {
    const root = (0, node_path_1.resolve)(__dirname, "../../../..");
    const manifest = (0, node_path_1.resolve)((0, seed_1.option)("baseline", (0, node_path_1.resolve)(root, "node_modules/.adira-fusion-baseline.json")));
    if (process.argv.includes("--capture-baseline")) {
        const directory = await (0, promises_1.mkdtemp)((0, node_path_1.resolve)(root, "node_modules/.adira-fusion-baseline."));
        await (0, promises_1.cp)((0, node_path_1.resolve)(root, "packages/backend/dist/read"), (0, node_path_1.resolve)(directory, "read"), { recursive: true });
        const demoModule = (0, node_path_1.resolve)(root, "examples/stress/dist/server", `adira-before-fusion${(0, node_path_1.basename)(directory)}.js`);
        await (0, promises_1.cp)((0, node_path_1.resolve)(root, "examples/stress/dist/server/adira.js"), demoModule);
        const capture = {
            readModule: (0, node_path_1.resolve)(directory, "read/index.js"),
            demoModule,
            sources: Object.fromEntries(await Promise.all(capturedSources.map(async (p) => [
                p,
                await hashFile((0, node_path_1.resolve)(root, p)),
            ]))),
        };
        await (0, promises_1.writeFile)(manifest, JSON.stringify(capture, null, 2) + "\n");
        console.log(`Captured the currently built reader: ${manifest}`);
        return;
    }
    const baseline = JSON.parse(await (0, promises_1.readFile)(manifest, "utf8"));
    // The captured demo keeps its original relative imports (models, policies,
    // callbacks). Only its Adira reader import points to the captured executor.
    let code = await (0, promises_1.readFile)(baseline.demoModule, "utf8");
    code = code.replace('require("@n/adira.backend.ts")', `require(${JSON.stringify(baseline.readModule)})`);
    strict_1.default.ok(code.includes(`require(${JSON.stringify(baseline.readModule)})`));
    await (0, promises_1.writeFile)(baseline.demoModule, code);
    const before = require(baseline.demoModule);
    for (const [path, expected] of Object.entries(baseline.sources))
        if (path.startsWith("examples/stress/"))
            strict_1.default.equal(await hashFile((0, node_path_1.resolve)(root, path)), expected, `${path} changed`);
    const profile = (0, seed_1.option)("profile", "medium");
    strict_1.default.ok(Object.hasOwn(seed_1.profiles, profile), "Unknown profile");
    const iterations = Number((0, seed_1.option)("iterations", "12"));
    const warmups = Number((0, seed_1.option)("warmup", "2"));
    const concurrency = (0, seed_1.option)("concurrency", "1,4").split(",").map(Number);
    strict_1.default.ok(Number.isInteger(iterations) && iterations > 0);
    strict_1.default.ok(Number.isInteger(warmups) && warmups >= 0);
    strict_1.default.ok(concurrency.every((c) => Number.isInteger(c) && c > 0 && c <= 64));
    const chosen = (0, seed_1.option)("workloads");
    const cases = chosen
        ? workloads_1.workloads.filter((w) => chosen.split(",").includes(w.id))
        : workloads_1.workloads;
    strict_1.default.ok(cases.length, "No matching workloads");
    const database = await (0, mongo_1.temporaryMongo)();
    let server;
    const run = (variant, workload, query, context) => variant === "reference"
        ? (0, reference_1.executeReference)(workload.id, context)
        : (variant === "before" ? before.executeAdira : adira_1.executeAdira)(workload.entity, query, context);
    try {
        await (0, models_1.connect)(database.uri);
        await (0, seed_1.seed)(profile, false);
        const metadata = await mongoose_1.default.connection
            .db.collection("stress_metadata")
            .findOne({ _id: "dataset" });
        strict_1.default.ok(metadata);
        const tenants = metadata.config.tenants;
        (0, telemetry_1.monitor)();
        const app = (0, express_1.default)();
        app.disable("x-powered-by");
        app.get("/bench/:variant/:view", async (req, res) => {
            try {
                const variant = req.params.variant;
                const workload = cases.find((w) => w.id === req.params.view);
                const tenant = Number(req.header("x-tenant-index") ?? 0);
                strict_1.default.ok(variants.includes(variant) && workload);
                strict_1.default.ok(Number.isInteger(tenant) && tenant >= 0 && tenant < tenants);
                const context = { tenantId: (0, seed_1.oid)(1, tenant, 0), trace: (0, telemetry_1.newTrace)() };
                const output = await telemetry_1.traces.run(context.trace, () => run(variant, workload, variant === "reference"
                    ? undefined
                    : JSON.parse(String(req.query.query)), context));
                res.json({
                    ...(0, adira_core_ts_1.readRecord)(output, "response data"),
                    telemetry: {
                        serverMs: node_perf_hooks_1.performance.now() - context.trace.started,
                        mongoMs: context.trace.mongoMs,
                        commands: context.trace.commands,
                        callbacks: context.trace.callbacks,
                        dataBytes: Buffer.byteLength(JSON.stringify(output)),
                        memory: process.memoryUsage(),
                    },
                });
            }
            catch (error) {
                res.status(500).json({ error: String(error) });
            }
        });
        server = app.listen(0, "127.0.0.1");
        await new Promise((done, reject) => {
            server.once("listening", done);
            server.once("error", reject);
        });
        const url = `http://127.0.0.1:${server.address().port}`;
        const request = async (variant, workload, tenant = 0) => {
            const start = node_perf_hooks_1.performance.now();
            const response = await fetch(`${url}/bench/${variant}/${workload.id}?query=${encodeURIComponent(JSON.stringify(workload.query))}`, {
                headers: { "x-tenant-index": String(tenant) },
                signal: AbortSignal.timeout(120_000),
            });
            const body = (await response.json());
            strict_1.default.equal(response.status, 200, JSON.stringify(body));
            strict_1.default.ok(!body.error && body.rows && body.telemetry, JSON.stringify(body));
            return { body, elapsedMs: node_perf_hooks_1.performance.now() - start };
        };
        const parity = [];
        const expected = new Map();
        for (const workload of cases)
            for (const tenant of new Set([0, tenants - 1])) {
                const results = [];
                for (const variant of variants)
                    results.push(await request(variant, workload, tenant));
                const output = (0, benchmark_1.digest)((0, benchmark_1.responseData)(results[2].body));
                for (const result of results)
                    strict_1.default.equal((0, benchmark_1.digest)((0, benchmark_1.responseData)(result.body)), output);
                strict_1.default.deepEqual(results[0].body.telemetry.callbacks, results[1].body.telemetry.callbacks);
                expected.set(`${workload.id}/${tenant}`, output);
                parity.push({
                    workload: workload.id,
                    tenant,
                    rows: results[0].body.rows.length,
                    digest: output,
                });
                console.log(`Parity ${workload.id}/tenant-${tenant}: all three executors agree`);
            }
        const samples = [];
        const summaries = [];
        const startingLoad = (0, node_os_1.loadavg)();
        for (const [caseIndex, workload] of cases.entries()) {
            const check = (body) => strict_1.default.equal((0, benchmark_1.digest)((0, benchmark_1.responseData)(body)), expected.get(`${workload.id}/0`));
            for (let i = 0; i < warmups; i++)
                for (const variant of variants)
                    check((await request(variant, workload)).body);
            for (const workers of concurrency) {
                const collected = {
                    before: [],
                    after: [],
                    reference: [],
                };
                for (let offset = 0, wave = 0; offset < iterations; offset += workers, wave++) {
                    for (let slot = 0; slot < variants.length; slot++) {
                        const variant = variants[(caseIndex + wave + slot) % variants.length];
                        const values = await Promise.all(Array.from({ length: Math.min(workers, iterations - offset) }, async () => {
                            const { body, elapsedMs } = await request(variant, workload);
                            check(body);
                            const t = body.telemetry;
                            return {
                                workload: workload.id,
                                variant,
                                concurrency: workers,
                                wave,
                                elapsedMs,
                                serverMs: t.serverMs,
                                mongoMs: t.mongoMs,
                                commands: t.commands,
                                callbacks: t.callbacks,
                            };
                        }));
                        collected[variant].push(...values);
                    }
                }
                for (const variant of variants) {
                    const group = collected[variant];
                    samples.push(...group);
                    const mean = (key) => group.reduce((sum, s) => sum + s[key], 0) / group.length;
                    const summary = {
                        workload: workload.id,
                        variant,
                        concurrency: workers,
                        samples: group.length,
                        p50Ms: percentile(group.map((s) => s.elapsedMs), 0.5),
                        p95Ms: percentile(group.map((s) => s.elapsedMs), 0.95),
                        meanServerMs: mean("serverMs"),
                        meanMongoMs: mean("mongoMs"),
                        meanCommands: mean("commands"),
                    };
                    summaries.push(summary);
                    console.log(`${workload.id} ${variant} c=${workers}: p50=${summary.p50Ms.toFixed(1)}ms p95=${summary.p95Ms.toFixed(1)}ms commands=${summary.meanCommands}`);
                }
            }
        }
        const finishingLoad = (0, node_os_1.loadavg)();
        // Capture plans and actual commands only after timing, to avoid trace overhead.
        const plans = {};
        const commands = {};
        for (const workload of cases) {
            for (const variant of ["before", "after"])
                plans[`${workload.id}/${variant}`] = (variant === "before" ? before.inspect : adira_1.inspect)(workload.entity, workload.query, {
                    tenantId: (0, seed_1.oid)(1, 0, 0),
                    trace: (0, telemetry_1.newTrace)(),
                });
            for (const variant of variants) {
                const context = {
                    tenantId: (0, seed_1.oid)(1, 0, 0),
                    trace: (0, telemetry_1.newTrace)(),
                };
                context.trace.details = [];
                const output = await telemetry_1.traces.run(context.trace, () => run(variant, workload, workload.query, context));
                strict_1.default.equal((0, benchmark_1.digest)(output), expected.get(`${workload.id}/0`));
                commands[`${workload.id}/${variant}`] = context.trace;
            }
        }
        const paths = [
            "packages/backend/read/execute.ts",
            "packages/core/src/read/query.ts",
            "examples/stress/server/adira.ts",
            "examples/stress/server/metrics.ts",
            "examples/stress/server/native-fields.ts",
            "examples/stress/server/reference.ts",
            "examples/stress/server/reference-advanced.ts",
            "examples/stress/server/fusion-benchmark.ts",
            "examples/stress/server/fixtures/workloads.ts",
            "examples/stress/server/fixtures/advanced-workloads.ts",
        ];
        const report = {
            createdAt: new Date().toISOString(),
            metadata,
            environment: {
                node: process.version,
                mongodb: (await mongoose_1.default.connection.db.admin().buildInfo()).version,
                os: `${(0, node_os_1.platform)()} ${(0, node_os_1.release)()}`,
                cpu: (0, node_os_1.cpus)()[0]?.model,
                logicalCpus: (0, node_os_1.cpus)().length,
                startingLoad,
                finishingLoad,
                mongoCacheGB: 0.25,
                transport: "HTTP loopback; before, after and native reference share one Node process and Mongo pool; Adira queries are JSON decoded from the URL",
            },
            settings: {
                iterations,
                warmups,
                concurrency,
                scheduling: "Cyclic variant order after every wave, no mixed-variant contention",
            },
            baseline: {
                ...baseline,
                readModuleSha256: await hashFile(baseline.readModule),
                executorSha256: await hashFile((0, node_path_1.resolve)(baseline.readModule, "../execute.js")),
                demoModuleSha256: await hashFile(baseline.demoModule),
            },
            sourceHashes: Object.fromEntries(await Promise.all(paths.map(async (p) => [p, await hashFile((0, node_path_1.resolve)(root, p))]))),
            parity,
            summaries,
            samples,
            plans,
            commands,
            limitations: [
                "Local synthetic data, warm caches, small fixed-wave samples; not a production capacity claim",
                "All three executors share a process, driver pool and database; variant order rotates but no cold-cache isolation",
                "The native reference is hand-optimized for fixed dashboard views",
                "Per-request summed Mongo durations can overlap; p95 estimates need more samples for stability",
                "Captured pre-change reader shares unchanged demo models, policies and callbacks with the current implementation",
            ],
        };
        const output = (0, node_path_1.resolve)((0, seed_1.option)("output", (0, node_path_1.resolve)(root, "examples/stress/reports/reduction-fusion-paired")));
        await (0, promises_1.mkdir)(output, { recursive: true });
        await (0, promises_1.writeFile)((0, node_path_1.resolve)(output, "report.json"), JSON.stringify(report, null, 2) + "\n");
        const markdown = [
            "# Compatible native reduction fusion — paired benchmark",
            "",
            `${Object.values(metadata.counts)
                .reduce((sum, n) => sum + n, 0)
                .toLocaleString()} documents; ${parity.length} tenant/workload parity checks across all three executors. ${samples.length} measured responses also matched.`,
            "",
            "The same backend declarations and frontend queries run against a captured pre-change reader, the new reader, and the optimized native reference. Cyclic variant order, warm caches, one private MongoDB process. Times include HTTP and query decoding.",
            "",
        ];
        for (const workers of concurrency) {
            markdown.push(`## Concurrency ${workers}`, "", "| Workload | Before p50 ms | After p50 ms | Native p50 ms | Before/after | Commands before → after / native |", "|---|---:|---:|---:|---:|---:|");
            for (const workload of cases) {
                const rows = variants.map((v) => summaries.find((s) => s.workload === workload.id &&
                    s.concurrency === workers &&
                    s.variant === v));
                markdown.push(`| ${workload.id} | ${rows[0].p50Ms.toFixed(1)} | ${rows[1].p50Ms.toFixed(1)} | ${rows[2].p50Ms.toFixed(1)} | ${(rows[0].p50Ms / rows[1].p50Ms).toFixed(2)}× | ${rows[0].meanCommands} → ${rows[1].meanCommands} / ${rows[2].meanCommands} |`);
            }
            markdown.push("");
        }
        markdown.push("## Limits", "", ...report.limitations.map((s) => `- ${s}`), "", "See report.json for raw samples, source hashes, plans and untimed command traces.", "");
        await (0, promises_1.writeFile)((0, node_path_1.resolve)(output, "report.md"), markdown.join("\n"));
        console.log(`Saved ${output}`);
    }
    finally {
        if (server)
            await new Promise((done) => server.close(() => done()));
        await mongoose_1.default.disconnect();
        await database.stop();
    }
}
if (require.main === module)
    runFusionBenchmark().catch((error) => {
        console.error(error);
        process.exitCode = 1;
    });
