"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkIntermediates = checkIntermediates;
exports.checkCustomProviderContract = checkCustomProviderContract;
const models_1 = require("./models");
const adira_backend_ts_1 = require("@n/adira.backend.ts");
const adira_core_ts_1 = require("@n/adira.core.ts");
function checkIntermediates(row, line) {
    // @ts-expect-error The native output schema infers a number.
    const badNative = line.shortageUnits;
    // @ts-expect-error A missing relation remains nullable after a typed batch load.
    const badLoaded = row.portfolio.revenueCents;
    // @ts-expect-error The complete statistics do not expose arbitrary selected order columns.
    row.latestPaidOrder?.number;
    return { badNative, badLoaded };
}
function checkCustomProviderContract() {
    return (0, adira_backend_ts_1.createReadContext)()
        .mongo.from(models_1.Accounts)
        .related({
        requires: ["managerId"],
        output: adira_core_ts_1.schema.object({ amount: adira_core_ts_1.schema.number() }),
        resolveBatch: async (input) => {
            const tenant = input.context.tenantId;
            // @ts-expect-error Custom providers receive parents and context, without query intent.
            input.query;
            return input.parents.map(({ ref, row }) => {
                const manager = row.managerId;
                // @ts-expect-error Provider inputs contain only declared requirements.
                row.creditLimitCents;
                return { ref, rows: [{ amount: manager.equals(tenant) ? 1 : 0 }] };
            });
        },
    });
}
