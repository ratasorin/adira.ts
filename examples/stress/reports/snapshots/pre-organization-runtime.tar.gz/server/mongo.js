"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.temporaryMongo = temporaryMongo;
const node_child_process_1 = require("node:child_process");
const promises_1 = require("node:fs/promises");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const node_net_1 = require("node:net");
async function temporaryMongo() {
    const port = await new Promise((resolve, reject) => {
        const s = (0, node_net_1.createServer)();
        s.once("error", reject);
        s.listen(0, "127.0.0.1", () => {
            const address = s.address();
            if (!address || typeof address === "string")
                return reject(new Error("No port"));
            s.close((error) => (error ? reject(error) : resolve(address.port)));
        });
    });
    const directory = await (0, promises_1.mkdtemp)((0, node_path_1.join)((0, node_os_1.tmpdir)(), "adira-stress-"));
    let child;
    const stop = async () => {
        if (child?.pid && child.exitCode === null && child.signalCode === null)
            await new Promise((resolve) => {
                child.once("exit", () => resolve());
                child.kill("SIGTERM");
            });
        await (0, promises_1.rm)(directory, { recursive: true, force: true });
    };
    try {
        await new Promise((resolve, reject) => {
            let logs = "";
            const timeout = setTimeout(() => reject(new Error(`Mongo startup timed out: ${logs}`)), 20000);
            child = (0, node_child_process_1.spawn)(process.env.MONGOD_BINARY ?? "mongod", [
                "--dbpath",
                directory,
                "--bind_ip",
                "127.0.0.1",
                "--port",
                String(port),
                "--nounixsocket",
                "--wiredTigerCacheSizeGB",
                "0.25",
                "--setParameter",
                "diagnosticDataCollectionEnabled=false",
            ], { stdio: ["ignore", "pipe", "pipe"] });
            child.once("error", (error) => {
                clearTimeout(timeout);
                reject(error);
            });
            child.once("exit", (code) => {
                clearTimeout(timeout);
                reject(new Error(`Mongo exited ${code}: ${logs}`));
            });
            const read = (chunk) => {
                logs = (logs + String(chunk)).slice(-5000);
                if (logs.includes("Waiting for connections")) {
                    clearTimeout(timeout);
                    resolve();
                }
            };
            child.stdout.on("data", read);
            child.stderr.on("data", read);
        });
        return { uri: `mongodb://127.0.0.1:${port}/adira_stress_temporary`, stop };
    }
    catch (error) {
        await stop();
        throw error;
    }
}
