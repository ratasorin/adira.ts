export declare function runFusionBenchmark(): Promise<void>;
