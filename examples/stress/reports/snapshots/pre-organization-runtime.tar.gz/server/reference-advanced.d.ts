/** Fixed-view native references. No Adira runtime or query translation is used here. */
import type { ReadData } from "@n/adira.core.ts";
import type { AccountResource, OrderResource } from "./resources";
import type { revenueQuality, fulfillment, nestedTriage, portfolioConcentration } from "./fixtures/advanced-workloads";
import { type RequestContext } from "./telemetry";
export declare function referenceRevenueQuality(c: RequestContext): Promise<ReadData<typeof AccountResource, typeof revenueQuality>>;
export declare function referenceFulfillment(c: RequestContext): Promise<ReadData<typeof OrderResource, typeof fulfillment>>;
export declare function referencePortfolio(c: RequestContext): Promise<ReadData<typeof AccountResource, typeof portfolioConcentration>>;
export declare const nativePriority: {
    $min: (number | {
        $floor: {
            $add: (number | {
                $add: ({
                    $multiply: (number | {
                        $log: (number | {
                            $add: (number | {
                                $divide: (string | number)[];
                            })[];
                        })[];
                    })[];
                    $cond?: undefined;
                    $min?: undefined;
                } | {
                    $cond: (number | {
                        $eq: string[];
                    })[];
                    $multiply?: undefined;
                    $min?: undefined;
                } | {
                    $min: (number | {
                        $multiply: (number | {
                            $divide: (number | {
                                $subtract: (string | number)[];
                            })[];
                        })[];
                    })[];
                    $multiply?: undefined;
                    $cond?: undefined;
                })[];
            })[];
        };
    })[];
};
export declare function referenceNestedTriage(c: RequestContext): Promise<ReadData<typeof AccountResource, typeof nestedTriage>>;
