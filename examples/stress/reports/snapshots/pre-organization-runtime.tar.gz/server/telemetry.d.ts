import { AsyncLocalStorage } from "node:async_hooks";
import { Types } from "mongoose";
export interface CommandDetail {
    name: string;
    collection?: string;
    pipeline?: unknown;
    filter?: unknown;
    sort?: unknown;
    projection?: unknown;
    durationMs?: number;
    returned?: number;
}
export interface Trace {
    commands: number;
    mongoMs: number;
    commandNames: Record<string, number>;
    callbacks: Record<string, number>;
    started: number;
    /** Enabled only for untimed developer diagnostics. */
    details?: CommandDetail[];
}
export interface RequestContext {
    tenantId: Types.ObjectId;
    trace: Trace;
}
export declare const traces: AsyncLocalStorage<Trace>;
export declare const newTrace: () => Trace;
export declare function count(context: RequestContext, key: string, n?: number): void;
export declare function monitor(): void;
