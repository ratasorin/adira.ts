"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.datasetWindow = exports.workloads = exports.history = exports.replenishment = exports.orderOps = exports.account360 = exports.risk = exports.finances = exports.directory = void 0;
const advanced_workloads_1 = require("./advanced-workloads");
const business_1 = require("../business");
exports.directory = {
    select: { id: true, name: true, tier: true, region: true },
    where: {
        $and: [
            { region: { $in: ["EU", "NA"] } },
            { $not: { tier: { $eq: "starter" } } },
        ],
    },
    orderBy: { name: "asc", id: "asc" },
    page: { limit: 40 },
};
exports.finances = {
    select: {
        id: true,
        name: true,
        tier: true,
        netRevenueCents: true,
        revenueOrderCount: true,
        marginBps: true,
    },
    where: {
        $and: [
            { region: { $in: ["EU", "NA"] } },
            { tier: { $in: ["growth", "enterprise"] } },
            { netRevenueCents: { $gte: 10_000 } },
        ],
    },
    orderBy: { netRevenueCents: "desc", id: "asc" },
    page: { limit: 30 },
};
exports.risk = {
    select: {
        id: true,
        name: true,
        region: true,
        netRevenueCents: true,
        openTicketCount: true,
        lateShipmentCount: true,
        riskScore: true,
        riskBand: true,
    },
    where: {
        $and: [
            { region: { $in: ["EU", "NA"] } },
            { $or: [{ riskScore: { $gte: 45 } }, { openTicketCount: { $gte: 4 } }] },
            { $not: { tier: { $eq: "starter" } } },
        ],
    },
    orderBy: { riskScore: "desc", id: "asc" },
    page: { limit: 25 },
};
exports.account360 = {
    select: {
        id: true,
        name: true,
        netRevenueCents: true,
        riskScore: true,
        managerRevenueCents: true,
        manager: { select: { name: true } },
        orders: {
            select: {
                id: true,
                number: true,
                netCents: true,
                priority: true,
                items: {
                    select: {
                        quantity: true,
                        marginCents: true,
                        product: {
                            select: {
                                sku: true,
                                inventory: {
                                    select: {
                                        warehouse: true,
                                        available: true,
                                        stockStatus: true,
                                    },
                                    orderBy: { warehouse: "asc", id: "asc" },
                                    page: { limit: 2 },
                                },
                            },
                        },
                    },
                    orderBy: { id: "asc" },
                    page: { limit: 2 },
                },
            },
            orderBy: { placedAt: "desc", id: "asc" },
            page: { limit: 2 },
        },
        tickets: {
            select: { subject: true, priority: true },
            where: { status: { $in: ["open", "pending"] } },
            orderBy: { priority: "desc", id: "asc" },
            page: { limit: 2 },
        },
    },
    where: { region: { $eq: "EU" } },
    orderBy: { name: "asc", id: "asc" },
    page: { limit: 12 },
};
exports.orderOps = {
    select: {
        id: true,
        number: true,
        status: true,
        netCents: true,
        priority: true,
        account: { select: { name: true, region: true } },
        items: {
            select: {
                quantity: true,
                marginCents: true,
                product: {
                    select: {
                        sku: true,
                        inventory: {
                            select: { warehouse: true, available: true, stockStatus: true },
                            orderBy: { warehouse: "asc", id: "asc" },
                            page: { limit: 2 },
                        },
                    },
                },
            },
            orderBy: { id: "asc" },
            page: { limit: 2 },
        },
    },
    where: {
        $and: [
            { region: { $eq: "EU" } },
            { placedAt: { $gte: business_1.AS_OF - 30 * business_1.DAY } },
            { $or: [{ status: { $eq: "pending" } }, { priority: { $gte: 65 } }] },
            { $not: { status: { $eq: "cancelled" } } },
        ],
    },
    orderBy: { priority: "desc", id: "asc" },
    page: { limit: 20 },
};
exports.replenishment = {
    select: {
        id: true,
        name: true,
        sku: true,
        available: true,
        unitsSold: true,
        warehouseCount: true,
        daysCover: true,
        inventory: {
            select: {
                warehouse: true,
                onHand: true,
                reserved: true,
                stockStatus: true,
            },
            orderBy: { warehouse: "asc", id: "asc" },
            page: { limit: 2 },
        },
    },
    where: {
        $and: [
            { category: { $eq: "hardware" } },
            { active: { $eq: true } },
            { $or: [{ daysCover: { $lt: 60 } }, { available: { $lt: 0 } }] },
        ],
    },
    orderBy: { daysCover: "asc", id: "asc" },
    page: { limit: 25 },
};
exports.history = {
    select: { id: true, name: true, orderVolatility: true },
    where: { id: { $eq: "030000000000000000000000" } },
    page: { limit: 1 },
};
// The budget diagnostic constructs this query using the selected tenant's whale account.
exports.workloads = [
    {
        id: "directory",
        title: "Account directory",
        entity: "accounts",
        query: exports.directory,
        description: "Native filters and pagination; expensive fields should be pruned.",
    },
    {
        id: "finances",
        title: "Revenue & margin",
        entity: "accounts",
        query: exports.finances,
        description: "Bulk revenue and cost aggregates through typed batch resolvers; JavaScript margin after pagination.",
    },
    {
        id: "risk",
        title: "Service risk",
        entity: "accounts",
        query: exports.risk,
        description: "Nested AND/OR/NOT; bulk finance, prebuilt counts, resolveBatch exposure and JavaScript filtering/sorting.",
    },
    {
        id: "account360",
        title: "Account 360°",
        entity: "accounts",
        query: exports.account360,
        description: "Paged parents; nested orders → items → product → inventory; custom shared manager aggregates.",
    },
    {
        id: "orderOps",
        title: "Order operations",
        entity: "orders",
        query: exports.orderOps,
        description: "Mixed native/JavaScript predicates; account include and three nested relation levels.",
    },
    {
        id: "replenishment",
        title: "Replenishment",
        entity: "products",
        query: exports.replenishment,
        description: "Shared stock totals and warehouse count, prebuilt sales sum, JavaScript days of cover and nested warehouses.",
    },
    ...advanced_workloads_1.advancedWorkloads,
];
exports.datasetWindow = { asOf: business_1.AS_OF, since: business_1.SINCE };
