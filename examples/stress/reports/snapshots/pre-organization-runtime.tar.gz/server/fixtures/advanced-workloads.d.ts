export declare const revenueQuality: {
    readonly select: {
        readonly id: true;
        readonly name: true;
        readonly recentOrderCount: true;
        readonly recentOrderAverage: true;
        readonly recentOrderMin: true;
        readonly recentOrderMax: true;
        readonly latestPaidOrderCents: true;
        readonly marginBps: true;
        readonly orders: {
            readonly select: {
                readonly id: true;
                readonly netCents: true;
                readonly priority: true;
            };
            readonly where: {
                readonly placedAt: {
                    readonly $gte: number;
                };
                readonly status: {
                    readonly $in: readonly ["paid", "shipped"];
                };
            };
            readonly orderBy: {
                readonly netCents: "desc";
                readonly id: "asc";
            };
            readonly page: {
                readonly offset: 1;
                readonly limit: 2;
            };
        };
    };
    readonly where: {
        readonly $and: readonly [{
            readonly region: {
                readonly $in: readonly ["EU", "NA"];
            };
        }, {
            readonly $not: {
                readonly tier: {
                    readonly $eq: "starter";
                };
            };
        }, {
            readonly $or: readonly [{
                readonly $and: readonly [{
                    readonly recentOrderAverage: {
                        readonly $gte: 200000;
                    };
                }, {
                    readonly recentOrderMax: {
                        readonly $gte: 400000;
                    };
                }];
            }, {
                readonly $and: readonly [{
                    readonly recentOrderCount: {
                        readonly $gte: 3;
                    };
                }, {
                    readonly $not: {
                        readonly recentOrderMin: {
                            readonly $gte: 150000;
                        };
                    };
                }];
            }];
        }];
    };
    readonly orderBy: {
        readonly recentOrderAverage: "desc";
        readonly id: "asc";
    };
    readonly page: {
        readonly limit: 20;
    };
};
export declare const fulfillment: {
    readonly select: {
        readonly id: true;
        readonly number: true;
        readonly priority: true;
        readonly shortageUnits: true;
        readonly fulfillmentScore: true;
        readonly account: {
            readonly select: {
                readonly name: true;
            };
        };
        readonly items: {
            readonly select: {
                readonly quantity: true;
                readonly marginCents: true;
                readonly shortageUnits: true;
                readonly product: {
                    readonly select: {
                        readonly sku: true;
                        readonly inventory: {
                            readonly select: {
                                readonly warehouse: true;
                                readonly available: true;
                                readonly stockStatus: true;
                            };
                            readonly where: {
                                readonly $or: readonly [{
                                    readonly stockStatus: {
                                        readonly $eq: "backorder";
                                    };
                                }, {
                                    readonly $and: readonly [{
                                        readonly available: {
                                            readonly $lt: 30;
                                        };
                                    }, {
                                        readonly $not: {
                                            readonly stockStatus: {
                                                readonly $eq: "healthy";
                                            };
                                        };
                                    }];
                                }];
                            };
                            readonly orderBy: {
                                readonly available: "asc";
                                readonly id: "asc";
                            };
                            readonly page: {
                                readonly limit: 1;
                            };
                        };
                    };
                };
            };
            readonly where: {
                readonly $or: readonly [{
                    readonly $and: readonly [{
                        readonly shortageUnits: {
                            readonly $gte: 1;
                        };
                    }, {
                        readonly marginCents: {
                            readonly $gte: 10000;
                        };
                    }];
                }, {
                    readonly $and: readonly [{
                        readonly $not: {
                            readonly marginCents: {
                                readonly $gte: 20000;
                            };
                        };
                    }, {
                        readonly quantity: {
                            readonly $gte: 3;
                        };
                    }];
                }];
            };
            readonly orderBy: {
                readonly shortageUnits: "desc";
                readonly marginCents: "desc";
                readonly id: "asc";
            };
            readonly page: {
                readonly limit: 2;
            };
        };
    };
    readonly where: {
        readonly $and: readonly [{
            readonly region: {
                readonly $in: readonly ["EU", "NA"];
            };
        }, {
            readonly placedAt: {
                readonly $gte: number;
            };
        }, {
            readonly $not: {
                readonly status: {
                    readonly $eq: "cancelled";
                };
            };
        }, {
            readonly $or: readonly [{
                readonly $and: readonly [{
                    readonly shortageUnits: {
                        readonly $gte: 1;
                    };
                }, {
                    readonly priority: {
                        readonly $gte: 55;
                    };
                }];
            }, {
                readonly fulfillmentScore: {
                    readonly $gte: 90;
                };
            }];
        }];
    };
    readonly orderBy: {
        readonly fulfillmentScore: "desc";
        readonly id: "asc";
    };
    readonly page: {
        readonly limit: 20;
    };
};
export declare const nestedTriage: {
    readonly select: {
        readonly id: true;
        readonly name: true;
        readonly managerRevenueCents: true;
        readonly manager: {
            readonly select: {
                readonly name: true;
            };
        };
        readonly orders: {
            readonly select: {
                readonly id: true;
                readonly status: true;
                readonly netCents: true;
                readonly priority: true;
                readonly items: {
                    readonly select: {
                        readonly quantity: true;
                        readonly marginCents: true;
                        readonly shortageUnits: true;
                        readonly product: {
                            readonly select: {
                                readonly sku: true;
                                readonly inventory: {
                                    readonly select: {
                                        readonly warehouse: true;
                                        readonly available: true;
                                        readonly stockStatus: true;
                                    };
                                    readonly where: {
                                        readonly $not: {
                                            readonly stockStatus: {
                                                readonly $eq: "healthy";
                                            };
                                        };
                                    };
                                    readonly orderBy: {
                                        readonly available: "asc";
                                        readonly id: "asc";
                                    };
                                    readonly page: {
                                        readonly limit: 1;
                                    };
                                };
                            };
                        };
                    };
                    readonly where: {
                        readonly $and: readonly [{
                            readonly marginCents: {
                                readonly $gte: 5000;
                            };
                        }, {
                            readonly $or: readonly [{
                                readonly quantity: {
                                    readonly $gte: 3;
                                };
                            }, {
                                readonly shortageUnits: {
                                    readonly $gte: 1;
                                };
                            }];
                        }];
                    };
                    readonly orderBy: {
                        readonly marginCents: "desc";
                        readonly id: "asc";
                    };
                    readonly page: {
                        readonly limit: 2;
                    };
                };
            };
            readonly where: {
                readonly $and: readonly [{
                    readonly placedAt: {
                        readonly $gte: number;
                    };
                }, {
                    readonly $not: {
                        readonly status: {
                            readonly $eq: "cancelled";
                        };
                    };
                }, {
                    readonly $or: readonly [{
                        readonly priority: {
                            readonly $gte: 65;
                        };
                    }, {
                        readonly status: {
                            readonly $eq: "pending";
                        };
                    }];
                }, {
                    readonly $not: {
                        readonly netCents: {
                            readonly $lt: 20000;
                        };
                    };
                }];
            };
            readonly orderBy: {
                readonly priority: "desc";
                readonly netCents: "desc";
                readonly id: "asc";
            };
            readonly page: {
                readonly offset: 1;
                readonly limit: 3;
            };
        };
        readonly tickets: {
            readonly select: {
                readonly subject: true;
                readonly priority: true;
            };
            readonly where: {
                readonly $and: readonly [{
                    readonly $or: readonly [{
                        readonly status: {
                            readonly $eq: "open";
                        };
                    }, {
                        readonly status: {
                            readonly $eq: "pending";
                        };
                    }];
                }, {
                    readonly $not: {
                        readonly priority: {
                            readonly $lt: 3;
                        };
                    };
                }];
            };
            readonly orderBy: {
                readonly priority: "desc";
                readonly openedAt: "asc";
                readonly id: "asc";
            };
            readonly page: {
                readonly offset: 1;
                readonly limit: 2;
            };
        };
    };
    readonly where: {
        readonly region: {
            readonly $in: readonly ["EU", "NA"];
        };
        readonly $not: {
            readonly tier: {
                readonly $eq: "starter";
            };
        };
    };
    readonly orderBy: {
        readonly id: "asc";
    };
    readonly page: {
        readonly offset: 1;
        readonly limit: 12;
    };
};
export declare const portfolioConcentration: {
    readonly select: {
        readonly id: true;
        readonly name: true;
        readonly netRevenueCents: true;
        readonly managerRevenueCents: true;
        readonly managerConcentrationBps: true;
        readonly portfolioShareBps: true;
        readonly manager: {
            readonly select: {
                readonly name: true;
            };
        };
        readonly tickets: {
            readonly select: {
                readonly subject: true;
                readonly priority: true;
            };
            readonly where: {
                readonly status: {
                    readonly $in: readonly ["open", "pending"];
                };
                readonly priority: {
                    readonly $gte: 4;
                };
                readonly openedAt: {
                    readonly $gte: number;
                };
            };
            readonly orderBy: {
                readonly priority: "desc";
                readonly id: "asc";
            };
            readonly page: {
                readonly limit: 2;
            };
        };
    };
    readonly where: {
        readonly $and: readonly [{
            readonly region: {
                readonly $in: readonly ["EU", "NA"];
            };
        }, {
            readonly $not: {
                readonly tier: {
                    readonly $eq: "starter";
                };
            };
        }, {
            readonly $or: readonly [{
                readonly $and: readonly [{
                    readonly portfolioShareBps: {
                        readonly $gte: 200;
                    };
                }, {
                    readonly managerRevenueCents: {
                        readonly $gte: 500000;
                    };
                }];
            }, {
                readonly $and: readonly [{
                    readonly hasRecentEscalation: {
                        readonly $eq: true;
                    };
                }, {
                    readonly $not: {
                        readonly managerConcentrationBps: {
                            readonly $lt: 2000;
                        };
                    };
                }];
            }];
        }];
    };
    readonly orderBy: {
        readonly portfolioShareBps: "desc";
        readonly netRevenueCents: "desc";
        readonly id: "asc";
    };
    readonly page: {
        readonly limit: 20;
    };
};
export declare const advancedWorkloads: readonly [{
    readonly id: "revenueQuality";
    readonly title: "Revenue quality";
    readonly entity: "accounts";
    readonly query: {
        readonly select: {
            readonly id: true;
            readonly name: true;
            readonly recentOrderCount: true;
            readonly recentOrderAverage: true;
            readonly recentOrderMin: true;
            readonly recentOrderMax: true;
            readonly latestPaidOrderCents: true;
            readonly marginBps: true;
            readonly orders: {
                readonly select: {
                    readonly id: true;
                    readonly netCents: true;
                    readonly priority: true;
                };
                readonly where: {
                    readonly placedAt: {
                        readonly $gte: number;
                    };
                    readonly status: {
                        readonly $in: readonly ["paid", "shipped"];
                    };
                };
                readonly orderBy: {
                    readonly netCents: "desc";
                    readonly id: "asc";
                };
                readonly page: {
                    readonly offset: 1;
                    readonly limit: 2;
                };
            };
        };
        readonly where: {
            readonly $and: readonly [{
                readonly region: {
                    readonly $in: readonly ["EU", "NA"];
                };
            }, {
                readonly $not: {
                    readonly tier: {
                        readonly $eq: "starter";
                    };
                };
            }, {
                readonly $or: readonly [{
                    readonly $and: readonly [{
                        readonly recentOrderAverage: {
                            readonly $gte: 200000;
                        };
                    }, {
                        readonly recentOrderMax: {
                            readonly $gte: 400000;
                        };
                    }];
                }, {
                    readonly $and: readonly [{
                        readonly recentOrderCount: {
                            readonly $gte: 3;
                        };
                    }, {
                        readonly $not: {
                            readonly recentOrderMin: {
                                readonly $gte: 150000;
                            };
                        };
                    }];
                }];
            }];
        };
        readonly orderBy: {
            readonly recentOrderAverage: "desc";
            readonly id: "asc";
        };
        readonly page: {
            readonly limit: 20;
        };
    };
    readonly description: "Count/avg/min/max and latest paid order over one complete relation; nested Boolean filters and an independently paged include.";
}, {
    readonly id: "fulfillment";
    readonly title: "Fulfillment constraints";
    readonly entity: "orders";
    readonly query: {
        readonly select: {
            readonly id: true;
            readonly number: true;
            readonly priority: true;
            readonly shortageUnits: true;
            readonly fulfillmentScore: true;
            readonly account: {
                readonly select: {
                    readonly name: true;
                };
            };
            readonly items: {
                readonly select: {
                    readonly quantity: true;
                    readonly marginCents: true;
                    readonly shortageUnits: true;
                    readonly product: {
                        readonly select: {
                            readonly sku: true;
                            readonly inventory: {
                                readonly select: {
                                    readonly warehouse: true;
                                    readonly available: true;
                                    readonly stockStatus: true;
                                };
                                readonly where: {
                                    readonly $or: readonly [{
                                        readonly stockStatus: {
                                            readonly $eq: "backorder";
                                        };
                                    }, {
                                        readonly $and: readonly [{
                                            readonly available: {
                                                readonly $lt: 30;
                                            };
                                        }, {
                                            readonly $not: {
                                                readonly stockStatus: {
                                                    readonly $eq: "healthy";
                                                };
                                            };
                                        }];
                                    }];
                                };
                                readonly orderBy: {
                                    readonly available: "asc";
                                    readonly id: "asc";
                                };
                                readonly page: {
                                    readonly limit: 1;
                                };
                            };
                        };
                    };
                };
                readonly where: {
                    readonly $or: readonly [{
                        readonly $and: readonly [{
                            readonly shortageUnits: {
                                readonly $gte: 1;
                            };
                        }, {
                            readonly marginCents: {
                                readonly $gte: 10000;
                            };
                        }];
                    }, {
                        readonly $and: readonly [{
                            readonly $not: {
                                readonly marginCents: {
                                    readonly $gte: 20000;
                                };
                            };
                        }, {
                            readonly quantity: {
                                readonly $gte: 3;
                            };
                        }];
                    }];
                };
                readonly orderBy: {
                    readonly shortageUnits: "desc";
                    readonly marginCents: "desc";
                    readonly id: "asc";
                };
                readonly page: {
                    readonly limit: 2;
                };
            };
        };
        readonly where: {
            readonly $and: readonly [{
                readonly region: {
                    readonly $in: readonly ["EU", "NA"];
                };
            }, {
                readonly placedAt: {
                    readonly $gte: number;
                };
            }, {
                readonly $not: {
                    readonly status: {
                        readonly $eq: "cancelled";
                    };
                };
            }, {
                readonly $or: readonly [{
                    readonly $and: readonly [{
                        readonly shortageUnits: {
                            readonly $gte: 1;
                        };
                    }, {
                        readonly priority: {
                            readonly $gte: 55;
                        };
                    }];
                }, {
                    readonly fulfillmentScore: {
                        readonly $gte: 90;
                    };
                }];
            }];
        };
        readonly orderBy: {
            readonly fulfillmentScore: "desc";
            readonly id: "asc";
        };
        readonly page: {
            readonly limit: 20;
        };
    };
    readonly description: "Custom native line → stock lookup, prebuilt sum across those lines, JavaScript score, computed parent filters and filtered nested warehouses.";
}, {
    readonly id: "nestedTriage";
    readonly title: "Nested service triage";
    readonly entity: "accounts";
    readonly query: {
        readonly select: {
            readonly id: true;
            readonly name: true;
            readonly managerRevenueCents: true;
            readonly manager: {
                readonly select: {
                    readonly name: true;
                };
            };
            readonly orders: {
                readonly select: {
                    readonly id: true;
                    readonly status: true;
                    readonly netCents: true;
                    readonly priority: true;
                    readonly items: {
                        readonly select: {
                            readonly quantity: true;
                            readonly marginCents: true;
                            readonly shortageUnits: true;
                            readonly product: {
                                readonly select: {
                                    readonly sku: true;
                                    readonly inventory: {
                                        readonly select: {
                                            readonly warehouse: true;
                                            readonly available: true;
                                            readonly stockStatus: true;
                                        };
                                        readonly where: {
                                            readonly $not: {
                                                readonly stockStatus: {
                                                    readonly $eq: "healthy";
                                                };
                                            };
                                        };
                                        readonly orderBy: {
                                            readonly available: "asc";
                                            readonly id: "asc";
                                        };
                                        readonly page: {
                                            readonly limit: 1;
                                        };
                                    };
                                };
                            };
                        };
                        readonly where: {
                            readonly $and: readonly [{
                                readonly marginCents: {
                                    readonly $gte: 5000;
                                };
                            }, {
                                readonly $or: readonly [{
                                    readonly quantity: {
                                        readonly $gte: 3;
                                    };
                                }, {
                                    readonly shortageUnits: {
                                        readonly $gte: 1;
                                    };
                                }];
                            }];
                        };
                        readonly orderBy: {
                            readonly marginCents: "desc";
                            readonly id: "asc";
                        };
                        readonly page: {
                            readonly limit: 2;
                        };
                    };
                };
                readonly where: {
                    readonly $and: readonly [{
                        readonly placedAt: {
                            readonly $gte: number;
                        };
                    }, {
                        readonly $not: {
                            readonly status: {
                                readonly $eq: "cancelled";
                            };
                        };
                    }, {
                        readonly $or: readonly [{
                            readonly priority: {
                                readonly $gte: 65;
                            };
                        }, {
                            readonly status: {
                                readonly $eq: "pending";
                            };
                        }];
                    }, {
                        readonly $not: {
                            readonly netCents: {
                                readonly $lt: 20000;
                            };
                        };
                    }];
                };
                readonly orderBy: {
                    readonly priority: "desc";
                    readonly netCents: "desc";
                    readonly id: "asc";
                };
                readonly page: {
                    readonly offset: 1;
                    readonly limit: 3;
                };
            };
            readonly tickets: {
                readonly select: {
                    readonly subject: true;
                    readonly priority: true;
                };
                readonly where: {
                    readonly $and: readonly [{
                        readonly $or: readonly [{
                            readonly status: {
                                readonly $eq: "open";
                            };
                        }, {
                            readonly status: {
                                readonly $eq: "pending";
                            };
                        }];
                    }, {
                        readonly $not: {
                            readonly priority: {
                                readonly $lt: 3;
                            };
                        };
                    }];
                };
                readonly orderBy: {
                    readonly priority: "desc";
                    readonly openedAt: "asc";
                    readonly id: "asc";
                };
                readonly page: {
                    readonly offset: 1;
                    readonly limit: 2;
                };
            };
        };
        readonly where: {
            readonly region: {
                readonly $in: readonly ["EU", "NA"];
            };
            readonly $not: {
                readonly tier: {
                    readonly $eq: "starter";
                };
            };
        };
        readonly orderBy: {
            readonly id: "asc";
        };
        readonly page: {
            readonly offset: 1;
            readonly limit: 12;
        };
    };
    readonly description: "Independent offsets, computed filters and sorts at three relation levels; shared-manager aggregation and a separately filtered ticket page.";
}, {
    readonly id: "portfolioConcentration";
    readonly title: "Portfolio concentration";
    readonly entity: "accounts";
    readonly query: {
        readonly select: {
            readonly id: true;
            readonly name: true;
            readonly netRevenueCents: true;
            readonly managerRevenueCents: true;
            readonly managerConcentrationBps: true;
            readonly portfolioShareBps: true;
            readonly manager: {
                readonly select: {
                    readonly name: true;
                };
            };
            readonly tickets: {
                readonly select: {
                    readonly subject: true;
                    readonly priority: true;
                };
                readonly where: {
                    readonly status: {
                        readonly $in: readonly ["open", "pending"];
                    };
                    readonly priority: {
                        readonly $gte: 4;
                    };
                    readonly openedAt: {
                        readonly $gte: number;
                    };
                };
                readonly orderBy: {
                    readonly priority: "desc";
                    readonly id: "asc";
                };
                readonly page: {
                    readonly limit: 2;
                };
            };
        };
        readonly where: {
            readonly $and: readonly [{
                readonly region: {
                    readonly $in: readonly ["EU", "NA"];
                };
            }, {
                readonly $not: {
                    readonly tier: {
                        readonly $eq: "starter";
                    };
                };
            }, {
                readonly $or: readonly [{
                    readonly $and: readonly [{
                        readonly portfolioShareBps: {
                            readonly $gte: 200;
                        };
                    }, {
                        readonly managerRevenueCents: {
                            readonly $gte: 500000;
                        };
                    }];
                }, {
                    readonly $and: readonly [{
                        readonly hasRecentEscalation: {
                            readonly $eq: true;
                        };
                    }, {
                        readonly $not: {
                            readonly managerConcentrationBps: {
                                readonly $lt: 2000;
                            };
                        };
                    }];
                }];
            }];
        };
        readonly orderBy: {
            readonly portfolioShareBps: "desc";
            readonly netRevenueCents: "desc";
            readonly id: "asc";
        };
        readonly page: {
            readonly limit: 20;
        };
    };
    readonly description: "Programmatic batch deduplication, native two-level grouping, cross-account share, and an approved relation predicate inside a mixed Boolean tree.";
}];
