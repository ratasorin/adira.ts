/** Intentionally invalid requests, also exercised in frontend/inference.ts. */
export declare const expressivityProbes: readonly [{
    readonly id: "relationQuantifier";
    readonly query: {
        readonly select: {
            readonly id: true;
        };
        readonly where: {
            readonly orders: {
                readonly $some: {
                    readonly priority: {
                        readonly $gte: 80;
                    };
                };
            };
        };
    };
    readonly boundary: "Arbitrary relation quantifiers require a backend-declared predicate.";
}, {
    readonly id: "relationAlias";
    readonly query: {
        readonly select: {
            readonly urgentOrders: {
                readonly select: {
                    readonly id: true;
                };
                readonly where: {
                    readonly priority: {
                        readonly $gte: 80;
                    };
                };
            };
        };
    };
    readonly boundary: "Two differently filtered views of one relation need separate declared relation names or requests.";
}, {
    readonly id: "computedArguments";
    readonly query: {
        readonly select: {
            readonly recentOrderAverage: {
                readonly since: 123;
            };
        };
    };
    readonly boundary: "Computed scalar fields have fixed backend dependencies, without frontend-supplied arguments.";
}, {
    readonly id: "arbitraryGrouping";
    readonly query: {
        readonly select: {
            readonly id: true;
        };
        readonly groupBy: readonly ["region"];
    };
    readonly boundary: "Frontend grouping is deliberately outside the REST resource contract.";
}, {
    readonly id: "predicateOperand";
    readonly query: {
        readonly select: {
            readonly id: true;
        };
        readonly where: {
            readonly hasRecentEscalation: {
                readonly $eq: "yes";
            };
        };
    };
    readonly boundary: "Backend-approved predicates still enforce their declared operand types.";
}];
