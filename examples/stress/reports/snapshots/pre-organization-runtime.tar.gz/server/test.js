"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const mongoose_1 = __importDefault(require("mongoose"));
const workloads_1 = require("./fixtures/workloads");
const expressivity_probes_1 = require("./fixtures/expressivity-probes");
const models_1 = require("./models");
const mongo_1 = require("./mongo");
const seed_1 = require("./seed");
const business_1 = require("./business");
const reference_advanced_1 = require("./reference-advanced");
const adira_1 = require("./adira");
const server_1 = require("./server");
const telemetry_1 = require("./telemetry");
const benchmark_1 = require("./benchmark");
let db, host;
(0, node_test_1.before)(async () => {
    db = await (0, mongo_1.temporaryMongo)();
    await (0, models_1.connect)(db.uri);
    await (0, seed_1.seed)("smoke", false, () => { });
    (0, telemetry_1.monitor)();
    host = await (0, server_1.listen)("both", 0);
});
(0, node_test_1.after)(async () => {
    if (host)
        await new Promise((resolve) => host.server.close(() => resolve()));
    await mongoose_1.default.disconnect();
    await db?.stop();
});
for (const workload of workloads_1.workloads)
    (0, node_test_1.test)(`equivalent ${workload.id} results across two tenants`, async () => {
        for (const tenant of [0, 1]) {
            const a = await (0, benchmark_1.request)(host.url, "adira", workload, tenant), b = await (0, benchmark_1.request)(host.url, "reference", workload, tenant);
            strict_1.default.equal(a.status, 200, JSON.stringify(a.body));
            strict_1.default.equal(b.status, 200, JSON.stringify(b.body));
            (0, benchmark_1.assertParity)(a.body, b.body, workload.id);
            if (workload.id === "fulfillment") {
                const batched = await (0, benchmark_1.request)(host.url, "adiraBatched", workload, tenant);
                strict_1.default.equal(batched.status, 200, JSON.stringify(batched.body));
                (0, benchmark_1.assertParity)(batched.body, b.body, `${workload.id}/batched`);
                strict_1.default.ok(batched.body.telemetry.callbacks.shortageBatch > 0);
                strict_1.default.ok(batched.body.telemetry.callbacks.shortageDistinctProducts <
                    batched.body.telemetry.callbacks.shortageLines);
            }
            strict_1.default.ok(a.body.telemetry.commands > 0, "Driver command monitoring should capture reads");
            strict_1.default.ok((a.body.rows?.length ?? 0) > 0, "The scenario must produce data");
        }
    });
async function customRead(entity, query, backend = "adira") {
    const response = await fetch(host.url +
        `/api/${backend}/${entity}?query=${encodeURIComponent(JSON.stringify(query))}`);
    const body = await response.json();
    strict_1.default.equal(response.status, 200, JSON.stringify(body));
    return body;
}
(0, node_test_1.test)("complete relation statistics are independent of include offsets; empty and tied relations keep exact semantics", async () => {
    const tenantId = (0, seed_1.oid)(1, 0, 0), ids = [new mongoose_1.default.Types.ObjectId(), new mongoose_1.default.Types.ObjectId()];
    const orderIds = [
        new mongoose_1.default.Types.ObjectId(),
        new mongoose_1.default.Types.ObjectId(),
        new mongoose_1.default.Types.ObjectId(),
    ].sort((a, b) => String(a).localeCompare(String(b)));
    try {
        await models_1.Accounts.collection.insertMany(ids.map((_id, i) => ({
            _id,
            tenantId,
            deletedAt: null,
            name: `Stats fixture ${i}`,
            region: "EU",
            tier: "growth",
            managerId: (0, seed_1.oid)(2, 0, 0),
            creditLimitCents: 100_000,
            joinedAt: business_1.SINCE,
        })));
        await models_1.Orders.collection.insertMany(orderIds.map((_id, i) => ({
            _id,
            tenantId,
            deletedAt: null,
            accountId: ids[0],
            managerId: (0, seed_1.oid)(2, 0, 0),
            region: "EU",
            number: `Stats order ${i}`,
            status: "paid",
            placedAt: business_1.AS_OF - 1,
            totalCents: [100, 300, 300][i],
            refundedCents: 0,
        })));
        const body = await customRead("accounts", {
            select: {
                id: true,
                recentOrderCount: true,
                recentOrderAverage: true,
                recentOrderMin: true,
                recentOrderMax: true,
                latestPaidOrderCents: true,
                orders: {
                    select: { id: true, netCents: true },
                    orderBy: { netCents: "desc", id: "asc" },
                    page: { offset: 1, limit: 1 },
                },
            },
            where: { $or: ids.map((id) => ({ id: { $eq: String(id) } })) },
            orderBy: { id: "asc" },
        });
        const full = body.rows.find((r) => r.id === String(ids[0]));
        strict_1.default.equal(full.recentOrderCount, 3);
        strict_1.default.equal(full.recentOrderAverage, 700 / 3);
        strict_1.default.equal(full.recentOrderMin, 100);
        strict_1.default.equal(full.recentOrderMax, 300);
        strict_1.default.equal(full.latestPaidOrderCents, 100, "Latest tie uses id ascending");
        strict_1.default.deepEqual(full.orders, [{ id: String(orderIds[2]), netCents: 300 }]);
        const empty = body.rows.find((r) => r.id === String(ids[1]));
        strict_1.default.deepEqual(empty, {
            id: String(ids[1]),
            recentOrderCount: 0,
            recentOrderAverage: null,
            recentOrderMin: null,
            recentOrderMax: null,
            latestPaidOrderCents: null,
            orders: [],
        });
        strict_1.default.equal(body.telemetry.callbacks.revenueBatch, undefined);
        strict_1.default.equal(body.telemetry.callbacks.fulfillmentScore, undefined);
    }
    finally {
        await models_1.Orders.collection.deleteMany({ _id: { $in: orderIds } });
        await models_1.Accounts.collection.deleteMany({ _id: { $in: ids } });
    }
});
(0, node_test_1.test)("custom native stock producers, prebuilt sums and callbacks preserve parent association and tenant scope", async () => {
    const tenantId = (0, seed_1.oid)(1, 0, 0), orderId = new mongoose_1.default.Types.ObjectId(), productId = new mongoose_1.default.Types.ObjectId();
    const lineIds = [
        new mongoose_1.default.Types.ObjectId(),
        new mongoose_1.default.Types.ObjectId(),
    ];
    const inventoryIds = [
        new mongoose_1.default.Types.ObjectId(),
        new mongoose_1.default.Types.ObjectId(),
        new mongoose_1.default.Types.ObjectId(),
    ];
    try {
        await models_1.Products.collection.insertOne({
            _id: productId,
            tenantId,
            deletedAt: null,
            name: "Stock fixture",
            sku: "FIXTURE",
            category: "hardware",
            priceCents: 100,
            costCents: 10,
            active: true,
        });
        await models_1.Orders.collection.insertOne({
            _id: orderId,
            tenantId,
            deletedAt: null,
            accountId: (0, seed_1.oid)(3, 0, 0),
            managerId: (0, seed_1.oid)(2, 0, 0),
            region: "EU",
            number: "Stock fixture",
            status: "pending",
            placedAt: business_1.AS_OF - 1,
            totalCents: 10_000,
            refundedCents: 0,
        });
        await models_1.Lines.collection.insertMany(lineIds.map((_id, i) => ({
            _id,
            tenantId,
            deletedAt: null,
            orderId,
            productId,
            accountId: (0, seed_1.oid)(3, 0, 0),
            placedAt: business_1.AS_OF - 1,
            status: "pending",
            quantity: [3, 7][i],
            grossCents: 1000,
            costCents: 100,
        })));
        await models_1.Inventories.collection.insertMany([
            {
                _id: inventoryIds[0],
                tenantId,
                deletedAt: null,
                productId,
                warehouse: "AMS",
                onHand: 6,
                reserved: 1,
            },
            {
                _id: inventoryIds[1],
                tenantId: (0, seed_1.oid)(1, 1, 0),
                deletedAt: null,
                productId,
                warehouse: "LEAK",
                onHand: 99999,
                reserved: 0,
            },
            {
                _id: inventoryIds[2],
                tenantId,
                deletedAt: business_1.AS_OF,
                productId,
                warehouse: "DELETED",
                onHand: 99999,
                reserved: 0,
            },
        ]);
        const query = {
            select: {
                shortageUnits: true,
                fulfillmentScore: true,
                items: {
                    select: {
                        quantity: true,
                        shortageUnits: true,
                        product: {
                            select: {
                                sku: true,
                                inventory: {
                                    select: { available: true, stockStatus: true },
                                    where: { $not: { stockStatus: { $eq: "healthy" } } },
                                },
                            },
                        },
                    },
                    where: { shortageUnits: { $gte: 1 } },
                    page: { limit: 1 },
                },
            },
            where: { id: { $eq: String(orderId) } },
        };
        const result = await customRead("orders", query);
        const batched = await customRead("orders", query, "adira-batched");
        strict_1.default.deepEqual(batched.rows, result.rows);
        strict_1.default.equal(result.rows[0].shortageUnits, 2);
        strict_1.default.deepEqual(result.rows[0].items, [
            {
                quantity: 7,
                shortageUnits: 2,
                product: {
                    sku: "FIXTURE",
                    inventory: [{ available: 5, stockStatus: "low" }],
                },
            },
        ]);
        await models_1.Inventories.collection.deleteOne({ _id: inventoryIds[0] });
        const noStock = await customRead("orders", {
            select: { shortageUnits: true },
            where: { id: { $eq: String(orderId) } },
        });
        strict_1.default.equal(noStock.rows[0].shortageUnits, 10, "Missing inventory is zero available stock");
        const noStockBatched = await customRead("orders", {
            select: { shortageUnits: true },
            where: { id: { $eq: String(orderId) } },
        }, "adira-batched");
        strict_1.default.deepEqual(noStockBatched.rows, noStock.rows);
    }
    finally {
        await models_1.Lines.collection.deleteMany({ _id: { $in: lineIds } });
        await models_1.Inventories.collection.deleteMany({ _id: { $in: inventoryIds } });
        await models_1.Orders.collection.deleteOne({ _id: orderId });
        await models_1.Products.collection.deleteOne({ _id: productId });
    }
});
(0, node_test_1.test)("programmatic manager grouping shares work within a resolver batch and stays demand driven", async () => {
    const workload = workloads_1.workloads.find((w) => w.id === "portfolioConcentration");
    const result = await (0, benchmark_1.request)(host.url, "adira", workload);
    strict_1.default.equal(result.status, 200);
    const counts = result.body.telemetry.callbacks;
    strict_1.default.ok(counts.managerPortfolioParents > counts.uniqueManagers);
    strict_1.default.equal(counts.costBatch, undefined);
    const directory = await customRead("accounts", {
        select: { name: true },
        page: { limit: 1 },
    });
    strict_1.default.deepEqual(directory.telemetry.callbacks, {});
});
(0, node_test_1.test)("the alternative order implementation prunes its custom provider when no shortage is requested", async () => {
    const result = await customRead("orders", { select: { id: true, number: true }, page: { limit: 2 } }, "adira-batched");
    strict_1.default.equal(result.rows.length, 2);
    strict_1.default.deepEqual(result.telemetry.callbacks, {});
    strict_1.default.equal(result.telemetry.commands, 1);
});
(0, node_test_1.test)("reduction membership runs before pagination while display-only financial callbacks run for selected accounts", async () => {
    const workload = workloads_1.workloads.find((w) => w.id === "revenueQuality");
    const plan = (0, adira_1.inspect)("accounts", workload.query, {
        tenantId: (0, seed_1.oid)(1, 0, 0),
        trace: (0, telemetry_1.newTrace)(),
    });
    strict_1.default.deepEqual(plan.reductionGroups?.map(({ loads, phase }) => ({ loads, phase })), [
        {
            loads: [
                "recentOrderCount",
                "recentOrderAverage",
                "recentOrderMin",
                "recentOrderMax",
            ],
            phase: "membership",
        },
    ]);
    const result = await (0, benchmark_1.request)(host.url, "adira", workload);
    strict_1.default.equal(result.status, 200);
    const counts = result.body.telemetry.callbacks;
    strict_1.default.equal(counts.costParents, result.body.rows.length);
    strict_1.default.equal(counts.revenueParents, result.body.rows.length);
    strict_1.default.equal(counts.marginBps, result.body.rows.length);
});
(0, node_test_1.test)("the native reference's priority formula matches JavaScript across representative amounts, ages and statuses", async () => {
    const samples = [0, 1000, 31_000, 300_000, 1_000_000].flatMap((totalCents) => [0, 0.25, 2.5, 14.5, 30].flatMap((age) => ["pending", "paid"].map((status) => ({
        totalCents,
        status,
        placedAt: business_1.AS_OF - age * business_1.DAY,
    }))));
    const results = await models_1.Orders.collection
        .aggregate([
        { $limit: 1 },
        { $project: { _id: 0, samples: { $literal: samples } } },
        { $unwind: "$samples" },
        { $replaceWith: "$samples" },
        { $set: { priority: reference_advanced_1.nativePriority } },
    ])
        .toArray();
    strict_1.default.equal(results.length, samples.length);
    for (const row of results)
        strict_1.default.equal(row.priority, (0, business_1.priority)(row.totalCents, row.status, (business_1.AS_OF - row.placedAt) / business_1.DAY));
});
(0, node_test_1.test)("unsupported frontend shapes fail before database work and diagnostics capture complete command sequences", async () => {
    for (const probe of expressivity_probes_1.expressivityProbes) {
        const response = await fetch(host.url +
            `/api/adira/accounts?query=${encodeURIComponent(JSON.stringify(probe.query))}`);
        const body = await response.json();
        strict_1.default.equal(response.status, 400, probe.id);
        strict_1.default.equal(body.telemetry.commands, 0, probe.id);
    }
    for (const backend of ["adira", "reference"]) {
        const response = await fetch(host.url + `/api/diagnostics/commands/fulfillment?backend=${backend}`);
        const body = await response.json();
        strict_1.default.equal(response.status, 200, JSON.stringify(body));
        strict_1.default.equal(body.commands.length, body.telemetry.commands);
        strict_1.default.ok(body.commands.some((c) => c.collection === "stress_lines"));
        strict_1.default.ok(body.commands.every((c) => typeof c.durationMs === "number"));
    }
});
(0, node_test_1.test)("lightweight selection prunes finance, service and JavaScript work", async () => {
    const result = await (0, benchmark_1.request)(host.url, "adira", workloads_1.workloads[0]);
    strict_1.default.deepEqual(result.body.telemetry?.callbacks, {});
    strict_1.default.equal(result.body.telemetry?.commands, 1);
    const response = await fetch(host.url +
        `/api/adira/plan/accounts?query=${encodeURIComponent(JSON.stringify(workloads_1.workloads[0].query))}`);
    const body = await response.json();
    strict_1.default.equal(JSON.stringify(body.pipeline).includes("$lookup"), false);
});
(0, node_test_1.test)("bulk revenue consumers skip costs and margin loads costs only for the selected page", async () => {
    for (const view of ["risk", "account360"]) {
        const result = await (0, benchmark_1.request)(host.url, "adira", workloads_1.workloads.find((w) => w.id === view));
        strict_1.default.equal(result.status, 200);
        strict_1.default.ok(result.body.telemetry.callbacks.revenueBatch > 0);
        strict_1.default.equal(result.body.telemetry.callbacks.costBatch, undefined);
        if (view === "account360")
            strict_1.default.equal(result.body.telemetry.callbacks.revenueParents, result.body.rows.length);
    }
    const workload = workloads_1.workloads.find((entry) => entry.id === "finances");
    const query = { ...workload.query, page: { limit: 3 } };
    const encoded = encodeURIComponent(JSON.stringify(query));
    const response = await fetch(host.url + `/api/adira/accounts?query=${encoded}`);
    strict_1.default.equal(response.status, 200);
    const body = await response.json();
    strict_1.default.equal(body.rows.length, 3);
    strict_1.default.equal(body.telemetry.callbacks.costParents, 3);
    strict_1.default.equal(body.telemetry.callbacks.marginBps, 3);
    strict_1.default.ok(body.telemetry.callbacks.revenueParents > 3);
    const plan = await (await fetch(host.url + `/api/adira/plan/accounts?query=${encoded}`)).json();
    strict_1.default.ok(plan.application.indexOf("load cost") >
        plan.application.indexOf("paginate"));
    strict_1.default.ok(!JSON.stringify(plan.pipeline).includes("$lookup"));
});
(0, node_test_1.test)("stock totals and warehouse counts share a batch while unrelated product demands stay pruned", async () => {
    const base = {
        where: { category: { $eq: "hardware" }, active: { $eq: true } },
        orderBy: { id: "asc" },
        page: { limit: 2 },
    };
    const get = async (select) => {
        const response = await fetch(host.url +
            `/api/adira/products?query=${encodeURIComponent(JSON.stringify({ ...base, select }))}`);
        strict_1.default.equal(response.status, 200);
        return response.json();
    };
    const plain = await get({ sku: true });
    strict_1.default.deepEqual(plain.telemetry.callbacks, {});
    strict_1.default.equal(plain.telemetry.commands, 1);
    const stock = await get({ sku: true, available: true, warehouseCount: true });
    strict_1.default.equal(stock.telemetry.callbacks.stockBatch, 1);
    strict_1.default.equal(stock.telemetry.callbacks.stockParents, 2);
    strict_1.default.equal(stock.telemetry.commands, 2, "stock amounts and warehouse count share one aggregate");
    const sales = await get({ sku: true, unitsSold: true });
    strict_1.default.equal(sales.telemetry.callbacks.stockBatch, undefined);
});
async function selectedMetrics(entity, ids, select) {
    const query = {
        select,
        where: { $or: ids.map((id) => ({ id: { $eq: id } })) },
        orderBy: { id: "asc" },
        page: { limit: ids.length },
    };
    const response = await fetch(host.url +
        `/api/adira/${entity}?query=${encodeURIComponent(JSON.stringify(query))}`);
    const body = await response.json();
    strict_1.default.equal(response.status, 200, JSON.stringify(body));
    strict_1.default.equal(body.rows.length, ids.length);
    return body.rows;
}
(0, node_test_1.test)("bulk finance preserves shared foreign-array membership and exact tenant/soft-delete policies", async () => {
    const parents = [(0, seed_1.oid)(3, 0, 0), (0, seed_1.oid)(3, 0, 1)];
    const select = {
        id: true,
        grossRevenueCents: true,
        netRevenueCents: true,
        revenueOrderCount: true,
        costCents: true,
    };
    const before = await selectedMetrics("accounts", parents.map(String), select);
    const base = {
        tenantId: (0, seed_1.oid)(1, 0, 0),
        deletedAt: null,
        accountId: parents[0],
        placedAt: business_1.SINCE + 1,
        status: "paid",
    };
    const excluded = [
        { tenantId: [base.tenantId] },
        { deletedAt: [null] },
        { tenantId: (0, seed_1.oid)(1, 1, 0) },
        { deletedAt: business_1.SINCE },
    ];
    const orders = [
        {
            ...base,
            _id: new mongoose_1.default.Types.ObjectId(),
            accountId: [parents[0], parents[1], parents[0]],
            totalCents: 100,
            refundedCents: 20,
        },
        ...excluded.map((fields) => ({
            ...base,
            ...fields,
            _id: new mongoose_1.default.Types.ObjectId(),
            totalCents: 1_000_000,
            refundedCents: 0,
        })),
    ];
    const lines = [
        {
            ...base,
            _id: new mongoose_1.default.Types.ObjectId(),
            accountId: [parents[0], parents[1], parents[0]],
            costCents: 30,
        },
        ...excluded.map((fields) => ({
            ...base,
            ...fields,
            _id: new mongoose_1.default.Types.ObjectId(),
            costCents: 1_000_000,
        })),
    ];
    try {
        await models_1.Orders.collection.insertMany(orders);
        await models_1.Lines.collection.insertMany(lines);
        const after = await selectedMetrics("accounts", parents.map(String), select);
        for (const [index, row] of after.entries()) {
            strict_1.default.equal(row.id, before[index].id);
            strict_1.default.equal(row.grossRevenueCents, before[index].grossRevenueCents + 100);
            strict_1.default.equal(row.netRevenueCents, before[index].netRevenueCents + 80);
            strict_1.default.equal(row.revenueOrderCount, before[index].revenueOrderCount + 1);
            strict_1.default.equal(row.costCents, before[index].costCents + 30);
        }
    }
    finally {
        await models_1.Orders.collection.deleteMany({
            _id: { $in: orders.map((row) => row._id) },
        });
        await models_1.Lines.collection.deleteMany({
            _id: { $in: lines.map((row) => row._id) },
        });
    }
});
(0, node_test_1.test)("shared stock grouping deduplicates foreign arrays and excludes malformed/cross-tenant policy values", async () => {
    const parents = [(0, seed_1.oid)(4, 0, 0), (0, seed_1.oid)(4, 0, 1)];
    const select = { id: true, available: true, warehouseCount: true };
    const before = await selectedMetrics("products", parents.map(String), select);
    const base = {
        tenantId: (0, seed_1.oid)(1, 0, 0),
        deletedAt: null,
        productId: parents[0],
        warehouse: "probe",
        onHand: 1_000_000,
        reserved: 0,
    };
    const rows = [
        {
            ...base,
            _id: new mongoose_1.default.Types.ObjectId(),
            productId: [parents[0], parents[1], parents[0]],
            onHand: 8,
            reserved: 3,
        },
        ...[
            { tenantId: [base.tenantId] },
            { deletedAt: [null] },
            { tenantId: (0, seed_1.oid)(1, 1, 0) },
            { deletedAt: business_1.SINCE },
        ].map((fields) => ({
            ...base,
            ...fields,
            _id: new mongoose_1.default.Types.ObjectId(),
        })),
    ];
    try {
        await models_1.Inventories.collection.insertMany(rows);
        const after = await selectedMetrics("products", parents.map(String), select);
        for (const [index, row] of after.entries()) {
            strict_1.default.equal(row.id, before[index].id);
            strict_1.default.equal(row.available, before[index].available + 5);
            strict_1.default.equal(row.warehouseCount, before[index].warehouseCount + 1);
        }
    }
    finally {
        await models_1.Inventories.collection.deleteMany({
            _id: { $in: rows.map((row) => row._id) },
        });
    }
});
(0, node_test_1.test)("unselected numeric filters still reject overflow after batch-loaded arithmetic", async () => {
    const accountId = (0, seed_1.oid)(3, 0, 0), productId = (0, seed_1.oid)(4, 0, 0);
    const orderId = new mongoose_1.default.Types.ObjectId(), inventoryId = new mongoose_1.default.Types.ObjectId();
    try {
        await models_1.Orders.collection.insertOne({
            _id: orderId,
            tenantId: (0, seed_1.oid)(1, 0, 0),
            deletedAt: null,
            accountId,
            placedAt: business_1.SINCE + 1,
            status: "paid",
            totalCents: Number.MAX_VALUE,
            refundedCents: -Number.MAX_VALUE,
        });
        await models_1.Inventories.collection.insertOne({
            _id: inventoryId,
            tenantId: (0, seed_1.oid)(1, 0, 0),
            deletedAt: null,
            productId,
            warehouse: "overflow",
            onHand: Number.MAX_VALUE,
            reserved: -Number.MAX_VALUE,
        });
        for (const [entity, id, field] of [
            ["accounts", accountId, "netRevenueCents"],
            ["products", productId, "available"],
        ]) {
            const query = {
                select: { id: true },
                where: {
                    $and: [{ id: { $eq: String(id) } }, { [field]: { $gte: 0 } }],
                },
            };
            const response = await fetch(host.url +
                `/api/adira/${entity}?query=${encodeURIComponent(JSON.stringify(query))}`);
            strict_1.default.equal(response.status, 400);
            strict_1.default.equal((await response.json()).error, "ReadValidationError");
        }
    }
    finally {
        await models_1.Orders.collection.deleteOne({ _id: orderId });
        await models_1.Inventories.collection.deleteOne({ _id: inventoryId });
    }
});
(0, node_test_1.test)("reference-only deployment serves its own views and rejects Adira routes", async () => {
    const reference = await (0, server_1.listen)("reference", 0);
    try {
        const response = await (0, benchmark_1.request)(reference.url, "reference", workloads_1.workloads[0]);
        strict_1.default.equal(response.status, 200);
        strict_1.default.equal(response.body.telemetry?.callbacks.riskScore, undefined);
        const absent = await fetch(reference.url + "/api/adira/accounts");
        strict_1.default.equal(absent.status, 404);
        strict_1.default.equal((await absent.json()).error, "NotFound");
    }
    finally {
        await new Promise((resolve) => reference.server.close(() => resolve()));
    }
});
(0, node_test_1.test)("invalid fields, types, page limits and tenant indices fail before database commands", async () => {
    for (const query of [
        { select: { secret: true } },
        { select: { name: true }, where: { riskScore: { $gte: "bad" } } },
        { select: { name: true }, page: { limit: 999 } },
    ]) {
        const response = await fetch(host.url +
            `/api/adira/accounts?query=${encodeURIComponent(JSON.stringify(query))}`);
        const body = await response.json();
        strict_1.default.equal(response.status, 400);
        strict_1.default.equal(body.telemetry.commands, 0);
    }
    const invalid = await fetch(host.url + "/api/reference/directory", {
        headers: { "x-tenant-index": "999" },
    });
    strict_1.default.equal(invalid.status, 400);
});
(0, node_test_1.test)("seed refuses accidental overwrite and data includes soft deletes and uneven accounts", async () => {
    await strict_1.default.rejects((0, seed_1.seed)("smoke", false, () => { }), /already exists/);
    strict_1.default.ok(await models_1.Accounts.countDocuments({ deletedAt: { $ne: null } }));
});
(0, node_test_1.test)("budget diagnostic reports complete-history cardinality and native explain is available", async () => {
    const response = await fetch(host.url + "/api/diagnostics/budget");
    const body = await response.json();
    strict_1.default.equal(response.status, 200);
    strict_1.default.ok(body.reference.candidates > 0);
    const explain = await fetch(host.url + "/api/diagnostics/explain/directory");
    strict_1.default.equal(explain.status, 200);
    strict_1.default.ok((await explain.json()).explanation);
});
