"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShortageSummary = exports.shortageOutput = exports.Stock = exports.stockOutput = exports.Cost = exports.costOutput = exports.Revenue = exports.revenueOutput = void 0;
exports.loadRevenue = loadRevenue;
exports.loadCost = loadCost;
exports.loadStock = loadStock;
exports.loadOrderShortages = loadOrderShortages;
const adira_core_ts_1 = require("@n/adira.core.ts");
const models_1 = require("./models");
const business_1 = require("./business");
const telemetry_1 = require("./telemetry");
const parentKey = "__demo_parent_key";
const idsFor = (parents) => [
    ...new Map(parents.map(({ row }) => [String(row._id), row._id])).values(),
];
// Keep the exact tenant/soft-delete policy alongside the indexable tenant match.
// In particular, an array containing a tenant ID or null is not that scalar.
function activeTenant(context) {
    return {
        tenantId: context.tenantId,
        $expr: {
            $and: [
                { $eq: ["$tenantId", { $literal: context.tenantId }] },
                { $eq: [{ $ifNull: ["$deletedAt", null] }, null] },
            ],
        },
    };
}
/** Preserve MongoDB lookup membership, including duplicate foreign array keys. */
function parentGroups(field, ids) {
    const foreign = `$${field}`;
    return [
        {
            $set: {
                [parentKey]: {
                    $cond: [
                        { $isArray: foreign },
                        { $setIntersection: [foreign, { $literal: ids }] },
                        [foreign],
                    ],
                },
            },
        },
        { $unwind: `$${parentKey}` },
    ];
}
exports.revenueOutput = adira_core_ts_1.schema.object({
    grossRevenueCents: adira_core_ts_1.schema.number(),
    refundedCents: adira_core_ts_1.schema.number(),
    revenueOrderCount: adira_core_ts_1.schema.number(),
});
exports.Revenue = (0, adira_core_ts_1.defineResource)({
    grossRevenueCents: adira_core_ts_1.field.number(),
    refundedCents: adira_core_ts_1.field.number(),
    revenueOrderCount: adira_core_ts_1.field.number(),
});
async function loadRevenue({ parents, context }) {
    (0, telemetry_1.count)(context, "revenueBatch");
    (0, telemetry_1.count)(context, "revenueParents", parents.length);
    const ids = idsFor(parents);
    const totals = await models_1.Orders.aggregate([
        {
            $match: {
                ...activeTenant(context),
                accountId: { $in: ids },
                placedAt: { $gte: business_1.SINCE },
                status: { $in: ["paid", "shipped"] },
            },
        },
        ...parentGroups("accountId", ids),
        {
            $group: {
                _id: `$${parentKey}`,
                grossRevenueCents: { $sum: "$totalCents" },
                refundedCents: { $sum: "$refundedCents" },
                revenueOrderCount: { $sum: 1 },
            },
        },
    ]);
    const byId = new Map(totals.map((row) => [String(row._id), row]));
    return parents.map(({ ref, row }) => {
        const value = byId.get(String(row._id));
        return {
            ref,
            rows: [
                {
                    grossRevenueCents: value?.grossRevenueCents ?? 0,
                    refundedCents: value?.refundedCents ?? 0,
                    revenueOrderCount: value?.revenueOrderCount ?? 0,
                },
            ],
        };
    });
}
exports.costOutput = adira_core_ts_1.schema.object({ costCents: adira_core_ts_1.schema.number() });
exports.Cost = (0, adira_core_ts_1.defineResource)({ costCents: adira_core_ts_1.field.number() });
async function loadCost({ parents, context }) {
    (0, telemetry_1.count)(context, "costBatch");
    (0, telemetry_1.count)(context, "costParents", parents.length);
    const ids = idsFor(parents);
    const totals = await models_1.Lines.aggregate([
        {
            $match: {
                ...activeTenant(context),
                accountId: { $in: ids },
                placedAt: { $gte: business_1.SINCE },
                status: { $in: ["paid", "shipped"] },
            },
        },
        ...parentGroups("accountId", ids),
        { $group: { _id: `$${parentKey}`, costCents: { $sum: "$costCents" } } },
    ]);
    const byId = new Map(totals.map((row) => [String(row._id), row.costCents]));
    return parents.map(({ ref, row }) => ({
        ref,
        rows: [{ costCents: byId.get(String(row._id)) ?? 0 }],
    }));
}
exports.stockOutput = adira_core_ts_1.schema.object({
    onHand: adira_core_ts_1.schema.number(),
    reserved: adira_core_ts_1.schema.number(),
    warehouseCount: adira_core_ts_1.schema.number(),
});
exports.Stock = (0, adira_core_ts_1.defineResource)({
    onHand: adira_core_ts_1.field.number(),
    reserved: adira_core_ts_1.field.number(),
    warehouseCount: adira_core_ts_1.field.number(),
});
async function loadStock({ parents, context }) {
    (0, telemetry_1.count)(context, "stockBatch");
    (0, telemetry_1.count)(context, "stockParents", parents.length);
    const ids = idsFor(parents);
    const totals = await models_1.Inventories.aggregate([
        { $match: { ...activeTenant(context), productId: { $in: ids } } },
        ...parentGroups("productId", ids),
        {
            $group: {
                _id: `$${parentKey}`,
                onHand: { $sum: "$onHand" },
                reserved: { $sum: "$reserved" },
                warehouseCount: { $sum: 1 },
            },
        },
    ]);
    const byId = new Map(totals.map((row) => [String(row._id), row]));
    return parents.map(({ ref, row }) => {
        const value = byId.get(String(row._id));
        return {
            ref,
            rows: [
                {
                    onHand: value?.onHand ?? 0,
                    reserved: value?.reserved ?? 0,
                    warehouseCount: value?.warehouseCount ?? 0,
                },
            ],
        };
    });
}
exports.shortageOutput = adira_core_ts_1.schema.object({ shortageUnits: adira_core_ts_1.schema.number() });
exports.ShortageSummary = (0, adira_core_ts_1.defineResource)({
    shortageUnits: adira_core_ts_1.field.number(),
});
/** Alternative backend modeling: share stock scans across orders in one batch. */
async function loadOrderShortages({ parents, context }) {
    (0, telemetry_1.count)(context, "shortageBatch");
    (0, telemetry_1.count)(context, "shortageParents", parents.length);
    const lines = await models_1.Lines.collection
        .find({ ...activeTenant(context), orderId: { $in: idsFor(parents) } }, { projection: { _id: 0, orderId: 1, productId: 1, quantity: 1 } })
        .batchSize(10_000)
        .toArray();
    const productIds = [
        ...new Map(lines.map((l) => [String(l.productId), l.productId])).values(),
    ];
    const stock = productIds.length
        ? await models_1.Inventories.collection
            .aggregate([
            {
                $match: {
                    ...activeTenant(context),
                    productId: { $in: productIds },
                },
            },
            {
                $group: {
                    _id: "$productId",
                    available: { $sum: { $subtract: ["$onHand", "$reserved"] } },
                },
            },
        ])
            .toArray()
        : [];
    const finite = adira_core_ts_1.schema.number();
    const available = new Map(stock.map((row) => [String(row._id), finite.parse(row.available)]));
    const totals = new Map();
    for (const line of lines) {
        const shortage = Math.max(0, finite.parse(line.quantity) -
            Math.max(0, available.get(String(line.productId)) ?? 0));
        const id = String(line.orderId);
        totals.set(id, (totals.get(id) ?? 0) + shortage);
    }
    (0, telemetry_1.count)(context, "shortageLines", lines.length);
    (0, telemetry_1.count)(context, "shortageDistinctProducts", productIds.length);
    return parents.map(({ ref, row }) => ({
        ref,
        rows: [{ shortageUnits: totals.get(String(row._id)) ?? 0 }],
    }));
}
