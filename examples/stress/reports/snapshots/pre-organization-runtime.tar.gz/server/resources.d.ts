export declare const readLimits: {
    defaultLimit: number;
    maxLimit: number;
    maxDepth: number;
    maxNodes: number;
    maxOperandItems: number;
    maxQueryBytes: number;
    maxCandidates: number;
};
export declare const AgentResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
}, {}>;
export declare const AccountMini: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
}, {}>;
export declare const InventoryResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
}, {}>;
export declare const ProductMini: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, true, false>;
}, {}>;
export declare const LineResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        }, {}>, true, false>;
    }, {}>, false, true>;
}, {}>;
export declare const OrderResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            }, {}>, true, false>;
        }, {}>, false, true>;
    }, {}>, true, false>;
}, {}>;
export declare const TicketResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly subject: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly openedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
}, {}>;
export declare const ShipmentResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly late: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
}, {}>;
export declare const AccountResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly tier: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly creditLimitCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly grossRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly netRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly costCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly revenueOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly marginBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly openTicketCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly lateShipmentCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly riskBand: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly managerRevenueCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly managerConcentrationBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly portfolioShareBps: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderAverage: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMin: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly recentOrderMax: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly latestPaidOrderCents: import("@n/adira.core.ts").ScalarField<number | null, "$eq" | "$gte" | "$lt", true>;
    readonly orderVolatility: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly manager: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, false, true>;
    readonly orders: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly number: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly totalCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly netCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly fulfillmentScore: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly account: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly region: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        }, {}>, false, true>;
        readonly items: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
            readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
            readonly quantity: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly grossCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly marginCents: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly shortageUnits: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly placedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
            readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
            readonly product: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
                    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
                    readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                    readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
                    readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
                }, {}>, true, false>;
            }, {}>, false, true>;
        }, {}>, true, false>;
    }, {}>, true, false>;
    readonly tickets: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly subject: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly status: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly priority: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly openedAt: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    }, {}>, true, false>;
}, {
    readonly hasRecentEscalation: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
}>;
export declare const ProductResource: import("@n/adira.core.ts").ReadResource<{
    readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
    readonly name: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly sku: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly category: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    readonly active: import("@n/adira.core.ts").ScalarField<boolean, "$eq", false>;
    readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly unitsSold: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly warehouseCount: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly daysCover: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
    readonly inventory: import("@n/adira.core.ts").RelationField<import("@n/adira.core.ts").ReadResource<{
        readonly id: import("@n/adira.core.ts").ScalarField<string, "$eq", true>;
        readonly warehouse: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
        readonly onHand: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly reserved: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly available: import("@n/adira.core.ts").ScalarField<number, "$eq" | "$gte" | "$lt", true>;
        readonly stockStatus: import("@n/adira.core.ts").ScalarField<string, "$eq" | "$in" | "$startsWith", true>;
    }, {}>, true, false>;
}, {}>;
export type Entity = "accounts" | "orders" | "products";
