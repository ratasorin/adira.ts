"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.newTrace = exports.traces = void 0;
exports.count = count;
exports.monitor = monitor;
const node_async_hooks_1 = require("node:async_hooks");
const mongoose_1 = __importDefault(require("mongoose"));
exports.traces = new node_async_hooks_1.AsyncLocalStorage();
const newTrace = () => ({
    commands: 0,
    mongoMs: 0,
    commandNames: {},
    callbacks: {},
    started: performance.now(),
});
exports.newTrace = newTrace;
function count(context, key, n = 1) {
    context.trace.callbacks[key] = (context.trace.callbacks[key] ?? 0) + n;
}
function monitor() {
    const active = new Map();
    const client = mongoose_1.default.connection.getClient();
    client.on("commandStarted", (event) => {
        const trace = exports.traces.getStore();
        if (trace &&
            ["aggregate", "find", "getMore", "count"].includes(event.commandName)) {
            trace.commands++;
            trace.commandNames[event.commandName] =
                (trace.commandNames[event.commandName] ?? 0) + 1;
            let detail;
            if (trace.details) {
                const command = event.command;
                detail = {
                    name: event.commandName,
                    collection: command.aggregate ?? command.find ?? command.collection,
                    pipeline: command.pipeline,
                    filter: command.filter,
                    sort: command.sort,
                    projection: command.projection,
                };
                trace.details.push(detail);
            }
            active.set(event.requestId, { trace, detail });
        }
    });
    const finish = (event) => {
        const entry = active.get(event.requestId);
        if (entry) {
            const { trace, detail } = entry;
            trace.mongoMs += event.duration;
            if (detail) {
                detail.durationMs = event.duration;
                const batch = event.reply?.cursor?.firstBatch ?? event.reply?.cursor?.nextBatch;
                if (Array.isArray(batch))
                    detail.returned = batch.length;
            }
            active.delete(event.requestId);
        }
    };
    client.on("commandSucceeded", finish);
    client.on("commandFailed", finish);
}
