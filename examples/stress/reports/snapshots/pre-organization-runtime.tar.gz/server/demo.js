"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = __importDefault(require("mongoose"));
const models_1 = require("./models");
const mongo_1 = require("./mongo");
const seed_1 = require("./seed");
const telemetry_1 = require("./telemetry");
const server_1 = require("./server");
async function main() {
    const profile = (0, seed_1.option)("profile", "medium");
    if (!Object.hasOwn(seed_1.profiles, profile))
        throw new Error("Unknown profile");
    const database = await (0, mongo_1.temporaryMongo)();
    let host;
    try {
        await (0, models_1.connect)(database.uri);
        await (0, seed_1.seed)(profile);
        (0, telemetry_1.monitor)();
        host = await (0, server_1.listen)("both", Number((0, seed_1.option)("port", "5400")));
        console.log(`\nOpen ${host.url}\nPrivate MongoDB: ${database.uri}\nSeeded data lasts until this process stops. Ctrl-C cleans up this private database.`);
        await new Promise((resolve) => {
            process.once("SIGINT", () => resolve());
            process.once("SIGTERM", () => resolve());
        });
    }
    finally {
        if (host)
            await new Promise((resolve) => host.server.close(() => resolve()));
        await mongoose_1.default.disconnect();
        await database.stop();
    }
}
main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
