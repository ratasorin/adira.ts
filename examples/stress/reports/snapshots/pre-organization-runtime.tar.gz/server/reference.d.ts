import type { WorkloadId } from "./fixtures/workloads";
import { type Id } from "./models";
import { type RequestContext } from "./telemetry";
export declare function executeReference(view: WorkloadId, c: RequestContext): Promise<{
    rows: unknown[];
}>;
export declare function referenceVolatility(accountId: Id, c: RequestContext): Promise<{
    candidates: number;
    value: number;
    priorityTop2: {
        id: string;
        priority: number;
    }[];
}>;
