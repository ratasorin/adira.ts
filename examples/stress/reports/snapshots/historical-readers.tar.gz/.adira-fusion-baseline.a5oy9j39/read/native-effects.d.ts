import type { PipelineStage } from "mongoose";
import type { NativeOperation, PlanState } from "./plan";
/** Conservative repeatability check, including any foreign lookup pipelines. */
export declare function repeatableMongo(value: unknown): boolean;
/** These outer stages operate independently on each parent. Foreign stages may group. */
export declare function rowLocalWrites(stages: readonly PipelineStage[]): ReadonlySet<string> | undefined;
export interface NativeUnit {
    readonly stages: readonly PipelineStage[];
    readonly operation?: NativeOperation;
    /** Undefined denotes an opaque or stream-dependent operation. */
    readonly writes?: ReadonlySet<string>;
    readonly keeps?: ReadonlySet<string>;
}
/** Keep producers atomic so predicates cannot observe their temporary payload. */
export declare function nativeUnits(state: PlanState, stages: readonly PipelineStage[]): NativeUnit[];
/** Delayed work must not observe predicate flags added to the parent document. */
export declare function readsRowShape(value: unknown): boolean;
/** Only an independent, repeatable output suffix may cross native pagination. */
export declare function nativePageSplit(state: PlanState, stages: readonly PipelineStage[], pageInputs: ReadonlySet<string>, predicateWrites: ReadonlySet<string>): {
    before: PipelineStage[];
    after: PipelineStage[];
};
//# sourceMappingURL=native-effects.d.ts.map