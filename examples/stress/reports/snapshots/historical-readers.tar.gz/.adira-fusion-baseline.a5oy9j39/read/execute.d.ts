import { ReadExecutor, ResourceLike } from "@n/adira.core.ts";
import { CompatibleResource, createMongo, ReaderOptions } from "./plan";
export declare class ReadBudgetError extends Error {
    constructor(message: string);
}
export declare function defineRead<R extends ResourceLike, Row extends object, Context = unknown>(resource: CompatibleResource<R, NoInfer<Row>>, options: ReaderOptions<R, Row, Context>): ReadExecutor<R, Context>;
export interface ReadContext<Context extends object> {
    readonly mongo: ReturnType<typeof createMongo<Context>>;
    defineRead<R extends ResourceLike, Row extends object>(resource: CompatibleResource<R, NoInfer<Row>>, options: ReaderOptions<R, Row, Context>): ReadExecutor<R, Context>;
}
/** Declare backend context once; all child plans and callbacks retain its type. */
export declare function createReadContext<Context extends object>(): ReadContext<Context>;
//# sourceMappingURL=execute.d.ts.map