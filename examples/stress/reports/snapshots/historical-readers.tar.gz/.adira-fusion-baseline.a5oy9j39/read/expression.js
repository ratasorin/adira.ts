"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Expressions = exports.MongoExpression = void 0;
exports.scalarExpression = scalarExpression;
const adira_core_ts_1 = require("@n/adira.core.ts");
const index_match_1 = require("./index-match");
/** Native representation and a reference evaluator for application-side composition. */
class MongoExpression {
    constructor(native, dependencies, evaluate, output, 
    /** False when JavaScript and MongoDB conversions need not have identical semantics. */
    applicationSafe = true, 
    /** Compiler facts supplied by built-ins; raw expressions need no metadata. */
    optimization) {
        this.native = native;
        this.dependencies = dependencies;
        this.evaluate = evaluate;
        this.output = output;
        this.applicationSafe = applicationSafe;
        this.optimization = optimization;
    }
}
exports.MongoExpression = MongoExpression;
const dependencies = (...expressions) => new Set(expressions.flatMap((expression) => [...expression.dependencies]));
function numeric(value) {
    if (typeof value !== "number" || !Number.isFinite(value))
        throw new Error("Numeric expression received a non-number");
    return value;
}
function equalValues(left, right) {
    if (left === right)
        return true;
    if (left instanceof Date || right instanceof Date)
        return (left instanceof Date &&
            right instanceof Date &&
            left.getTime() === right.getTime());
    if (!left || !right || typeof left !== "object" || typeof right !== "object")
        return false;
    if ("toHexString" in left && typeof left.toHexString === "function") {
        return ("toHexString" in right &&
            typeof right.toHexString === "function" &&
            left.toHexString() === right.toHexString());
    }
    if (Array.isArray(left) || Array.isArray(right)) {
        return (Array.isArray(left) &&
            Array.isArray(right) &&
            left.length === right.length &&
            left.every((value, index) => equalValues(value, right[index])));
    }
    const keys = Object.keys(left), other = Object.keys(right);
    return (keys.length === other.length &&
        keys.every((key, index) => key === other[index] &&
            equalValues(left[key], right[key])));
}
class Expressions {
    field(key) {
        return new MongoExpression(`$${key}`, new Set([key]), (row) => row[key], undefined, true, { field: key });
    }
    literal(value) {
        return new MongoExpression({ $literal: value }, new Set(), () => value);
    }
    add(left, right) {
        return new MongoExpression({ $add: [left.native, right.native] }, dependencies(left, right), (row) => numeric(left.evaluate(row)) + numeric(right.evaluate(row)), adira_core_ts_1.schema.number(), left.applicationSafe && right.applicationSafe);
    }
    multiply(left, right) {
        return new MongoExpression({ $multiply: [left.native, right.native] }, dependencies(left, right), (row) => numeric(left.evaluate(row)) * numeric(right.evaluate(row)), adira_core_ts_1.schema.number(), left.applicationSafe && right.applicationSafe);
    }
    lower(value) {
        return new MongoExpression({ $toLower: value.native }, value.dependencies, (row) => adira_core_ts_1.schema.string().parse(value.evaluate(row)).toLowerCase(), adira_core_ts_1.schema.string(), false);
    }
    upper(value) {
        return new MongoExpression({ $toUpper: value.native }, value.dependencies, (row) => adira_core_ts_1.schema.string().parse(value.evaluate(row)).toUpperCase(), adira_core_ts_1.schema.string(), false);
    }
    toString(value) {
        return new MongoExpression({ $toString: value.native }, value.dependencies, (row) => {
            const resolved = value.evaluate(row);
            if (resolved === null || resolved === undefined)
                throw new Error("Cannot stringify a missing value");
            return String(resolved);
        }, adira_core_ts_1.schema.string(), false);
    }
    size(value) {
        return new MongoExpression({ $size: value.native }, value.dependencies, (row) => {
            const resolved = value.evaluate(row);
            if (!Array.isArray(resolved))
                throw new Error("size() received a non-array");
            return resolved.length;
        }, adira_core_ts_1.schema.number(), value.applicationSafe);
    }
    eq(left, right) {
        return new MongoExpression({ $eq: [{ $ifNull: [left.native, null] }, { $literal: right }] }, left.dependencies, (row) => equalValues(left.evaluate(row) ?? null, right), adira_core_ts_1.schema.boolean(), left.applicationSafe, { match: (0, index_match_1.scalarMatch)(left.optimization?.field, "$eq", right) });
    }
    gt(left, right) {
        return new MongoExpression({
            $and: [
                { $isNumber: left.native },
                { $gt: [left.native, { $literal: right }] },
            ],
        }, left.dependencies, (row) => typeof left.evaluate(row) === "number" &&
            numeric(left.evaluate(row)) > right, adira_core_ts_1.schema.boolean(), left.applicationSafe, { match: (0, index_match_1.scalarMatch)(left.optimization?.field, "$gt", right) });
    }
    gte(left, right) {
        return new MongoExpression({
            $and: [
                { $isNumber: left.native },
                { $gte: [left.native, { $literal: right }] },
            ],
        }, left.dependencies, (row) => typeof left.evaluate(row) === "number" &&
            numeric(left.evaluate(row)) >= right, adira_core_ts_1.schema.boolean(), left.applicationSafe, { match: (0, index_match_1.scalarMatch)(left.optimization?.field, "$gte", right) });
    }
    startsWith(left, prefix) {
        return new MongoExpression({
            $cond: [
                { $eq: [{ $type: left.native }, "string"] },
                { $eq: [{ $indexOfCP: [left.native, { $literal: prefix }] }, 0] },
                false,
            ],
        }, left.dependencies, (row) => typeof left.evaluate(row) === "string" &&
            left.evaluate(row).startsWith(prefix), adira_core_ts_1.schema.boolean(), left.applicationSafe);
    }
    isNull(value) {
        return new MongoExpression({ $eq: [{ $ifNull: [value.native, null] }, null] }, value.dependencies, (row) => value.evaluate(row) == null, adira_core_ts_1.schema.boolean(), value.applicationSafe, { match: (0, index_match_1.scalarMatch)(value.optimization?.field, "$eq", null) });
    }
    and(...values) {
        return new MongoExpression({ $and: values.map((value) => value.native) }, dependencies(...values), (row) => values.every((value) => value.evaluate(row)), adira_core_ts_1.schema.boolean(), values.every((value) => value.applicationSafe), { match: (0, index_match_1.andMatch)(values.map((value) => value.optimization?.match)) });
    }
    or(...values) {
        return new MongoExpression({ $or: values.map((value) => value.native) }, dependencies(...values), (row) => values.some((value) => value.evaluate(row)), adira_core_ts_1.schema.boolean(), values.every((value) => value.applicationSafe), { match: (0, index_match_1.orMatch)(values.map((value) => value.optimization?.match)) });
    }
    not(value) {
        return new MongoExpression({ $not: [value.native] }, value.dependencies, (row) => !value.evaluate(row), adira_core_ts_1.schema.boolean(), value.applicationSafe);
    }
}
exports.Expressions = Expressions;
/** Built-in scalar predicates have explicitly two-valued null/missing semantics. */
function scalarExpression(field, operator, operand) {
    const property = `$${field}`;
    const value = { $ifNull: [property, null] };
    let native;
    const equal = { $eq: [value, { $literal: operand }] };
    switch (operator) {
        case "$eq":
            native = equal;
            break;
        case "$ne":
            native = { $not: [equal] };
            break;
        case "$in":
            native = { $in: [value, { $literal: operand }] };
            break;
        case "$nin":
            native = { $not: [{ $in: [value, { $literal: operand }] }] };
            break;
        case "$gt":
        case "$gte":
        case "$lt":
        case "$lte":
            native = {
                $and: [
                    { $isNumber: property },
                    { [operator]: [property, { $literal: operand }] },
                ],
            };
            break;
        case "$startsWith":
        case "$contains":
            native = {
                $cond: [
                    { $eq: [{ $type: property }, "string"] },
                    {
                        [operator === "$startsWith" ? "$eq" : "$gte"]: [
                            { $indexOfCP: [property, { $literal: operand }] },
                            0,
                        ],
                    },
                    false,
                ],
            };
            break;
        default:
            throw new Error(`Unsupported scalar operator '${operator}'`);
    }
    return new MongoExpression(native, new Set([field]), (row) => {
        const resolved = row[field] ?? null;
        switch (operator) {
            case "$eq":
                return resolved === operand;
            case "$ne":
                return resolved !== operand;
            case "$in":
                return operand.includes(resolved);
            case "$nin":
                return !operand.includes(resolved);
            case "$gt":
                return typeof resolved === "number" && resolved > operand;
            case "$gte":
                return (typeof resolved === "number" && resolved >= operand);
            case "$lt":
                return typeof resolved === "number" && resolved < operand;
            case "$lte":
                return (typeof resolved === "number" && resolved <= operand);
            case "$startsWith":
                return (typeof resolved === "string" &&
                    resolved.startsWith(operand));
            case "$contains":
                return (typeof resolved === "string" && resolved.includes(operand));
            default:
                return false;
        }
    }, adira_core_ts_1.schema.boolean(), true, { match: (0, index_match_1.scalarMatch)(field, operator, operand) });
}
//# sourceMappingURL=expression.js.map