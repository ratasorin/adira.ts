"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mongo = exports.AppRelationPlan = exports.MongoRelationPlan = exports.AppPlan = exports.MongoPlan = exports.RelationBinding = exports.RelationDependency = exports.Condition = void 0;
exports.assertReadOnlyStages = assertReadOnlyStages;
exports.pick = pick;
exports.createMongo = createMongo;
const adira_core_ts_1 = require("@n/adira.core.ts");
const expression_1 = require("./expression");
class Condition {
    constructor(scope, requires, native, evaluate) {
        this.scope = scope;
        this.requires = requires;
        this.native = native;
        this.evaluate = evaluate;
    }
}
exports.Condition = Condition;
/** A lazy description of a complete relation view, consumed by AppPlan.load(). */
class RelationDependency {
    constructor(binding, query, operation = "all", field) {
        this.binding = binding;
        this.query = query;
        this.operation = operation;
        this.field = field;
    }
}
exports.RelationDependency = RelationDependency;
class RelationBinding {
    constructor(resource, many, parentScope, localField, foreignField, options) {
        this.resource = resource;
        this.many = many;
        this.parentScope = parentScope;
        this.localField = localField;
        this.foreignField = foreignField;
        this.options = options;
    }
    get requires() {
        const provider = this.options.source.state.provider;
        if (provider)
            return provider.requires;
        if (this.localField === undefined)
            throw new Error("A MongoDB relation requires a local field");
        return [this.localField];
    }
    all(query) {
        if (!this.many)
            throw new Error("all() requires a to-many relation");
        return new RelationDependency(this, query);
    }
    count(query) {
        return this.aggregate("count", query ?? {});
    }
    exists(query) {
        return this.aggregate("exists", query ?? {});
    }
    sum(query) {
        return this.aggregate("sum", query, query.field);
    }
    avg(query) {
        return this.aggregate("avg", query, query.field);
    }
    min(query) {
        return this.aggregate("min", query, query.field);
    }
    max(query) {
        return this.aggregate("max", query, query.field);
    }
    first(query) {
        return this.aggregate("first", query);
    }
    last(query) {
        return this.aggregate("last", query);
    }
    get(query) {
        return this.aggregate("get", query);
    }
    aggregate(operation, query, field) {
        if (this.many !== (operation !== "get"))
            throw new Error(`${operation}() requires a ${operation === "get" ? "to-one" : "to-many"} relation`);
        return new RelationDependency(this, query, operation, field);
    }
}
exports.RelationBinding = RelationBinding;
function batchRelation(parent, options) {
    const batchSize = options.batchSize ?? parent.batchSize;
    if (!Number.isSafeInteger(batchSize) || batchSize <= 0 || batchSize > 10_000)
        throw new Error("Batch size must be a positive integer up to 10000");
    options.requires.forEach(adira_core_ts_1.assertReadKey);
    if (typeof options.resolveBatch !== "function")
        throw new Error("resolveBatch must be a function");
    const state = {
        scope: {},
        requiresContext: parent.requiresContext,
        // Retained only as an adapter anchor; provider execution never scans it.
        collection: parent.collection,
        stages: [],
        nativeKeys: new Set(),
        materializedKeys: new Set(Object.keys(options.output.fields)),
        nativeOrigins: new Map(),
        validators: new Map(),
        application: [],
        batchSize,
        concurrency: parent.concurrency,
        provider: {
            requires: [...options.requires],
            output: options.output,
            resolveBatch: options.resolveBatch,
        },
    };
    return new AppRelationPlan(new AppPlan(state), { parentScope: parent.scope });
}
function relationContext(parent, child, join) {
    if (child.nativeOrigins.get(join.foreignField) !== join.foreignField)
        throw new Error(`Relation key '${join.foreignField}' must be retained unchanged by the native child plan; declare .related() before transforming the join field`);
    return { parentScope: parent.scope, ...join };
}
function assertReadOnlyStages(stages) {
    function walk(value) {
        if (!value || typeof value !== "object")
            return;
        for (const [key, child] of Object.entries(value)) {
            if (key === "$out" || key === "$merge")
                throw new Error("Read plans cannot contain $out or $merge");
            walk(child);
        }
    }
    walk(stages);
}
class PlanBase {
    constructor(state) {
        this.state = state;
    }
    related(source, join) {
        if ("resolveBatch" in source)
            return batchRelation(this.state, source);
        if (!join)
            throw new Error("A source relation requires join fields");
        const context = relationContext(this.state, source.state, join);
        return source instanceof MongoPlan
            ? new MongoRelationPlan(new MongoPlan(source.state), context)
            : new AppRelationPlan(new AppPlan(source.state), context);
    }
    condition(build) {
        const expression = build(new expression_1.Expressions());
        return new Condition(this.state.scope, expression.dependencies, {
            stages: [],
            test: expression.native,
            output: {},
            indexMatch: expression.optimization?.match,
        }, expression.applicationSafe
            ? (row) => expression.evaluate(row)
            : undefined);
    }
    appCondition(options) {
        return new Condition(this.state.scope, new Set(options.requires), undefined, (row, context) => options.evaluate(pick(row, options.requires), context));
    }
    /** Preparation enriches parents; the complete Boolean tree decides membership. */
    pipelineCondition(options) {
        assertReadOnlyStages(options.stages);
        const additions = new Set(Object.keys(options.output.fields));
        for (const key of additions)
            if (this.state.materializedKeys.has(key))
                throw new Error(`Predicate preparation cannot overwrite '${key}'`);
        for (const stage of options.stages) {
            const entries = Object.entries(stage);
            if (entries.length !== 1)
                throw new Error("A preparation stage needs one operator");
            const [operator, payload] = entries[0];
            const writes = operator === "$lookup"
                ? [payload.as]
                : operator === "$set" || operator === "$addFields"
                    ? Object.keys(payload)
                    : undefined;
            if (!writes || writes.some((key) => !additions.has(key))) {
                throw new Error("Predicate preparation may only $lookup/$set/$addFields its declared new fields; it cannot filter or replace parents");
            }
        }
        const expression = options.test(new expression_1.Expressions());
        const required = new Set(options.requires);
        for (const key of expression.dependencies)
            if (!additions.has(key))
                required.add(key);
        return new Condition(this.state.scope, required, {
            stages: options.stages,
            test: expression.native,
            output: options.output.fields,
        });
    }
    one(resource, options) {
        return this.relation(resource, false, options);
    }
    many(resource, options) {
        return this.relation(resource, true, options);
    }
    relation(resource, many, options) {
        relationContext(this.state, options.plan.state, options);
        const { plan, localField, foreignField, ...rest } = options;
        return new RelationBinding(resource, many, this.state.scope, localField, foreignField, { ...rest, source: plan });
    }
}
function pick(row, keys) {
    const output = {};
    for (const key of keys)
        output[key] = row[key];
    return output;
}
function appendNativeStage(state, stage, operation) {
    return {
        stages: [...state.stages, stage],
        nativeOperations: new Map(state.nativeOperations).set(stage, operation),
    };
}
class MongoPlan extends PlanBase {
    derive(name, build) {
        (0, adira_core_ts_1.assertReadKey)(name);
        const expression = build(new expression_1.Expressions());
        const keys = new Set(this.state.nativeKeys).add(name);
        const origins = new Map(this.state.nativeOrigins);
        origins.delete(name);
        const validators = new Map(this.state.validators);
        if (expression.output)
            validators.set(name, expression.output);
        else
            validators.delete(name);
        const eagerValidators = new Set(this.state.eagerValidators ?? this.state.validators.keys());
        eagerValidators.delete(name);
        return new MongoPlan({
            ...this.state,
            ...appendNativeStage(this.state, { $set: { [name]: expression.native } }, {
                kind: "derive",
                key: name,
                requires: expression.dependencies,
                output: expression.output,
            }),
            nativeKeys: keys,
            materializedKeys: keys,
            nativeOrigins: origins,
            validators,
            eagerValidators,
        });
    }
    where(build) {
        const expression = build(new expression_1.Expressions());
        return new MongoPlan({
            ...this.state,
            ...appendNativeStage(this.state, {
                $match: {
                    ...expression.optimization?.match,
                    $expr: expression.native,
                },
            }, {
                kind: "consume",
                requires: expression.dependencies,
            }),
        });
    }
    sortBy(order) {
        return new MongoPlan({
            ...this.state,
            ...appendNativeStage(this.state, { $sort: order }, {
                kind: "consume",
                requires: new Set(Object.keys(order)),
            }),
        });
    }
    project(keys) {
        if (!keys.length)
            throw new Error("A native projection requires at least one field");
        keys.forEach(adira_core_ts_1.assertReadKey);
        const projection = Object.fromEntries(keys.map((key) => [key, 1]));
        if (!keys.includes("_id"))
            projection._id = 0;
        return new MongoPlan({
            ...this.state,
            ...appendNativeStage(this.state, { $project: projection }, {
                kind: "project",
                keys: new Set(keys),
            }),
            nativeKeys: new Set(keys),
            materializedKeys: new Set(keys),
            nativeOrigins: new Map([...this.state.nativeOrigins].filter(([key]) => keys.includes(key))),
            validators: new Map([...this.state.validators].filter(([key]) => keys.includes(key))),
            eagerValidators: new Set([
                ...(this.state.eagerValidators ?? this.state.validators.keys()),
            ].filter((key) => keys.includes(key))),
        });
    }
    native(options) {
        assertReadOnlyStages(options.stages);
        if (options.provides !== undefined || options.requires !== undefined) {
            if (!Array.isArray(options.provides) ||
                !options.provides.length ||
                !Array.isArray(options.requires))
                throw new Error("A native field producer requires nonempty provides and an explicit requires array");
            if (options.preserves !== undefined)
                throw new Error("Native field producers preserve undeclared fields automatically; do not specify preserves");
            options.provides.forEach(adira_core_ts_1.assertReadKey);
            options.requires.forEach(adira_core_ts_1.assertReadKey);
            const provides = new Set(options.provides);
            const fields = Object.keys(options.output.fields);
            if (provides.size !== options.provides.length ||
                provides.size !== fields.length ||
                fields.some((key) => !provides.has(key)))
                throw new Error("Native producer provides must name every output field exactly once");
            for (const key of options.requires)
                if (!this.state.materializedKeys.has(key))
                    throw new Error(`Native producer requires unknown input field '${key}'`);
            // Keep the block atomic even when several outputs are used independently.
            // Clone stage identities so reused stage objects cannot alias another block.
            const stages = options.stages.map((stage) => ({ ...stage }));
            const producer = {
                provides,
                requires: new Set(options.requires),
                stages,
                output: new Map(Object.entries(options.output.fields)),
            };
            const operations = new Map(this.state.nativeOperations);
            // An empty block may still assert/validate existing values on demand.
            const trackedStages = stages.length
                ? stages
                : [{ $set: {} }];
            trackedStages.forEach((stage) => operations.set(stage, { kind: "producer", producer }));
            const keys = new Set([...this.state.nativeKeys, ...provides]);
            const origins = new Map(this.state.nativeOrigins);
            const validators = new Map(this.state.validators);
            const eagerValidators = new Set(this.state.eagerValidators ?? this.state.validators.keys());
            for (const [key, parser] of producer.output) {
                origins.delete(key);
                validators.set(key, parser);
                eagerValidators.delete(key);
            }
            return new MongoPlan({
                ...this.state,
                stages: [...this.state.stages, ...trackedStages],
                nativeOperations: operations,
                nativeKeys: keys,
                materializedKeys: keys,
                nativeOrigins: origins,
                validators,
                eagerValidators,
            });
        }
        const origins = new Map([...this.state.nativeOrigins].filter(([key]) => options.preserves?.includes(key)));
        return new MongoPlan({
            ...this.state,
            stages: [...this.state.stages, ...options.stages],
            nativeKeys: new Set(Object.keys(options.output.fields)),
            materializedKeys: new Set(Object.keys(options.output.fields)),
            nativeOrigins: origins,
            validators: new Map(Object.entries(options.output.fields)),
            eagerValidators: new Set(Object.keys(options.output.fields)),
        });
    }
    use(fragment) {
        const result = fragment(this);
        if (result.state.scope !== this.state.scope)
            throw new Error("A fragment cannot switch collections");
        return result;
    }
    toApp(options = {}) {
        const batchSize = options.batchSize ?? this.state.batchSize;
        const concurrency = options.concurrency ?? this.state.concurrency;
        if (![batchSize, concurrency].every((value) => Number.isSafeInteger(value) && value > 0 && value <= 10_000))
            throw new Error("Batch size and concurrency must be positive integers up to 10000");
        return new AppPlan({ ...this.state, batchSize, concurrency });
    }
}
exports.MongoPlan = MongoPlan;
class AppPlan extends PlanBase {
    load(name, dependency) {
        (0, adira_core_ts_1.assertReadKey)(name);
        if (!(dependency instanceof RelationDependency) ||
            dependency.binding.parentScope !== this.state.scope)
            throw new Error("A relation dependency must belong to the same source");
        const nativeKeys = new Set(this.state.nativeKeys);
        nativeKeys.delete(name);
        const nativeOrigins = new Map(this.state.nativeOrigins);
        nativeOrigins.delete(name);
        return new AppPlan({
            ...this.state,
            nativeKeys,
            nativeOrigins,
            application: [
                ...this.state.application,
                {
                    kind: "load",
                    key: name,
                    requires: dependency.binding.requires,
                    dependency: dependency,
                },
            ],
        });
    }
    derive(name, requires, resolve) {
        (0, adira_core_ts_1.assertReadKey)(name);
        const nativeKeys = new Set(this.state.nativeKeys);
        nativeKeys.delete(name);
        const nativeOrigins = new Map(this.state.nativeOrigins);
        nativeOrigins.delete(name);
        return new AppPlan({
            ...this.state,
            nativeKeys,
            nativeOrigins,
            application: [
                ...this.state.application,
                {
                    kind: "derive",
                    key: name,
                    requires,
                    run: (row, context) => resolve(pick(row, requires), context),
                },
            ],
        });
    }
    map(resolve) {
        return new AppPlan({
            ...this.state,
            nativeKeys: new Set(),
            nativeOrigins: new Map(),
            application: [
                ...this.state.application,
                {
                    kind: "map",
                    run: (row, context) => resolve(row, context),
                },
            ],
        });
    }
    filter(predicate) {
        return new AppPlan({
            ...this.state,
            application: [
                ...this.state.application,
                {
                    kind: "filter",
                    run: (row, context) => predicate(row, context),
                },
            ],
        });
    }
    transformBatch(resolve) {
        return new AppPlan({
            ...this.state,
            nativeKeys: new Set(),
            nativeOrigins: new Map(),
            application: [
                ...this.state.application,
                {
                    kind: "batch",
                    run: (rows, context) => resolve(rows, context),
                },
            ],
        });
    }
    use(fragment) {
        const result = fragment(this);
        if (result.state.scope !== this.state.scope)
            throw new Error("A fragment cannot switch collections");
        return result;
    }
}
exports.AppPlan = AppPlan;
/** The join belongs to this context, independently of its transformed payload. */
class RelationPlanBase {
    constructor(plan, correlation) {
        this.plan = plan;
        this.correlation = correlation;
    }
    get state() {
        return this.plan.state;
    }
    one(resource, ...[options]) {
        return this.bind(resource, false, options);
    }
    many(resource, ...[options]) {
        return this.bind(resource, true, options);
    }
    bind(resource, many, options) {
        return new RelationBinding(resource, many, this.correlation.parentScope, this.correlation.localField, this.correlation.foreignField, { ...options, source: this.plan });
    }
    condition(build) {
        return this.plan.condition(build);
    }
    appCondition(options) {
        return this.plan.appCondition(options);
    }
    pipelineCondition(options) {
        return this.plan.pipelineCondition(options);
    }
    related(source, join) {
        if ("resolveBatch" in source)
            return batchRelation(this.state, source);
        if (!join)
            throw new Error("A source relation requires join fields");
        return this.plan.related(source, join);
    }
    assertSameContext(other) {
        if (other.correlation !== this.correlation ||
            other.state.scope !== this.state.scope)
            throw new Error("A relation fragment cannot switch its source or parent context");
    }
}
/** Native stages operate on the rows already matched to one parent. */
class MongoRelationPlan extends RelationPlanBase {
    constructor(nativePlan, context) {
        super(nativePlan, context);
        this.nativePlan = nativePlan;
    }
    derive(name, build) {
        return new MongoRelationPlan(this.nativePlan.derive(name, build), this.correlation);
    }
    where(build) {
        return new MongoRelationPlan(this.nativePlan.where(build), this.correlation);
    }
    sortBy(order) {
        return new MongoRelationPlan(this.nativePlan.sortBy(order), this.correlation);
    }
    project(keys) {
        return new MongoRelationPlan(this.nativePlan.project(keys), this.correlation);
    }
    native(options) {
        if (options.provides !== undefined)
            return new MongoRelationPlan(this.nativePlan.native(options), this.correlation);
        return new MongoRelationPlan(this.nativePlan.native(options), this.correlation);
    }
    toApp(options = {}) {
        return new AppRelationPlan(this.nativePlan.toApp(options), this.correlation);
    }
    use(fragment) {
        const result = fragment(this);
        this.assertSameContext(result);
        return result;
    }
}
exports.MongoRelationPlan = MongoRelationPlan;
/** Application callbacks run inside one parent's relation, including batch callbacks. */
class AppRelationPlan extends RelationPlanBase {
    constructor(appPlan, context) {
        super(appPlan, context);
        this.appPlan = appPlan;
    }
    load(name, dependency) {
        return new AppRelationPlan(this.appPlan.load(name, dependency), this.correlation);
    }
    derive(name, requires, resolve) {
        return new AppRelationPlan(this.appPlan.derive(name, requires, resolve), this.correlation);
    }
    map(resolve) {
        return new AppRelationPlan(this.appPlan.map(resolve), this.correlation);
    }
    filter(predicate) {
        return new AppRelationPlan(this.appPlan.filter(predicate), this.correlation);
    }
    transformBatch(resolve) {
        return new AppRelationPlan(this.appPlan.transformBatch(resolve), this.correlation);
    }
    use(fragment) {
        const result = fragment(this);
        this.assertSameContext(result);
        return result;
    }
}
exports.AppRelationPlan = AppRelationPlan;
function createMongo(requiresContext = false) {
    return {
        from(model, options = {}) {
            const keys = Object.keys(model.schema.paths).map((path) => path.split(".")[0]);
            keys.forEach(adira_core_ts_1.assertReadKey);
            const adapter = {
                name: model.collection.name,
                database: model.db,
                async *scan(pipeline, batchSize) {
                    const cursor = model
                        .aggregate(pipeline)
                        .cursor({ batchSize });
                    try {
                        for await (const row of cursor)
                            yield row;
                    }
                    finally {
                        await cursor.close();
                    }
                },
            };
            const scope = {};
            return new MongoPlan({
                scope,
                requiresContext,
                collection: adapter,
                stages: [],
                inputScope: options.scope
                    ? (context) => {
                        const expression = options.scope(new expression_1.Expressions(), context);
                        // Retain predicate metadata without evaluating the policy twice.
                        return new Condition(scope, expression.dependencies, {
                            stages: [],
                            test: expression.native,
                            output: {},
                            indexMatch: expression.optimization?.match,
                        });
                    }
                    : undefined,
                nativeKeys: new Set(keys),
                materializedKeys: new Set(keys),
                nativeOrigins: new Map(keys.map((key) => [key, key])),
                validators: new Map(),
                application: [],
                batchSize: 256,
                concurrency: 1,
            });
        },
    };
}
exports.mongo = createMongo();
//# sourceMappingURL=plan.js.map