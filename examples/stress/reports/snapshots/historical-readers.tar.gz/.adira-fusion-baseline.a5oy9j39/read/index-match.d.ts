/** A necessary Mongo match, never a replacement for the exact expression. */
export type IndexMatch = Readonly<Record<string, unknown>>;
export declare function andMatch(values: readonly (IndexMatch | undefined)[]): IndexMatch | undefined;
export declare function orMatch(values: readonly (IndexMatch | undefined)[]): IndexMatch | undefined;
/** Positive matches may admit arrays; the original scalar test rejects them. */
export declare function scalarMatch(field: string | undefined, operator: string, operand: unknown): IndexMatch | undefined;
//# sourceMappingURL=index-match.d.ts.map