import { ValueSchema } from "@n/adira.core.ts";
import { IndexMatch } from "./index-match";
export type DataRow = Record<string, unknown>;
export type MaybePromise<T> = T | Promise<T>;
/** Native representation and a reference evaluator for application-side composition. */
export declare class MongoExpression<T> {
    readonly native: unknown;
    readonly dependencies: ReadonlySet<string>;
    readonly evaluate: (row: DataRow) => T;
    readonly output?: ValueSchema<T> | undefined;
    /** False when JavaScript and MongoDB conversions need not have identical semantics. */
    readonly applicationSafe: boolean;
    /** Compiler facts supplied by built-ins; raw expressions need no metadata. */
    readonly optimization?: {
        readonly field?: string;
        readonly match?: IndexMatch;
    } | undefined;
    readonly __value: T;
    constructor(native: unknown, dependencies: ReadonlySet<string>, evaluate: (row: DataRow) => T, output?: ValueSchema<T> | undefined, 
    /** False when JavaScript and MongoDB conversions need not have identical semantics. */
    applicationSafe?: boolean, 
    /** Compiler facts supplied by built-ins; raw expressions need no metadata. */
    optimization?: {
        readonly field?: string;
        readonly match?: IndexMatch;
    } | undefined);
}
export declare class Expressions<Row extends object> {
    field<Key extends keyof Row & string>(key: Key): MongoExpression<Row[Key]>;
    literal<T>(value: T): MongoExpression<T>;
    add(left: MongoExpression<number>, right: MongoExpression<number>): MongoExpression<number>;
    multiply(left: MongoExpression<number>, right: MongoExpression<number>): MongoExpression<number>;
    lower(value: MongoExpression<string>): MongoExpression<string>;
    upper(value: MongoExpression<string>): MongoExpression<string>;
    toString(value: MongoExpression<unknown>): MongoExpression<string>;
    size(value: MongoExpression<readonly unknown[]>): MongoExpression<number>;
    eq<T>(left: MongoExpression<T>, right: Exclude<NoInfer<T>, undefined>): MongoExpression<boolean>;
    gt(left: MongoExpression<number>, right: number): MongoExpression<boolean>;
    gte(left: MongoExpression<number>, right: number): MongoExpression<boolean>;
    startsWith(left: MongoExpression<string>, prefix: string): MongoExpression<boolean>;
    isNull(value: MongoExpression<unknown>): MongoExpression<boolean>;
    and(...values: MongoExpression<boolean>[]): MongoExpression<boolean>;
    or(...values: MongoExpression<boolean>[]): MongoExpression<boolean>;
    not(value: MongoExpression<boolean>): MongoExpression<boolean>;
}
/** Built-in scalar predicates have explicitly two-valued null/missing semantics. */
export declare function scalarExpression(field: string, operator: string, operand: unknown): MongoExpression<boolean>;
//# sourceMappingURL=expression.d.ts.map