import type { Document, Model, PipelineStage } from "mongoose";
import type { IndexMatch } from "./index-match";
import { ExactReadQuery, FieldValue, FilterDefinitions, FilterKeys, ObjectSchema, OperatorsOf, OperatorValue, ReadLimits, ReadData, ReadQuery, ReadWhere, RelationField, ResourceLike, ScalarDefinition, SchemaValue, SortableKeys, ValueSchema } from "@n/adira.core.ts";
import { DataRow, Expressions, MaybePromise, MongoExpression } from "./expression";
type Key<Row> = keyof Row & string;
type Replace<Row, Name extends string, Value> = Omit<Row, Name> & Record<Name, Value>;
type SchemaFields = Record<string, ValueSchema<unknown>>;
type SchemaRow<F extends SchemaFields> = {
    [K in keyof F]: SchemaValue<F[K]>;
};
type WithFields<Row, Fields extends SchemaFields> = Omit<Row, keyof Fields> & SchemaRow<Fields>;
/** An unconditional pipeline may change row shape, membership, and ordering. */
export interface NativeTransformOptions<Row extends object, Fields extends SchemaFields> {
    readonly stages: readonly PipelineStage[];
    readonly output: ObjectSchema<Fields>;
    readonly preserves?: readonly (Key<Row> & keyof Fields)[];
    readonly provides?: never;
    readonly requires?: never;
}
/** A demand-driven producer promises to preserve rows and all undeclared fields. */
export interface NativeProducerOptions<Row extends object, Fields extends SchemaFields, Needs extends readonly Key<Row>[], Provides extends readonly string[]> {
    readonly provides: Provides & readonly (keyof NoInfer<Fields> & string)[] & ([Exclude<keyof Fields, Provides[number]>] extends [never] ? unknown : {
        readonly missingProvidedFields: Exclude<keyof Fields, Provides[number]>;
    });
    readonly requires: Needs;
    readonly stages: readonly PipelineStage[];
    readonly output: ObjectSchema<Fields>;
    readonly preserves?: never;
}
declare const batchParentRef: unique symbol;
/** Opaque, invocation-local identity. Return the original reference unchanged. */
export type BatchParentRef = {
    readonly [batchParentRef]: true;
};
export interface BatchParent<Row extends object> {
    readonly ref: BatchParentRef;
    readonly row: Readonly<Row>;
}
export interface BatchRelationResult<Row extends object> {
    readonly ref: BatchParentRef;
    readonly rows: readonly Row[];
}
export interface BatchRelationOptions<Parent extends object, Needs extends readonly Key<Parent>[], Fields extends SchemaFields, Context = unknown> {
    readonly requires: Needs;
    readonly output: ObjectSchema<Fields>;
    /** Maximum parents per invocation; defaults to the parent plan's batch size. */
    readonly batchSize?: number;
    /** Return one entry per parent, including an empty rows array for no matches. */
    readonly resolveBatch: (input: {
        readonly parents: readonly BatchParent<Pick<Parent, Needs[number]>>[];
        readonly context: Context;
    }) => MaybePromise<readonly BatchRelationResult<SchemaRow<Fields>>[]>;
}
export interface BatchRelationProvider {
    readonly requires: readonly string[];
    readonly output: ValueSchema<object>;
    readonly resolveBatch: (input: {
        readonly parents: readonly BatchParent<DataRow>[];
        readonly context: unknown;
    }) => MaybePromise<readonly BatchRelationResult<object>[]>;
}
export interface CollectionAdapter {
    readonly name: string;
    readonly database: unknown;
    scan(pipeline: PipelineStage[], batchSize: number): AsyncIterable<DataRow>;
}
export type ApplicationStage = {
    kind: "load";
    key: string;
    requires: readonly string[];
    dependency: RelationDependency<object, unknown>;
} | {
    kind: "derive";
    key: string;
    requires: readonly string[];
    run: (row: DataRow, context: unknown) => MaybePromise<unknown>;
} | {
    kind: "map";
    run: (row: DataRow, context: unknown) => MaybePromise<object>;
} | {
    kind: "filter";
    run: (row: DataRow, context: unknown) => MaybePromise<boolean>;
} | {
    kind: "batch";
    run: (rows: readonly DataRow[], context: unknown) => MaybePromise<readonly object[]>;
};
export type NativeOperation = {
    readonly kind: "derive";
    readonly key: string;
    readonly requires: ReadonlySet<string>;
    readonly output?: ValueSchema<unknown>;
} | {
    readonly kind: "consume";
    readonly requires: ReadonlySet<string>;
} | {
    readonly kind: "project";
    readonly keys: ReadonlySet<string>;
} | {
    readonly kind: "producer";
    readonly producer: NativeFieldProducer;
};
export interface NativeFieldProducer {
    readonly provides: ReadonlySet<string>;
    readonly requires: ReadonlySet<string>;
    readonly stages: readonly PipelineStage[];
    readonly output: ReadonlyMap<string, ValueSchema<unknown>>;
}
export interface PlanState {
    readonly scope: object;
    readonly requiresContext?: boolean;
    readonly collection: CollectionAdapter;
    readonly stages: readonly PipelineStage[];
    /** Unannotated raw stages conservatively observe every preceding column. */
    readonly nativeOperations?: ReadonlyMap<PipelineStage, NativeOperation>;
    /** Source-input policy, evaluated before every native transformation. */
    readonly inputScope?: (context: unknown) => unknown;
    /** Complete candidates supplied by a parent-batch loader, without a native prefix. */
    readonly provider?: BatchRelationProvider;
    readonly nativeKeys: ReadonlySet<string>;
    /** Columns actually returned by the native prefix, including overwritten app inputs. */
    readonly materializedKeys: ReadonlySet<string>;
    readonly nativeOrigins: ReadonlyMap<string, string>;
    readonly validators: ReadonlyMap<string, ValueSchema<unknown>>;
    /** Raw output contracts stay eager; managed derivations validate on demand. */
    readonly eagerValidators?: ReadonlySet<string>;
    readonly application: readonly ApplicationStage[];
    readonly batchSize: number;
    readonly concurrency: number;
}
/** Execution input only: consuming a plan must not retype its fluent callbacks. */
export interface ReadSource<Row extends object, Context = unknown> {
    readonly __row: Row;
    readonly __context: (context: Context) => void;
    readonly __rootPlan: true;
    readonly state: PlanState;
}
export interface MongoSource<Row extends object, Context = unknown> extends ReadSource<Row, Context> {
    readonly __phase: "mongodb";
}
export interface AppSource<Row extends object, Context = unknown> extends ReadSource<Row, Context> {
    readonly __phase: "application";
}
export interface NativeCondition {
    readonly stages: readonly PipelineStage[];
    readonly test: unknown;
    readonly output: Readonly<Record<string, ValueSchema<unknown>>>;
    readonly indexMatch?: IndexMatch;
}
export declare class Condition<Row extends object, Context = unknown> {
    readonly scope: object;
    readonly requires: ReadonlySet<string>;
    readonly native?: NativeCondition | undefined;
    readonly evaluate?: ((row: DataRow, context: Context) => MaybePromise<boolean>) | undefined;
    readonly __input: (row: Row) => void;
    readonly __context: (context: Context) => void;
    constructor(scope: object, requires: ReadonlySet<string>, native?: NativeCondition | undefined, evaluate?: ((row: DataRow, context: Context) => MaybePromise<boolean>) | undefined);
}
type HandlerMap<Field, Row extends object, Context> = {
    [Operator in OperatorsOf<Field>]: (value: OperatorValue<Field, Operator>) => Condition<Row, Context>;
};
type PublicFilterHandlers<R extends ResourceLike, Row extends object, Context = unknown> = {
    [K in FilterKeys<R> & keyof R["fields"]]?: Partial<HandlerMap<FilterDefinitions<R>[K], Row, Context>>;
};
export type FilterHandlers<R extends ResourceLike, Row extends object, Context = unknown> = PublicFilterHandlers<R, Row, Context> & {
    [K in keyof R["predicates"]]: HandlerMap<R["predicates"][K], Row, Context>;
};
type RelationKeys<R extends ResourceLike> = {
    [K in keyof R["fields"]]: R["fields"][K] extends RelationField<ResourceLike, boolean, boolean> ? K : never;
}[keyof R["fields"]];
declare const missingFromPlan: unique symbol;
declare const outputTypeMismatch: unique symbol;
type MissingPlanField<Name extends PropertyKey> = {
    readonly [missingFromPlan]: Name;
};
type CompatibleField<Field extends ScalarDefinition, Value> = [Value] extends [
    FieldValue<Field>
] ? Field : [FieldValue<Field>] extends [Value] ? {
    readonly [outputTypeMismatch]: {
        readonly expected: FieldValue<Field>;
        readonly received: Value;
    };
} : ScalarDefinition<Value>;
type DeclaredPlanKeys<Row> = keyof {
    [K in keyof Row as string extends K ? never : number extends K ? never : symbol extends K ? never : K]: Row[K];
};
type CompatibleFields<R extends ResourceLike, Row extends object> = {
    [K in keyof R["fields"]]: R["fields"][K] extends ScalarDefinition ? K extends keyof Row & DeclaredPlanKeys<Row> ? [Row] extends [Record<K, Row[K]>] ? CompatibleField<R["fields"][K], Row[K]> : MissingPlanField<K> : MissingPlanField<K> : R["fields"][K];
};
/** Compare public scalar fields at the resource argument, without changing arity. */
export type CompatibleResource<R extends ResourceLike, Row extends object> = R & {
    readonly fields: CompatibleFields<NoInfer<R>, Row>;
};
export type RelationBindings<R extends ResourceLike, Row extends object, Context = unknown> = {
    [K in RelationKeys<R>]: R["fields"][K] extends RelationField<infer Child, infer Many, boolean> ? RelationBinding<Row, Child, Many, Context> : never;
};
export type ReaderOptions<R extends ResourceLike, Row extends object, Context = unknown> = {
    source: ReadSource<Row, Context>;
    limits?: Partial<ReadLimits>;
    defaultOrderBy?: Partial<Record<SortableKeys<R>, "asc" | "desc">>;
    scope?: (context: NoInfer<Context>) => Condition<Row, NoInfer<Context>>;
} & ([RelationKeys<R>] extends [never] ? {
    relations?: RelationBindings<R, Row, NoInfer<Context>>;
} : {
    relations: RelationBindings<R, Row, NoInfer<Context>>;
}) & ([keyof R["predicates"]] extends [never] ? {
    filters?: FilterHandlers<R, Row, NoInfer<Context>>;
} : {
    filters: FilterHandlers<R, Row, NoInfer<Context>>;
});
export interface RuntimeReaderOptions {
    source: {
        readonly state: PlanState;
    };
    limits?: Partial<ReadLimits>;
    defaultOrderBy?: Record<string, "asc" | "desc">;
    scope?: (context: unknown) => Condition<object>;
    relations?: Record<string, RelationBinding<object, ResourceLike, boolean>>;
    filters?: Record<string, Record<string, (value: unknown) => Condition<object>>>;
}
/** Complete selections cannot contain display pagination, including nested relations. */
export type RelationAllQuery<R extends ResourceLike> = Omit<ReadQuery<R>, "select" | "page"> & {
    select: {
        [K in keyof R["fields"]]?: R["fields"][K] extends RelationField<infer Child, infer Many, boolean> ? Many extends true ? RelationAllQuery<Child> : Pick<RelationAllQuery<Child>, "select" | "where"> : true;
    };
};
export type RelationWhereQuery<R extends ResourceLike> = {
    where?: ReadWhere<R>;
};
export type NumericResourceKeys<R extends ResourceLike> = {
    [K in keyof R["fields"]]: R["fields"][K] extends ScalarDefinition<infer Value> ? [NonNullable<Value>] extends [never] ? never : NonNullable<Value> extends number ? K : never : never;
}[keyof R["fields"]] & string;
export type RelationNumericQuery<R extends ResourceLike> = RelationWhereQuery<R> & {
    field: NumericResourceKeys<R>;
};
type AtLeastOne<T> = {
    [K in keyof T]-?: Required<Pick<T, K>> & Partial<Omit<T, K>>;
}[keyof T];
export type RelationFirstQuery<R extends ResourceLike> = Omit<RelationAllQuery<R>, "orderBy"> & {
    orderBy: AtLeastOne<NonNullable<ReadQuery<R>["orderBy"]>>;
};
type ExactRelationOptions<R extends ResourceLike, Q, Allowed extends string> = ExactReadQuery<R, Omit<Q, "field">> & {
    [K in Exclude<keyof Q, Allowed>]: never;
};
export type RelationOperation = "all" | "count" | "exists" | "sum" | "avg" | "min" | "max" | "first" | "last" | "get";
type ExactRelationAllQuery<R extends ResourceLike, Q> = ExactReadQuery<R, Q> & {
    [K in keyof Q]: K extends "page" ? never : K extends "select" ? {
        [F in keyof Q[K]]: F extends keyof R["fields"] ? R["fields"][F] extends RelationField<infer Child, boolean, boolean> ? ExactRelationAllQuery<Child, Q[K][F]> : unknown : never;
    } : unknown;
};
/** A lazy description of a complete relation view, consumed by AppPlan.load(). */
export declare class RelationDependency<Parent extends object, Value, Context = unknown> {
    readonly binding: RelationBinding<Parent, ResourceLike, boolean, Context>;
    readonly query: unknown;
    readonly operation: RelationOperation;
    readonly field?: string | undefined;
    readonly __parent: (row: Parent) => void;
    readonly __context: (context: Context) => void;
    readonly __value: Value;
    constructor(binding: RelationBinding<Parent, ResourceLike, boolean, Context>, query: unknown, operation?: RelationOperation, field?: string | undefined);
}
export declare class RelationBinding<Parent extends object, R extends ResourceLike, Many extends boolean, Context = unknown> {
    readonly resource: R;
    readonly many: Many;
    readonly parentScope: object;
    readonly localField: string | undefined;
    readonly foreignField: string | undefined;
    readonly options: RuntimeReaderOptions;
    readonly __parent: (row: Parent) => void;
    readonly __context: (context: Context) => void;
    constructor(resource: R, many: Many, parentScope: object, localField: string | undefined, foreignField: string | undefined, options: RuntimeReaderOptions);
    get requires(): readonly string[];
    all<const Q extends RelationAllQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationAllQuery<R, Q>): RelationDependency<Parent, Readonly<ReadData<R, Q>["rows"]>, Context>;
    count<const Q extends RelationWhereQuery<R> = RelationWhereQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query?: Q & ExactRelationOptions<R, Q, "where">): RelationDependency<Parent, number, Context>;
    exists<const Q extends RelationWhereQuery<R> = RelationWhereQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query?: Q & ExactRelationOptions<R, Q, "where">): RelationDependency<Parent, boolean, Context>;
    sum<const Q extends RelationNumericQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationOptions<R, Q, "where" | "field">): RelationDependency<Parent, number, Context>;
    avg<const Q extends RelationNumericQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationOptions<R, Q, "where" | "field">): RelationDependency<Parent, number | null, Context>;
    min<const Q extends RelationNumericQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationOptions<R, Q, "where" | "field">): RelationDependency<Parent, number | null, Context>;
    max<const Q extends RelationNumericQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationOptions<R, Q, "where" | "field">): RelationDependency<Parent, number | null, Context>;
    first<const Q extends RelationFirstQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationAllQuery<R, Q>): RelationDependency<Parent, ReadData<R, Q>["rows"][number] | null, Context>;
    last<const Q extends RelationFirstQuery<R>>(this: RelationBinding<Parent, R, true, Context>, query: Q & ExactRelationAllQuery<R, Q>): RelationDependency<Parent, ReadData<R, Q>["rows"][number] | null, Context>;
    get<const Q extends Pick<RelationAllQuery<R>, "select" | "where">>(this: RelationBinding<Parent, R, false, Context>, query: Q & ExactRelationAllQuery<R, Q> & {
        [K in Exclude<keyof Q, "select" | "where">]: never;
    }): RelationDependency<Parent, ReadData<R, Q>["rows"][number] | null, Context>;
    private aggregate;
}
type JoinValue<T> = NonNullable<T> extends readonly (infer Element)[] ? NonNullable<Element> : NonNullable<T>;
type JoinFields<Parent extends object, Child extends object, Local extends Key<Parent>, Foreign extends Key<Child>> = {
    localField: Local;
    foreignField: Foreign & (JoinValue<Parent[Local]> extends JoinValue<Child[Foreign]> ? unknown : never);
};
type JoinOptions<Parent extends object, R extends ResourceLike, Child extends object, Local extends Key<Parent>, Foreign extends Key<Child>, Context = unknown> = Omit<ReaderOptions<R, Child, Context>, "source"> & {
    plan: ReadSource<Child, Context>;
} & JoinFields<Parent, Child, Local, Foreign>;
interface RelationContext {
    readonly parentScope: object;
    readonly localField?: string;
    readonly foreignField?: string;
}
export declare function assertReadOnlyStages(stages: readonly PipelineStage[]): void;
declare abstract class PlanBase<Row extends object, Context = unknown> {
    readonly state: PlanState;
    readonly __rootPlan: true;
    readonly __row: Row;
    readonly __context: (context: Context) => void;
    constructor(state: PlanState);
    /** Establish association before changing the child payload. */
    related<const Needs extends readonly Key<Row>[], const Fields extends SchemaFields>(options: BatchRelationOptions<Row, Needs, Fields, Context>): AppRelationPlan<Row, SchemaRow<Fields>, Context>;
    related<Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(source: MongoSource<Child, Context>, join: JoinFields<Row, Child, Local, Foreign>): MongoRelationPlan<Row, Child, Context>;
    related<Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(source: AppSource<Child, Context>, join: JoinFields<Row, Child, Local, Foreign>): AppRelationPlan<Row, Child, Context>;
    related<Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(source: ReadSource<Child, Context>, join: JoinFields<Row, Child, Local, Foreign>): MongoRelationPlan<Row, Child, Context> | AppRelationPlan<Row, Child, Context>;
    condition(build: (expressions: Expressions<Row>) => MongoExpression<boolean>): Condition<Row, Context>;
    appCondition<const Needs extends readonly Key<Row>[]>(options: {
        requires: Needs;
        evaluate: (row: Readonly<Pick<Row, Needs[number]>>, context: Context) => MaybePromise<boolean>;
    }): Condition<Row, Context>;
    /** Preparation enriches parents; the complete Boolean tree decides membership. */
    pipelineCondition<const Needs extends readonly Key<Row>[], const Fields extends SchemaFields>(options: {
        requires: Needs;
        stages: readonly PipelineStage[];
        output: ObjectSchema<Fields>;
        preservesRows: true;
        test: (expressions: Expressions<Row & SchemaRow<Fields>>) => MongoExpression<boolean>;
    }): Condition<Row, Context>;
    one<R extends ResourceLike, Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(resource: CompatibleResource<R, NoInfer<Child>>, options: JoinOptions<Row, R, Child, Local, Foreign, Context>): RelationBinding<Row, R, false, Context>;
    many<R extends ResourceLike, Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(resource: CompatibleResource<R, NoInfer<Child>>, options: JoinOptions<Row, R, Child, Local, Foreign, Context>): RelationBinding<Row, R, true, Context>;
    private relation;
}
export declare function pick(row: DataRow, keys: readonly string[]): DataRow;
export declare class MongoPlan<Row extends object, Context = unknown> extends PlanBase<Row, Context> {
    readonly __phase: "mongodb";
    derive<const Name extends string, Value>(name: Name, build: (expressions: Expressions<Row>) => MongoExpression<Value>): MongoPlan<Replace<Row, Name, Value>, Context>;
    where(build: (expressions: Expressions<Row>) => MongoExpression<boolean>): MongoPlan<Row, Context>;
    sortBy(order: Partial<Record<Key<Row>, 1 | -1>>): MongoPlan<Row, Context>;
    project<const Keys extends readonly Key<Row>[]>(keys: Keys): MongoPlan<Pick<Row, Keys[number]>, Context>;
    /** Optional fields retain their input row; output types come from the schema. */
    native<const Fields extends SchemaFields, const Needs extends readonly Key<Row>[], const Provides extends readonly string[]>(options: NativeProducerOptions<Row, Fields, Needs, Provides>): MongoPlan<WithFields<Row, Fields>, Context>;
    /** Without provides/requires, the pipeline remains an unconditional transform. */
    native<const Fields extends SchemaFields>(options: NativeTransformOptions<Row, Fields>): MongoPlan<SchemaRow<Fields>, Context>;
    use<Output extends object>(fragment: (plan: MongoPlan<Row, Context>) => MongoPlan<Output, Context>): MongoPlan<Output, Context>;
    toApp(options?: {
        batchSize?: number;
        concurrency?: number;
    }): AppPlan<Row, Context>;
}
export declare class AppPlan<Row extends object, Context = unknown> extends PlanBase<Row, Context> {
    readonly __phase: "application";
    load<const Name extends string, Dependency extends RelationDependency<Row, unknown, Context>>(name: Name, dependency: Dependency): AppPlan<Replace<Row, Name, Dependency["__value"]>, Context>;
    derive<const Name extends string, const Needs extends readonly Key<Row>[], Value>(name: Name, requires: Needs, resolve: (row: Readonly<Pick<Row, Needs[number]>>, context: Context) => MaybePromise<Value>): AppPlan<Replace<Row, Name, Awaited<Value>>, Context>;
    map<Output extends object>(resolve: (row: Readonly<Row>, context: Context) => MaybePromise<Output>): AppPlan<Output, Context>;
    filter(predicate: (row: Readonly<Row>, context: Context) => MaybePromise<boolean>): AppPlan<Row, Context>;
    transformBatch<Output extends object>(resolve: (rows: readonly Readonly<Row>[], context: Context) => MaybePromise<readonly Output[]>): AppPlan<Output, Context>;
    use<Output extends object>(fragment: (plan: AppPlan<Row, Context>) => AppPlan<Output, Context>): AppPlan<Output, Context>;
}
export type ReadPlan<Row extends object, Context = unknown> = MongoPlan<Row, Context> | AppPlan<Row, Context>;
export type PlanRow<P> = P extends {
    readonly __row: infer Row;
} ? Row : never;
export type PlanContext<P> = P extends {
    readonly __context: (context: infer Context) => void;
} ? Context : never;
type ResourceBindingOptions<R extends ResourceLike, Row extends object, Context = unknown> = Omit<ReaderOptions<R, Row, Context>, "source">;
type ResourceBindingArguments<R extends ResourceLike, Row extends object, Context = unknown> = {} extends ResourceBindingOptions<R, Row, Context> ? [options?: ResourceBindingOptions<R, Row, Context>] : [options: ResourceBindingOptions<R, Row, Context>];
/** The join belongs to this context, independently of its transformed payload. */
declare abstract class RelationPlanBase<Parent extends object, Row extends object, Context = unknown> {
    protected readonly plan: ReadPlan<Row, Context>;
    protected readonly correlation: RelationContext;
    readonly __row: Row;
    readonly __context: (context: Context) => void;
    constructor(plan: ReadPlan<Row, Context>, correlation: RelationContext);
    get state(): PlanState;
    one<R extends ResourceLike>(resource: CompatibleResource<R, Row>, ...[options]: ResourceBindingArguments<R, Row, Context>): RelationBinding<Parent, R, false, Context>;
    many<R extends ResourceLike>(resource: CompatibleResource<R, Row>, ...[options]: ResourceBindingArguments<R, Row, Context>): RelationBinding<Parent, R, true, Context>;
    private bind;
    condition(build: (expressions: Expressions<Row>) => MongoExpression<boolean>): Condition<Row, Context>;
    appCondition<const Needs extends readonly Key<Row>[]>(options: {
        requires: Needs;
        evaluate: (row: Readonly<Pick<Row, Needs[number]>>, context: Context) => MaybePromise<boolean>;
    }): Condition<Row, Context>;
    pipelineCondition<const Needs extends readonly Key<Row>[], const Fields extends SchemaFields>(options: {
        requires: Needs;
        stages: readonly PipelineStage[];
        output: ObjectSchema<Fields>;
        preservesRows: true;
        test: (expressions: Expressions<Row & SchemaRow<Fields>>) => MongoExpression<boolean>;
    }): Condition<Row, Context>;
    related<const Needs extends readonly Key<Row>[], const Fields extends SchemaFields>(options: BatchRelationOptions<Row, Needs, Fields, Context>): AppRelationPlan<Row, SchemaRow<Fields>, Context>;
    related<Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(source: MongoSource<Child, Context>, join: JoinFields<Row, Child, Local, Foreign>): MongoRelationPlan<Row, Child, Context>;
    related<Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(source: AppSource<Child, Context>, join: JoinFields<Row, Child, Local, Foreign>): AppRelationPlan<Row, Child, Context>;
    related<Child extends object, const Local extends Key<Row>, const Foreign extends Key<Child>>(source: ReadSource<Child, Context>, join: JoinFields<Row, Child, Local, Foreign>): MongoRelationPlan<Row, Child, Context> | AppRelationPlan<Row, Child, Context>;
    protected assertSameContext<Output extends object>(other: RelationPlanBase<Parent, Output, Context>): void;
}
/** Native stages operate on the rows already matched to one parent. */
export declare class MongoRelationPlan<Parent extends object, Row extends object, Context = unknown> extends RelationPlanBase<Parent, Row, Context> {
    private readonly nativePlan;
    constructor(nativePlan: MongoPlan<Row, Context>, context: RelationContext);
    derive<const Name extends string, Value>(name: Name, build: (expressions: Expressions<Row>) => MongoExpression<Value>): MongoRelationPlan<Parent, Replace<Row, Name, Value>, Context>;
    where(build: (expressions: Expressions<Row>) => MongoExpression<boolean>): MongoRelationPlan<Parent, Row, Context>;
    sortBy(order: Partial<Record<Key<Row>, 1 | -1>>): MongoRelationPlan<Parent, Row, Context>;
    project<const Keys extends readonly Key<Row>[]>(keys: Keys): MongoRelationPlan<Parent, Pick<Row, Keys[number]>, Context>;
    native<const Fields extends SchemaFields, const Needs extends readonly Key<Row>[], const Provides extends readonly string[]>(options: NativeProducerOptions<Row, Fields, Needs, Provides>): MongoRelationPlan<Parent, WithFields<Row, Fields>, Context>;
    native<const Fields extends SchemaFields>(options: Omit<NativeTransformOptions<Row, Fields>, "preserves">): MongoRelationPlan<Parent, SchemaRow<Fields>, Context>;
    toApp(options?: {
        batchSize?: number;
        concurrency?: number;
    }): AppRelationPlan<Parent, Row, Context>;
    use<Output extends object>(fragment: (plan: MongoRelationPlan<Parent, Row, Context>) => MongoRelationPlan<Parent, Output, Context>): MongoRelationPlan<Parent, Output, Context>;
}
/** Application callbacks run inside one parent's relation, including batch callbacks. */
export declare class AppRelationPlan<Parent extends object, Row extends object, Context = unknown> extends RelationPlanBase<Parent, Row, Context> {
    private readonly appPlan;
    constructor(appPlan: AppPlan<Row, Context>, context: RelationContext);
    load<const Name extends string, Dependency extends RelationDependency<Row, unknown, Context>>(name: Name, dependency: Dependency): AppRelationPlan<Parent, Replace<Row, Name, Dependency["__value"]>, Context>;
    derive<const Name extends string, const Needs extends readonly Key<Row>[], Value>(name: Name, requires: Needs, resolve: (row: Readonly<Pick<Row, Needs[number]>>, context: Context) => MaybePromise<Value>): AppRelationPlan<Parent, Replace<Row, Name, Awaited<Value>>, Context>;
    map<Output extends object>(resolve: (row: Readonly<Row>, context: Context) => MaybePromise<Output>): AppRelationPlan<Parent, Output, Context>;
    filter(predicate: (row: Readonly<Row>, context: Context) => MaybePromise<boolean>): AppRelationPlan<Parent, Row, Context>;
    transformBatch<Output extends object>(resolve: (rows: readonly Readonly<Row>[], context: Context) => MaybePromise<readonly Output[]>): AppRelationPlan<Parent, Output, Context>;
    use<Output extends object>(fragment: (plan: AppRelationPlan<Parent, Row, Context>) => AppRelationPlan<Parent, Output, Context>): AppRelationPlan<Parent, Output, Context>;
}
export interface MongoSourceOptions<Row extends object, Context = unknown> {
    /** Required input policy: evaluated before any native stage, at roots and in relations. */
    scope?: (expressions: Expressions<Row>, context: Context) => MongoExpression<boolean>;
}
type SourceModel<Row extends object> = Pick<Model<Row>, "castObject"> & Pick<Model<unknown>, "aggregate" | "collection" | "db"> & {
    readonly schema: {
        readonly paths: Readonly<Record<string, unknown>>;
    };
};
type SourceRow<Row extends object> = Row extends Document ? Omit<Row, Exclude<keyof Document, "_id">> : Row;
export declare function createMongo<Context = unknown>(requiresContext?: boolean): {
    from<Row extends object>(model: SourceModel<Row>, options?: MongoSourceOptions<SourceRow<Row>, Context>): MongoPlan<SourceRow<Row>, Context>;
};
export declare const mongo: {
    from<Row extends object>(model: SourceModel<Row>, options?: MongoSourceOptions<SourceRow<Row>, unknown>): MongoPlan<SourceRow<Row>, unknown>;
};
export {};
//# sourceMappingURL=plan.d.ts.map